// Missions, vérifications et suivi SCORM — atelier Power BI 01
(function () {
  'use strict';
  const A = window.PBI;
  const OK = m => ({ ok: true, msg: m }), KO = m => ({ ok: false, msg: m });
  const M = 'Devis.Montant HT';
  const vis = () => A.S.vis;
  const hasSum = v => (v.val || []).some(m => m.f === M && m.a === 'sum');
  const TRUTH = A.D.devis.filter(r => r[3] === 'Julie' && r[4] === 'Salle de bain').reduce((s, r) => s + r[5], 0);
  function parseNum(t) { if (!t) return NaN; let s = String(t).toLowerCase().replace(/€/g, '').replace(/\s| | /g, '');
    let mult = 1; if (/k$/.test(s)) { mult = 1e3; s = s.slice(0, -1); } else if (/m$/.test(s)) { mult = 1e6; s = s.slice(0, -1); }
    s = s.replace(',', '.'); return parseFloat(s) * mult; }

  const STEPS = [
    { t: 'Faire entrer les données',
      mission: 'Sophie veut un tableau de bord des devis. Le classeur <b>Atelier_Martin_Ventes.xlsx</b> contient les devis, les clients et des notes de Karim. Faites entrer dans Power BI ce qui sert à l\'analyse, et seulement ça. Les données sont déjà propres.',
      h: ['Power BI ne modifie pas votre classeur : il en importe une copie. Ne prenez que les feuilles qui contiennent des données utiles à compter et à filtrer.',
          'Accueil → Obtenir des données → Classeur Excel. Dans le Navigateur, cliquez sur chaque feuille pour l\'aperçu, cochez celles qui servent, puis choisissez entre Charger et Transformer les données.'],
      sol: 'Ouvrez <b>Atelier_Martin_Ventes.xlsx</b>, cochez <b>Devis</b> et <b>Clients</b> (pas Notes), puis <b>Charger</b>.',
      check() { const L = A.S.loaded;
        if (!L.length) return KO('Aucune donnée chargée pour l\'instant.');
        if (L.includes('Notes')) return KO('La table Notes ne contient que du texte libre : elle n\'apporte rien à l\'analyse. Retirez-la (⋯ à côté de son nom, dans le volet Données).');
        if (!L.includes('Devis')) return KO('Il manque la table qui contient les devis et leurs montants.');
        if (!L.includes('Clients')) return KO('Les devis sont chargés. Sophie voudra aussi filtrer par commune : où se trouve cette information ?');
        return OK('Devis et Clients sont dans le modèle. Le classeur Excel, lui, n\'a pas bougé.'); } },
    { t: 'Le chiffre d\'affaires en un coup d\'œil',
      mission: 'Sophie veut voir, en haut de la page, un seul chiffre : le chiffre d\'affaires HT de tous les devis.',
      h: ['Un seul chiffre, mis en avant : il existe un visuel fait pour ça, différent d\'un graphique.',
          'Cliquez sur le fond de la page pour ne rien sélectionner, choisissez le visuel Carte (🔢) dans le volet Visualisations, puis cochez la colonne des montants dans le volet Données.'],
      sol: 'Visuel <b>Carte</b> + case <b>Montant HT</b> cochée : Power BI affiche la <b>Somme de Montant HT</b>.',
      check() { const c = vis().filter(v => v.type === 'carte');
        if (!c.length) return KO('Pas encore de visuel Carte sur la page.');
        if (c.some(hasSum)) return OK('La carte affiche la somme des montants. Power BI arrondit en k (milliers) ou M (millions) : survolez ou utilisez une table pour le détail.');
        const m = c.map(v => v.val[0]).find(Boolean);
        if (m && m.f === M) return KO(`La carte affiche « ${m.a === 'avg' ? 'la moyenne' : m.a === 'cnt' || m.a === 'dc' ? 'un nombre' : 'un ' + (m.a === 'min' ? 'minimum' : 'maximum')} » des montants. Sophie veut le total.`);
        if (m) return KO('La carte n\'affiche pas les montants. Quelle colonne contient le chiffre d\'affaires ?');
        return KO('La carte est vide : il lui faut un champ.'); } },
    { t: 'Qui vend combien ?',
      mission: 'Sophie veut comparer le chiffre d\'affaires de chaque commercial, d\'un coup d\'œil.',
      h: ['Comparer des catégories : chaque commercial devient une barre, et sa longueur montre son chiffre d\'affaires.',
          'Visuel Graphique à barres groupées ou Histogramme groupé. Le champ texte va sur l\'axe des catégories, le montant sur l\'axe des valeurs. Pensez à désélectionner la carte avant.'],
      sol: 'Clic sur le fond de la page → <b>Graphique à barres groupées</b> → cochez <b>Commercial</b> puis <b>Montant HT</b>.',
      check() { const g = vis().filter(v => v.type === 'barres' || v.type === 'histo');
        const okv = g.find(v => v.axe[0] === 'Devis.Commercial' && hasSum(v));
        if (okv) return OK('Une barre par commercial, triée du plus grand au plus petit. Survolez une barre pour lire le montant exact.');
        if (vis().some(v => v.type === 'secteurs' && v.axe[0] === 'Devis.Commercial')) return KO('Un graphique en secteurs montre des parts. Pour comparer des montants entre eux, les barres se lisent mieux.');
        if (g.some(v => v.axe[0] === 'Devis.Commercial')) return KO('Les commerciaux sont bien en catégories. Que mesure la longueur des barres ? Il faut la somme des montants.');
        if (g.some(hasSum)) return KO('Les montants sont là. Par quoi sont-ils répartis ? Il faut une barre par commercial.');
        return KO('Pas encore de graphique à barres ou d\'histogramme qui compare les commerciaux.'); } },
    { t: 'Mois après mois',
      mission: 'Comment le chiffre d\'affaires évolue-t-il ? Sophie veut voir la tendance mois par mois, depuis janvier 2025.',
      h: ['Une évolution dans le temps se lit sur une ligne. Le temps, ici, c\'est la date de chaque devis.',
          'Graphique en courbes, avec Date du devis sur l\'axe X et Montant HT sur l\'axe Y. Power BI commence par les années : les boutons ↑ et ⇊ en haut du visuel montent ou descendent dans la hiérarchie Année > Trimestre > Mois > Jour.'],
      sol: '<b>Graphique en courbes</b> + <b>Date du devis</b> + <b>Montant HT</b>, puis <b>⇊</b> deux fois : Année → Trimestre → Mois.',
      check() { const g = vis().filter(v => v.type === 'courbes' && v.axe[0] === 'Devis.Date du devis' && hasSum(v));
        if (g.some(v => v.lvl === 2)) return OK('Une valeur par mois : on voit les hauts et les bas de l\'activité.');
        if (g.some(v => !v.lvl)) return KO('La courbe n\'a que deux points : un par année. Descendez dans la hiérarchie des dates.');
        if (g.some(v => v.lvl === 1)) return KO('Vous êtes au niveau des trimestres. Encore un niveau.');
        if (g.some(v => v.lvl === 3)) return KO('Une valeur par jour : trop détaillé pour voir une tendance. Remontez d\'un niveau.');
        if (vis().some(v => v.type === 'courbes')) return KO('La courbe existe : vérifiez ses deux champs (la date du devis, et la somme des montants).');
        if (vis().some(v => (v.type === 'histo' || v.type === 'barres') && v.axe[0] === 'Devis.Date du devis')) return KO('Des barres par date se lisent moins bien qu\'une ligne pour suivre une tendance.');
        return KO('Pas encore de graphique en courbes sur la page.'); } },
    { t: 'Filtrer par commune',
      mission: 'Julie et Thomas veulent choisir eux-mêmes une ou plusieurs communes, d\'un clic, et voir toute la page s\'adapter.',
      h: ['Ils doivent choisir eux-mêmes, sur la page : il existe un visuel dédié au filtrage.',
          'Visuel Segment (🔽). La commune ne se trouve pas dans la table Devis : cherchez-la dans l\'autre table.'],
      sol: 'Clic sur le fond → <b>Segment</b> → cochez <b>Clients → Commune</b>. Testez : cochez Compiègne, les autres visuels changent.',
      check() { const s = vis().filter(v => v.type === 'segment');
        if (s.some(v => v.axe[0] === 'Clients.Commune')) return OK('Cochez une commune dans le segment : la carte, les barres et la courbe se recalculent. Pensez à la décocher ensuite.');
        if (s.some(v => v.axe[0])) return KO('Un segment existe, mais sur un autre champ que la commune.');
        if (s.length) return KO('Le segment est vide : il lui faut un champ.');
        if (A.S.xf) return KO('Cliquer dans un graphique filtre aussi, mais Julie et Thomas veulent une liste à cocher, visible sur la page.');
        return KO('Pas encore de segment sur la page.'); } },
    { t: 'Ce qui relie les deux tables',
      mission: 'Le segment filtre les montants des devis, alors que la commune n\'est pas dans la table Devis. Trouvez dans Power BI ce qui relie les deux tables, et ouvrez-en les propriétés.',
      h: ['Deux tables qui ont une colonne en commun : Power BI les a reliées tout seul au chargement.',
          'La barre verticale, tout à gauche, contient trois vues : Rapport, Tableau et Modèle. L\'une d\'elles dessine les tables et leurs liens.'],
      sol: 'Vue <b>Modèle</b> (⛓) → cliquez sur le <b>trait</b> entre Clients et Devis : relation sur <b>Code client</b>, un client (1) pour plusieurs devis (*).',
      check() { if (A.S.relSeen) return OK('La relation passe par Code client : un client (1) a plusieurs devis (*). Le filtre va des clients vers les devis.');
        if (A.S.view === 'M') return KO('Vous êtes dans la bonne vue. Cliquez sur l\'élément qui relie les deux tables.');
        return KO('Pas encore trouvé.'); } },
    { t: 'Un clic qui filtre',
      mission: 'Sophie demande : « Combien Julie a-t-elle vendu en salles de bain, toutes communes confondues ? » Trouvez la réponse avec les visuels, sans créer de calcul, puis saisissez le montant en euros.',
      h: ['Inutile de créer un calcul : cliquer sur un élément d\'un visuel filtre ou met en surbrillance tous les autres visuels de la page.',
          'Il vous faut un visuel par type de travaux (barres ou table). Videz le segment Commune, cliquez sur Salle de bain, puis survolez la barre de Julie : sa partie foncée est la part « salle de bain ».'],
      sol: 'Ajoutez un graphique <b>Type de travaux</b> + <b>Montant HT</b>, cliquez sur <b>Salle de bain</b>, puis lisez l\'info-bulle « Mis en surbrillance » de la barre <b>Julie</b>.',
      input: true,
      check() { const a = A.S.ans[6]; if (a === undefined || a === '') return KO('Saisissez votre réponse, puis cliquez sur Vérifier.');
        const x = parseNum(a); if (isNaN(x)) return KO('Saisissez un nombre, par exemple 12 345.');
        if (Math.abs(x - TRUTH) / TRUTH < 0.005) return OK('Exact. Un clic sur Salle de bain a mis en surbrillance la part correspondante de chaque commercial.');
        const tot = A.D.devis.filter(r => r[3] === 'Julie').reduce((s, r) => s + r[5], 0), sdb = A.D.devis.filter(r => r[4] === 'Salle de bain').reduce((s, r) => s + r[5], 0);
        if (Math.abs(x - tot) / tot < 0.005) return KO('C\'est tout le CA de Julie, toutes catégories confondues. Il faut seulement la part « salle de bain ».');
        if (Math.abs(x - sdb) / sdb < 0.005) return KO('C\'est le CA salle de bain de toute l\'équipe. Il faut seulement celui de Julie.');
        if (x < TRUTH) return KO('Trop bas. Vérifiez que le segment Commune est vide : la question porte sur toutes les communes.');
        return KO('Ce n\'est pas le bon montant. Vérifiez la sélection : Salle de bain d\'un côté, Julie de l\'autre.'); } },
    { t: 'Les nouveaux devis de Karim',
      mission: 'Karim vient d\'ajouter les devis de la semaine dans le classeur Excel. Faites en sorte que le tableau de bord de Sophie les montre, sans rien reconstruire.',
      h: ['Le rapport travaille sur une copie des données, faite au chargement. Cette copie ne se met pas à jour toute seule.',
          'Un bouton du ruban Accueil relit le classeur et rejoue le chargement, sans toucher aux visuels.'],
      sol: 'Accueil → <b>Actualiser</b> : la table Devis passe de 188 à 196 lignes, et la carte augmente.',
      check() { if (!A.S.event) return KO('Attendez le message de Karim (il arrive quand vous ouvrez cette étape).');
        if (A.S.refreshed) return OK('Les 8 nouveaux devis sont dans le rapport : la carte, les barres et la courbe en tiennent compte.');
        return KO('Karim a modifié le classeur, mais le rapport montre toujours l\'ancienne copie des données.'); } },
  ];
  const N = STEPS.length;
  const AIDE = (() => { try { return JSON.parse(localStorage.getItem('pbi01-aide') || '{}'); } catch (e) { return {}; } })();
  const saveAide = () => { try { localStorage.setItem('pbi01-aide', JSON.stringify(AIDE)); } catch (e) {} };

  // ---------- SCORM 1.2 ----------
  const SC = (() => { let api = null; function find(w) { let n = 0; while (w && !w.API && w.parent && w.parent !== w && n < 10) { w = w.parent; n++; } return w && w.API ? w.API : null; }
    try { api = find(window) || (window.opener && find(window.opener)); } catch (e) {}
    const call = (f, ...a) => { try { return api ? api[f](...a) : ''; } catch (e) { return ''; } };
    return { init: () => call('LMSInitialize', ''), get: k => call('LMSGetValue', k), set: (k, x) => call('LMSSetValue', k, String(x)), commit: () => call('LMSCommit', ''), finish: () => call('LMSFinish', '') }; })();
  SC.init();
  const susp = SC.get('cmi.suspend_data'), local = A.saved();
  if (susp && susp.length > 2) A.load(susp); else if (local) A.load(local);
  let saveT; window.onSave = d => { clearTimeout(saveT); saveT = setTimeout(() => { SC.set('cmi.suspend_data', d.length < 4000 ? d : d.slice(0, 0)); SC.commit(); }, 800); };
  window.addEventListener('beforeunload', () => { SC.commit(); SC.finish(); });

  // ---------- panneau ----------
  let cur = 0, lastScore = -1;
  const el = document.getElementById('steps');
  function draw(res) {
    el.innerHTML = STEPS.map((s, i) => { const lv = AIDE[i] || 0;
      const aides = s.h.slice(0, Math.min(lv, 2)).map((x, k) => `<div class="hint"><b>Indice ${k + 1} :</b> ${x}</div>`).join('') + (lv >= 3 ? `<div class="hint"><b>Solution :</b> ${s.sol}</div>` : '');
      const btn = res[i].ok ? '' : lv < 2 ? `<button class="b" data-h="${i}">Indice ${lv + 1}</button>` : lv === 2 ? `<button class="b" data-h="${i}">Voir la solution</button>` : '';
      const tag = lv ? `<span class="lvl">${lv >= 3 ? 'avec la solution' : lv + ' indice' + (lv > 1 ? 's' : '')}</span>` : '';
      const inp = s.input ? `<div class="ans"><input id="ans${i}" placeholder="Montant en €" value="${(A.S.ans[i] || '').replace(/"/g, '')}"><button class="b p" data-ans="${i}">Vérifier</button></div>` : '';
      return `<div class="st${res[i].ok ? ' ok' : ''}${i === cur ? ' on' : ''}" data-i="${i}">
      <div class="hd"><span class="ic">${res[i].ok ? '✓' : i + 1}</span><span>${s.t}</span>${tag}</div>
      <div class="bd"><p>${s.mission}</p>${inp}${aides}
      <div class="fb ${res[i].ok ? 'ok' : 'ko'}">${res[i].ok ? '✓ ' : ''}${res[i].msg}</div>
      <div class="btns">${btn}${i < N - 1 ? `<button class="b p" data-next="${i}">Suivant →</button>` : ''}</div></div></div>`; }).join('')
      + (res.every(r => r.ok) ? `<div class="done"><b>Atelier terminé.</b> ${Object.keys(AIDE).length ? 'Refaites plus tard les étapes où vous avez eu besoin d\'aide.' : 'Sans aucune aide : bravo !'} Refaites maintenant le même rapport dans Power BI Desktop, avec le fichier de la section.</div>` : '');
  }
  function evaluate() {
    if (cur === N - 1 && !A.S.event) { A.S.event = true; A.karim('J\'ai ajouté les 8 devis de cette semaine dans le classeur Excel. Sophie les verra dans son tableau de bord ?'); A.changed(); return; }
    const res = STEPS.map(s => { try { return s.check(); } catch (e) { return KO('Étape à faire.'); } });
    const n = res.filter(r => r.ok).length;
    document.getElementById('pt').textContent = n + ' / ' + N; document.getElementById('pb').style.width = (n / N * 100) + '%';
    const scroll = el.scrollTop; const focus = document.activeElement && document.activeElement.id; draw(res); el.scrollTop = scroll;
    if (focus && focus.startsWith('ans')) { const f = document.getElementById(focus); if (f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); } }
    const score = Math.round(n / N * 100);
    if (score !== lastScore) { lastScore = score; SC.set('cmi.core.score.min', 0); SC.set('cmi.core.score.max', 100); SC.set('cmi.core.score.raw', score); SC.set('cmi.core.lesson_status', n === N ? 'completed' : 'incomplete'); SC.commit(); }
    return res;
  }
  window.onModelChange = evaluate;
  el.addEventListener('click', ev => {
    const hb = ev.target.closest('[data-h]'); if (hb) { const i = +hb.dataset.h; AIDE[i] = (AIDE[i] || 0) + 1; saveAide(); evaluate(); return; }
    const ab = ev.target.closest('[data-ans]'); if (ab) { const i = +ab.dataset.ans; A.S.ans[i] = document.getElementById('ans' + i).value.trim(); A.changed(); return; }
    const nx = ev.target.closest('[data-next]'), hd = ev.target.closest('.hd');
    if (nx) { cur = +nx.dataset.next + 1; evaluate(); return; }
    if (hd) { cur = +hd.parentElement.dataset.i; evaluate(); }
  });
  el.addEventListener('keydown', ev => { if (ev.key === 'Enter' && ev.target.id && ev.target.id.startsWith('ans')) { const i = +ev.target.id.slice(3); A.S.ans[i] = ev.target.value.trim(); A.changed(); } });
  let armed = false; const rb = document.getElementById('reset');
  rb.addEventListener('click', () => { if (!armed) { armed = true; rb.textContent = 'Confirmer la remise à zéro'; rb.classList.add('p'); setTimeout(() => { armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); }, 4000); return; }
    armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); for (const k in AIDE) delete AIDE[k]; saveAide(); cur = 0; document.getElementById('karim').style.display = 'none'; A.reset(); });
  const r0 = STEPS.map(s => { try { return s.check(); } catch (e) { return KO(''); } });
  cur = Math.max(0, r0.findIndex(r => !r.ok)); evaluate();
})();
