// Pseudo Power BI Desktop – Atelier 01 (Académie numérique)
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const D = window.PBD;
  const FIELDS = {
    Devis: [['N° devis', 'txt'], ['Date du devis', 'date'], ['Code client', 'txt'], ['Commercial', 'txt'], ['Type de travaux', 'txt'], ['Montant HT', 'num'], ['Statut', 'txt'], ['Date de signature', 'date']],
    Clients: [['Code client', 'txt'], ['Client', 'txt'], ['Commune', 'txt'], ['Code postal', 'txt'], ['Département', 'txt']],
    Notes: [['Column1', 'txt']],
  };
  const FT = {}; for (const t in FIELDS) for (const [n, ty] of FIELDS[t]) FT[t + '.' + n] = ty;
  const fname = f => f.split('.')[1];
  const VT = {
    barres: { n: 'Graphique à barres groupées', i: '📊', wells: [['axe', 'Axe Y', 1], ['val', 'Axe X', 3]] },
    histo: { n: 'Histogramme groupé', i: '📶', wells: [['axe', 'Axe X', 1], ['val', 'Axe Y', 3]] },
    courbes: { n: 'Graphique en courbes', i: '📈', wells: [['axe', 'Axe X', 1], ['val', 'Axe Y', 3]] },
    secteurs: { n: 'Graphique en secteurs', i: '🥧', wells: [['axe', 'Légende', 1], ['val', 'Valeurs', 1]] },
    carte: { n: 'Carte', i: '🔢', wells: [['val', 'Champs', 1]] },
    table: { n: 'Table', i: '▦', wells: [['col', 'Colonnes', 9]] },
    segment: { n: 'Segment', i: '🔽', wells: [['axe', 'Champ', 1]] },
  };
  const AGG = { sum: 'Somme', avg: 'Moyenne', cnt: 'Nombre', dc: 'Nombre (distinct)', min: 'Minimum', max: 'Maximum' };
  const AGGL = { sum: 'Somme de', avg: 'Moyenne de', cnt: 'Nombre de', dc: 'Nombre de', min: 'Minimum de', max: 'Maximum de' };
  const MOIS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
  const LV = ['Année', 'Trimestre', 'Mois', 'Jour'];

  // ---------- état ----------
  const blank = () => ({ loaded: [], refreshed: false, event: false, vis: [], sel: null, view: 'R', xf: null, relSeen: false, ans: {}, nid: 1, tview: 'Devis' });
  let S = blank();
  const save = () => { const j = JSON.stringify(S); try { localStorage.setItem('pbi01', j); } catch (e) {} if (window.onSave) window.onSave(j); };
  const changed = () => { save(); render(); if (window.onModelChange) window.onModelChange(); };

  // ---------- données ----------
  const cli = {}; D.clients.forEach(c => cli[c[0]] = c);
  function devisRows() {
    const src = S.refreshed ? D.devis.concat(D.nouveaux) : D.devis;
    return src.map(r => { const c = cli[r[2]] || []; const o = {};
      FIELDS.Devis.forEach(([n], k) => o['Devis.' + n] = r[k]);
      if (S.loaded.includes('Clients')) FIELDS.Clients.forEach(([n], k) => o['Clients.' + n] = c[k]);
      return o; });
  }
  function clientRows() { return D.clients.map(c => { const o = {}; FIELDS.Clients.forEach(([n], k) => o['Clients.' + n] = c[k]); return o; }); }
  const hasRel = () => S.loaded.includes('Devis') && S.loaded.includes('Clients');
  function keyOf(v, f, lvl) {
    if (v == null || v === '') return { k: '', l: '(Vide)' };
    if (FT[f] === 'date') { const [y, m, d] = v.split('-'); const q = Math.ceil(+m / 3);
      if (lvl === 0) return { k: y, l: y }; if (lvl === 1) return { k: y + '-' + q, l: y + ' T' + q };
      if (lvl === 2) return { k: y + '-' + m, l: MOIS[+m - 1] + ' ' + y }; return { k: v, l: d + '/' + m + '/' + y }; }
    return { k: String(v), l: String(v) };
  }
  function aggregate(rows, f, a) {
    const v = rows.map(r => r[f]).filter(x => x != null && x !== '');
    if (a === 'cnt') return v.length; if (a === 'dc') return new Set(v).size; if (!v.length) return null;
    if (a === 'sum') return v.reduce((s, x) => s + x, 0); if (a === 'avg') return v.reduce((s, x) => s + x, 0) / v.length;
    if (a === 'min') return Math.min(...v); if (a === 'max') return Math.max(...v);
  }
  const fields = v => [...(v.axe || []), ...(v.val || []).map(x => x.f), ...(v.col || []).map(x => x.f)];
  // filtres actifs pour un visuel
  function filtersFor(v, withXf) {
    const out = [];
    for (const s of S.vis) if (s.type === 'segment' && s.id !== v.id && s.axe && s.axe[0] && s.pick && s.pick.length)
      out.push({ f: s.axe[0], keys: new Set(s.pick), lvl: 0 });
    if (withXf && S.xf && S.xf.vid !== v.id && byId(S.xf.vid)) out.push({ f: S.xf.f, keys: new Set([S.xf.k]), lvl: S.xf.lvl });
    return out;
  }
  function rowsFor(v, filt) {
    const fs = fields(v); const usesDevis = !fs.length || fs.some(f => f.startsWith('Devis.'));
    let rows, ok;
    if (usesDevis) { if (!S.loaded.includes('Devis')) return []; rows = devisRows(); ok = f => f.startsWith('Devis.') || (f.startsWith('Clients.') && hasRel()); }
    else if (fs.every(f => f.startsWith('Clients.'))) { rows = clientRows(); ok = f => f.startsWith('Clients.'); }
    else return [];
    for (const fl of filt) if (ok(fl.f)) rows = rows.filter(r => fl.keys.has(keyOf(r[fl.f], fl.f, fl.lvl).k));
    return rows;
  }
  // calcul générique : catégories × mesures
  function compute(v, mode) {
    const xfMode = mode === 'hl' ? false : true;
    const rows = rowsFor(v, filtersFor(v, xfMode));
    const ax = v.axe && v.axe[0], lvl = v.lvl || 0, ms = v.val || [];
    if (!ax) return { cats: [], tot: ms.map(m => aggregate(rows, m.f, m.a)), rows };
    const g = new Map();
    for (const r of rows) { const { k, l } = keyOf(r[ax], ax, lvl); if (!g.has(k)) g.set(k, { k, l, rows: [] }); g.get(k).rows.push(r); }
    const cats = [...g.values()].map(c => ({ k: c.k, l: c.l, v: ms.map(m => aggregate(c.rows, m.f, m.a)) }));
    return { cats, tot: ms.map(m => aggregate(rows, m.f, m.a)), rows };
  }
  const byId = id => S.vis.find(v => v.id === id);
  const mlabel = m => (FT[m.f] === 'num' || m.a === 'cnt' || m.a === 'dc' ? AGGL[m.a] + ' ' : '') + fname(m.f);
  const nf = x => x == null ? '' : (Math.round(x * 100) / 100).toLocaleString('fr-FR');
  const short = x => { if (x == null) return ''; const a = Math.abs(x); if (a >= 1e6) return (x / 1e6).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' M'; if (a >= 1e3) return (x / 1e3).toLocaleString('fr-FR', { maximumFractionDigits: 2 }) + ' k'; return nf(x); };

  // ---------- rendu ----------
  function render() {
    ['R', 'T', 'M'].forEach(k => $('v' + k).classList.toggle('on', S.view === k));
    $('pVis').style.display = S.view === 'R' ? '' : 'none';
    $('fname').textContent = (S.loaded.length ? 'Atelier_Martin_Ventes' : 'Sans titre') + ' – Power BI Desktop';
    $('bTr').disabled = $('bRef').disabled = !S.loaded.length;
    if (S.view === 'R') renderReport(); else if (S.view === 'T') renderTable(); else renderModel();
    renderFields(); renderVisPane();
  }
  function renderReport() {
    const c = $('center');
    let h = '<div class="cv" id="cv"><div class="page" id="page">';
    if (!S.loaded.length) h += `<div class="empty"><b>Ajouter des données à votre rapport</b><span>Une fois chargées, vos données apparaissent dans le volet Données.</span><button class="b p" id="eXl">📗 Importer des données depuis Excel</button></div>`;
    else if (!S.vis.length) h += `<div class="empty"><b>Créez des visuels avec vos données</b><span>Choisissez un visuel dans le volet Visualisations, ou cochez un champ dans le volet Données.</span></div>`;
    S.vis.forEach(v => { h += `<div class="vis${S.sel === v.id ? ' on' : ''}" data-v="${v.id}"><div class="vh">${v.axe && v.axe[0] && FT[v.axe[0]] === 'date' && v.type !== 'segment' ? `<button data-up="${v.id}" title="Monter d'un niveau dans la hiérarchie" ${!(v.lvl > 0) ? 'disabled' : ''}>↑</button><button data-dn="${v.id}" title="Développer tout d'un niveau dans la hiérarchie" ${v.lvl >= 3 ? 'disabled' : ''}>⇊</button>` : ''}<button data-del="${v.id}" title="Supprimer le visuel">✕</button></div><div class="vt">${esc(title(v))}</div><div class="vb">${body(v)}</div></div>`; });
    h += '</div></div><div class="ptabs"><span class="on">Page 1</span><span>+</span></div>';
    c.innerHTML = h;
  }
  function title(v) {
    const ms = (v.val || []).map(mlabel), ax = v.axe && v.axe[0] ? fname(v.axe[0]) : '';
    if (v.type === 'segment') return ax; if (v.type === 'table') return '';
    if (v.type === 'carte') return '';
    if (!ms.length && !ax) return '';
    return ms.join(' et ') + (ax ? ' par ' + (FT[v.axe[0]] === 'date' ? LV.slice(0, (v.lvl || 0) + 1).join(', ') : ax) : '');
  }
  const PH = { barres: 'Ajoutez des champs dans Axe Y et Axe X', histo: 'Ajoutez des champs dans Axe X et Axe Y', courbes: 'Ajoutez des champs dans Axe X et Axe Y', secteurs: 'Ajoutez des champs dans Légende et Valeurs', carte: 'Ajoutez un champ dans Champs', table: 'Ajoutez des champs dans Colonnes', segment: 'Ajoutez un champ dans Champ' };
  function body(v) {
    const ph = `<div class="ph">${PH[v.type]}</div>`;
    if (v.type === 'carte') { if (!v.val || !v.val[0]) return ph; const r = compute(v); return `<div class="card"><div class="n">${esc(short(r.tot[0]))}</div><div class="l">${esc(mlabel(v.val[0]))}</div></div>`; }
    if (v.type === 'segment') { if (!v.axe || !v.axe[0]) return ph; const f = v.axe[0];
      const rows = FT[f] && f.startsWith('Clients.') ? clientRows() : devisRows(); const m = new Map();
      rows.forEach(r => { const o = keyOf(r[f], f, 0); m.set(o.k, o.l); });
      const ks = [...m.keys()].sort((a, b) => a.localeCompare(b, 'fr'));
      return `<div class="sl">` + ks.map(k => `<label><input type="checkbox" data-sl="${v.id}" value="${esc(k)}" ${(v.pick || []).includes(k) ? 'checked' : ''}>${esc(m.get(k))}</label>`).join('') + '</div>'; }
    if (v.type === 'table') return tableBody(v);
    if (!(v.axe && v.axe[0]) || !(v.val && v.val[0])) return ph;
    return chart(v);
  }
  function tableBody(v) {
    const cols = v.col || []; if (!cols.length) return `<div class="ph">${PH.table}</div>`;
    const dims = cols.filter(c => !c.a), ms = cols.filter(c => c.a);
    const rows = rowsFor(v, filtersFor(v, true));
    const g = new Map();
    for (const r of rows) { const ks = dims.map(d => keyOf(r[d.f], d.f, 3)); const k = ks.map(x => x.k).join('|'); if (!g.has(k)) g.set(k, { ks, rows: [] }); g.get(k).rows.push(r); }
    let list = [...g.values()].sort((a, b) => a.ks.map(x => x.k).join('|').localeCompare(b.ks.map(x => x.k).join('|'), 'fr'));
    const clickable = dims.length === 1;
    let h = '<div class="tv"><table><tr>' + cols.map(c => `<th>${esc(c.a ? mlabel(c) : fname(c.f))}</th>`).join('') + '</tr>';
    list.slice(0, 300).forEach(e => { const k = e.ks.map(x => x.k).join('|'); const sel = S.xf && S.xf.vid === v.id && S.xf.k === k;
      h += `<tr class="${clickable ? 'k' : ''}${sel ? ' xs' : ''}" ${clickable ? `data-xv="${v.id}" data-xk="${esc(k)}"` : ''}>` + cols.map(c => c.a ? `<td class="n">${nf(aggregate(e.rows, c.f, c.a))}</td>` : `<td>${esc(e.ks[dims.indexOf(c)].l)}</td>`).join('') + '</tr>'; });
    if (ms.length) h += '<tr class="tot">' + cols.map((c, i) => c.a ? `<td class="n">${nf(aggregate(rows, c.f, c.a))}</td>` : `<td>${i === 0 ? 'Total' : ''}</td>`).join('') + '</tr>';
    return h + '</table></div>';
  }
  const COLS = ['#118DFF', '#12239E', '#E66C37', '#6B007B', '#E044A7', '#744EC2', '#D9B300', '#D64550'];
  function chart(v) {
    const r = compute(v); const hl = (S.xf && S.xf.vid !== v.id && byId(S.xf.vid) && v.type !== 'courbes') ? compute(v, 'hl') : null;
    // en surbrillance : base = sans le filtre croisé ; hl = avec
    let cats = hl ? hl.cats : r.cats; let hmap = null;
    if (hl) { hmap = new Map(r.cats.map(c => [c.k, c.v])); }
    if (v.type === 'courbes') cats = cats.slice().sort((a, b) => a.k.localeCompare(b.k));
    else if (FT[v.axe[0]] === 'date') cats = cats.slice().sort((a, b) => a.k.localeCompare(b.k));
    else cats = cats.slice().sort((a, b) => (b.v[0] || 0) - (a.v[0] || 0));
    if (!cats.length) return '<div class="ph">Aucune donnée</div>';
    const W = 300, H = 190, ns = v.val.length; const max = Math.max(...cats.flatMap(c => c.v.map(x => x || 0)), 1);
    const id = v.id; let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">`;
    const tipData = (c, j) => `data-tip="${esc(fname(v.axe[0]))}|${esc(c.l)}|${esc(mlabel(v.val[j]))}|${esc(nf(c.v[j]))}${hmap ? '|' + esc(nf((hmap.get(c.k) || [])[j] || 0)) : ''}"`;
    const selK = S.xf && S.xf.vid === v.id ? S.xf.k : null;
    const dim = k => selK != null && selK !== k ? ' opacity="0.35"' : '';
    if (v.type === 'barres') {
      const L = 92, top = 6, ch = (H - top - 18) / cats.length, bw = Math.min(26, ch * 0.75 / ns);
      cats.forEach((c, i) => { const y = top + i * ch;
        s += `<text x="${L - 6}" y="${y + ch / 2 + 4}" font-size="10" text-anchor="end" fill="#605e5c">${esc(c.l.length > 15 ? c.l.slice(0, 14) + '…' : c.l)}</text>`;
        c.v.forEach((x, j) => { const yy = y + (ch - bw * ns) / 2 + j * bw; const w = (W - L - 10) * (x || 0) / max;
          if (hmap) { s += `<rect x="${L}" y="${yy}" width="${w}" height="${bw - 1}" fill="${COLS[j]}" opacity="0.3"/>`; const hv = (hmap.get(c.k) || [])[j] || 0; s += `<rect class="k" data-xv="${id}" data-xk="${esc(c.k)}" ${tipData(c, j)} x="${L}" y="${yy}" width="${Math.max(w, (W - L - 10) * hv / max)}" height="${bw - 1}" fill="transparent"/><rect pointer-events="none" x="${L}" y="${yy}" width="${(W - L - 10) * hv / max}" height="${bw - 1}" fill="${COLS[j]}"/>`; }
          else s += `<rect class="k" data-xv="${id}" data-xk="${esc(c.k)}" ${tipData(c, j)} x="${L}" y="${yy}" width="${w}" height="${bw - 1}" fill="${COLS[j]}"${dim(c.k)}/>`; }); });
      s += `<text x="${L}" y="${H - 3}" font-size="9" fill="#a19f9d">0</text><text x="${W - 10}" y="${H - 3}" font-size="9" text-anchor="end" fill="#a19f9d">${short(max)}</text>`;
    } else if (v.type === 'histo') {
      const L = 42, B = H - 30, cw = (W - L - 6) / cats.length, bw = Math.min(30, cw * 0.75 / ns);
      cats.forEach((c, i) => { const x0 = L + i * cw;
        s += `<text x="${x0 + cw / 2}" y="${B + 12}" font-size="9" text-anchor="middle" fill="#605e5c">${esc(c.l.length > 11 ? c.l.slice(0, 10) + '…' : c.l)}</text>`;
        c.v.forEach((x, j) => { const hh = (B - 8) * (x || 0) / max, xx = x0 + (cw - bw * ns) / 2 + j * bw;
          if (hmap) { const hv = (hmap.get(c.k) || [])[j] || 0, h2 = (B - 8) * hv / max; s += `<rect x="${xx}" y="${B - hh}" width="${bw - 1}" height="${hh}" fill="${COLS[j]}" opacity="0.3"/><rect pointer-events="none" x="${xx}" y="${B - h2}" width="${bw - 1}" height="${h2}" fill="${COLS[j]}"/><rect class="k" data-xv="${id}" data-xk="${esc(c.k)}" ${tipData(c, j)} x="${xx}" y="${B - hh}" width="${bw - 1}" height="${hh}" fill="transparent"/>`; }
          else s += `<rect class="k" data-xv="${id}" data-xk="${esc(c.k)}" ${tipData(c, j)} x="${xx}" y="${B - hh}" width="${bw - 1}" height="${hh}" fill="${COLS[j]}"${dim(c.k)}/>`; }); });
      s += `<line x1="${L}" x2="${W - 4}" y1="${B}" y2="${B}" stroke="#e1dfdd"/><text x="${L - 4}" y="12" font-size="9" text-anchor="end" fill="#a19f9d">${short(max)}</text><text x="${L - 4}" y="${B}" font-size="9" text-anchor="end" fill="#a19f9d">0</text>`;
    } else if (v.type === 'courbes') {
      const L = 42, B = H - 30, n = cats.length, dx = n > 1 ? (W - L - 12) / (n - 1) : 0;
      [0.5, 1].forEach(t => s += `<line x1="${L}" x2="${W - 6}" y1="${B - (B - 8) * t}" y2="${B - (B - 8) * t}" stroke="#f0f0f0"/><text x="${L - 4}" y="${B - (B - 8) * t + 3}" font-size="9" text-anchor="end" fill="#a19f9d">${short(max * t)}</text>`);
      v.val.forEach((m, j) => { const pts = cats.map((c, i) => [L + 6 + i * dx, B - (B - 8) * (c.v[j] || 0) / max]);
        s += `<polyline fill="none" stroke="${COLS[j]}" stroke-width="2" points="${pts.map(p => p.join(',')).join(' ')}"/>`;
        pts.forEach((p, i) => s += `<circle class="k" data-xv="${id}" data-xk="${esc(cats[i].k)}" ${tipData(cats[i], j)} cx="${p[0]}" cy="${p[1]}" r="${n > 30 ? 2.5 : 3.5}" fill="${COLS[j]}"/>`); });
      const step = Math.ceil(n / 5); cats.forEach((c, i) => { if (i % step === 0) s += `<text x="${L + 6 + i * dx}" y="${B + 12}" font-size="8.5" text-anchor="middle" fill="#605e5c">${esc(c.l)}</text>`; });
      s += `<line x1="${L}" x2="${W - 4}" y1="${B}" y2="${B}" stroke="#e1dfdd"/>`;
    } else if (v.type === 'secteurs') {
      const tot = cats.reduce((a, c) => a + (c.v[0] || 0), 0) || 1; let a0 = -Math.PI / 2; const cx = 85, cy = 92, R = 72;
      cats.forEach((c, i) => { const a1 = a0 + 2 * Math.PI * (c.v[0] || 0) / tot; const big = a1 - a0 > Math.PI ? 1 : 0;
        const p = `M${cx},${cy} L${cx + R * Math.cos(a0)},${cy + R * Math.sin(a0)} A${R},${R} 0 ${big} 1 ${cx + R * Math.cos(a1)},${cy + R * Math.sin(a1)} Z`;
        s += `<path class="k" data-xv="${id}" data-xk="${esc(c.k)}" ${tipData(c, 0)} d="${p}" fill="${COLS[i % 8]}" stroke="#fff"${dim(c.k)}${hmap && !(hmap.get(c.k) || [])[0] ? ' opacity="0.3"' : ''}/>`;
        if (i < 9) s += `<rect x="178" y="${12 + i * 18}" width="9" height="9" fill="${COLS[i % 8]}"/><text x="191" y="${20 + i * 18}" font-size="10" fill="#605e5c">${esc(c.l.length > 16 ? c.l.slice(0, 15) + '…' : c.l)}</text>`;
        a0 = a1; });
    }
    return s + '</svg>';
  }
  function renderTable() {
    const t = S.loaded.includes(S.tview) ? S.tview : S.loaded[0];
    const c = $('center');
    if (!t) { c.innerHTML = '<div class="dview"><div class="nod">Aucune donnée chargée.</div></div>'; return; }
    let rows = t === 'Devis' ? (S.refreshed ? D.devis.concat(D.nouveaux) : D.devis) : t === 'Clients' ? D.clients : [['Notes de Karim – ne pas importer'], ['Export du logiciel de devis, mis à jour chaque lundi.'], ['Les montants sont hors taxes.'], ['À faire : relancer les devis en attente de plus de 30 jours.']];
    const fs = FIELDS[t];
    const fmt = (x, ty) => x == null ? '' : ty === 'date' ? x.split('-').reverse().join('/') : ty === 'num' ? nf(x) : x;
    let h = '<div class="dview"><table><tr>' + fs.map(f => `<th>${esc(f[0])}</th>`).join('') + '</tr>';
    rows.forEach(r => h += '<tr>' + fs.map((f, k) => `<td class="${f[1] === 'num' ? 'n' : ''}">${esc(fmt(r[k], f[1]))}</td>`).join('') + '</tr>');
    c.innerHTML = h + `</table></div><div class="dfoot">Table : ${t} (${rows.length} lignes) · Cliquez sur le nom d'une table dans le volet Données pour l'afficher.</div>`;
  }
  function renderModel() {
    const c = $('center'); const pos = { Clients: [40, 40], Devis: [360, 70], Notes: [40, 330] };
    let h = '<div class="mview" id="mv"><svg width="900" height="520" style="position:absolute;left:0;top:0">';
    if (hasRel()) { const x1 = 230, y1 = 40 + 30 + 10, x2 = 360, y2 = 70 + 30 + 52;
      h += `<g class="rel${S.relOpen ? ' on' : ''}" id="rel"><line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#8a8886" stroke-width="2"/><line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="transparent" stroke-width="16"/>
      <text x="${x1 + 8}" y="${y1 - 6}" font-size="13" fill="#252423">1</text><text x="${x2 - 16}" y="${y2 - 6}" font-size="14" fill="#252423">*</text>
      <polygon points="${(x1 + x2) / 2 - 5},${(y1 + y2) / 2 - 7} ${(x1 + x2) / 2 + 7},${(y1 + y2) / 2 + 3} ${(x1 + x2) / 2 - 6},${(y1 + y2) / 2 + 6}" fill="#605e5c"/></g>`; }
    h += '</svg>';
    for (const t of S.loaded) { const [x, y] = pos[t];
      h += `<div class="mcard" style="left:${x}px;top:${y}px"><div class="mh">${t}</div>` + FIELDS[t].map(f => `<div class="mf${f[0] === 'Code client' && hasRel() ? ' key' : ''}">${FT[t + '.' + f[0]] === 'num' ? 'Σ ' : ''}${esc(f[0])}</div>`).join('') + '</div>'; }
    if (!S.loaded.length) h += '<div class="nod">Aucune table chargée.</div>';
    h += `<div class="props" id="props" style="display:${S.relOpen ? 'block' : 'none'}"><h4>Propriétés de la relation</h4>
      <div class="r"><span>De : table (colonne)</span><b>Devis (Code client)</b></div><div class="r"><span>Vers : table (colonne)</span><b>Clients (Code client)</b></div>
      <div class="r"><span>Cardinalité</span><b>Plusieurs-à-un (*:1)</b></div><div class="r"><span>Direction du filtrage croisé</span><b>Unique</b></div>
      <div class="r"><span>Rendre cette relation active</span><b>☑</b></div>
      <p style="color:#605e5c;margin:8px 0 0">Relation détectée automatiquement au chargement. Vous apprendrez à créer et régler les relations à la leçon 4.</p>
      <div style="text-align:right;margin-top:8px"><button class="btn" id="closeRel">Fermer</button></div></div>`;
    c.innerHTML = h + '</div>';
  }
  function renderFields() {
    const el = $('fields'); if (!S.loaded.length) { el.innerHTML = '<div class="nod">Aucune donnée. Utilisez Obtenir des données dans le ruban Accueil.</div>'; return; }
    const v = byId(S.sel); const inV = v ? new Set(fields(v)) : new Set(); const q = ($('srch').value || '').toLowerCase();
    el.innerHTML = S.loaded.map(t => `<div class="tbl"><div class="tn" data-tbl="${t}">▾ ▦ ${t}<button class="more" data-more="${t}" title="Plus d'options">⋯</button></div>` +
      FIELDS[t].filter(f => !q || f[0].toLowerCase().includes(q)).map(([n, ty]) => { const f = t + '.' + n;
        return `<label class="fld"><input type="checkbox" data-f="${esc(f)}" ${inV.has(f) ? 'checked' : ''}><span class="ty">${ty === 'num' ? 'Σ' : ty === 'date' ? '📅' : ''}</span>${esc(n)}</label>`; }).join('') + '</div>').join('');
  }
  function renderVisPane() {
    const v = byId(S.sel);
    $('gal').innerHTML = Object.entries(VT).map(([k, t]) => `<button data-vt="${k}" title="${t.n}" class="${v && v.type === k ? 'on' : ''}">${t.i}</button>`).join('');
    document.querySelector('#pVis .vtype').textContent = v ? 'Visuel sélectionné : ' + VT[v.type].n : 'Créer un visuel';
    if (!v) { $('wells').innerHTML = '<div class="nod" style="padding:6px 2px">Sélectionnez un visuel sur la page pour voir ses champs, ou choisissez un type ci-dessus pour en créer un.</div>'; return; }
    $('wells').innerHTML = VT[v.type].wells.map(([w, lab]) => { const items = v[w] || [];
      return `<div class="well"><div class="wl">${lab}</div><div class="wb">` + (items.length ? items.map((it, i) => { const f = typeof it === 'string' ? it : it.f; const a = typeof it === 'string' ? null : it.a;
        const sel = a ? `<select data-agg="${w}:${i}">${(FT[f] === 'num' ? ['sum', 'avg', 'min', 'max', 'cnt', 'dc'] : ['cnt', 'dc']).map(k => `<option value="${k}" ${k === a ? 'selected' : ''}>${AGG[k]}</option>`).join('')}</select>` : '';
        return `<div class="chip"><span title="${esc(fname(f))}">${esc(a ? mlabel(it) : fname(f) + (FT[f] === 'date' && w === 'axe' && v.type !== 'segment' ? ' (hiérarchie)' : ''))}</span>${sel}<button data-rm="${w}:${i}" title="Supprimer le champ">✕</button></div>`; }).join('') : '<div class="ph2">Ajoutez des champs de données ici</div>') + '</div></div>'; }).join('');
  }

  // ---------- actions sur les visuels ----------
  function newVis(type) { const v = { id: S.nid++, type, axe: [], val: [], col: [], lvl: 0, pick: [] }; S.vis.push(v); S.sel = v.id; return v; }
  function addField(f) {
    let v = byId(S.sel); const ty = FT[f];
    if (!v) v = newVis(ty === 'num' ? 'histo' : 'table');
    const m = { f, a: ty === 'num' ? 'sum' : 'cnt' };
    if (v.type === 'table') { v.col.push(ty === 'num' ? m : { f }); return; }
    if (v.type === 'carte') { v.val = [m]; return; }
    if (v.type === 'segment') { v.axe = [f]; v.pick = []; return; }
    if (ty === 'num') { if (v.val.length >= (v.type === 'secteurs' ? 1 : 3)) v.val = v.val.slice(1); v.val.push(m); return; }
    if (!v.axe.length) { v.axe = [f]; v.lvl = 0; return; }
    if (!v.val.length && v.type !== 'secteurs') { v.val.push(m); flash(`« ${fname(f)} » est un texte : Power BI le compte (Nombre de ${fname(f)}).`); return; }
    flash(`L'axe contient déjà « ${fname(v.axe[0])} ». Décochez-le d'abord, ou supprimez-le dans le volet Visualisations.`);
  }
  function removeField(f) { const v = byId(S.sel); if (!v) return;
    v.axe = v.axe.filter(x => x !== f); v.val = v.val.filter(x => x.f !== f); v.col = v.col.filter(x => x.f !== f); if (!v.axe.length) v.lvl = 0;
    if (S.xf && S.xf.vid === v.id) S.xf = null; }
  function convert(v, type) {
    const all = [...v.axe.map(f => ({ f })), ...v.col, ...v.val];
    const dims = all.filter(x => !x.a).map(x => x.f), ms = all.filter(x => x.a);
    v.type = type; v.axe = []; v.val = []; v.col = []; v.pick = [];
    if (type === 'table') { v.col = [...dims.map(f => ({ f })), ...ms]; }
    else if (type === 'carte') { v.val = ms.slice(0, 1); if (!ms.length && dims[0]) v.val = [{ f: dims[0], a: 'cnt' }]; }
    else if (type === 'segment') { v.axe = dims.slice(0, 1); }
    else { v.axe = dims.slice(0, 1); v.val = ms.slice(0, type === 'secteurs' ? 1 : 3); }
    if (S.xf && S.xf.vid === v.id) S.xf = null;
  }

  // ---------- événements ----------
  document.addEventListener('click', e => {
    const t = e.target;
    if (t.closest('#rel')) { S.relOpen = true; S.relSeen = true; changed(); return; }
    if (!t.closest('#bGet') && !t.closest('#ddGet')) $('ddGet').style.display = 'none';
    if (t.closest('#bGet')) { $('ddGet').style.display = $('ddGet').style.display === 'block' ? 'none' : 'block'; return; }
    if (t.closest('[data-src]') || t.closest('#bXl') || t.closest('#eXl')) { $('ddGet').style.display = 'none'; openFile(); return; }
    if (t.closest('#bTr')) { dlg('Transformer les données', `<p>Ce bouton ouvre l'<b>éditeur Power Query</b>, pour nettoyer les données avant de les charger : supprimer des colonnes, corriger des types, remplacer des valeurs…</p><p>Vous l'utiliserez à la leçon 2. Les données d'Atelier Martin sont déjà propres : inutile ici.</p>`, [['Fermer', closeDlg, 1]]); return; }
    if (t.closest('#bRef')) { refresh(); return; }
    if (t.closest('#bNew')) { if (!S.loaded.length) return flash('Chargez d\'abord des données.'); S.view = 'R'; newVis('histo'); changed(); return; }
    if (t.closest('#vR')) { S.view = 'R'; changed(); return; } if (t.closest('#vT')) { S.view = 'T'; changed(); return; } if (t.closest('#vM')) { S.view = 'M'; changed(); return; }
    const vt = t.closest('[data-vt]'); if (vt) { if (!S.loaded.length) return flash('Chargez d\'abord des données.'); const v = byId(S.sel); if (v) convert(v, vt.dataset.vt); else newVis(vt.dataset.vt); changed(); return; }
    const rm = t.closest('[data-rm]'); if (rm) { const [w, i] = rm.dataset.rm.split(':'); const v = byId(S.sel); v[w].splice(+i, 1); if (w === 'axe') { v.lvl = 0; v.pick = []; } if (S.xf && S.xf.vid === v.id) S.xf = null; changed(); return; }
    const del = t.closest('[data-del]'); if (del) { const id = +del.dataset.del; S.vis = S.vis.filter(v => v.id !== id); if (S.sel === id) S.sel = null; if (S.xf && S.xf.vid === id) S.xf = null; changed(); return; }
    const up = t.closest('[data-up]'), dn = t.closest('[data-dn]');
    if (up || dn) { const v = byId(+(up || dn).dataset[up ? 'up' : 'dn']); v.lvl = Math.max(0, Math.min(3, (v.lvl || 0) + (dn ? 1 : -1))); if (S.xf && S.xf.vid === v.id) S.xf = null; S.sel = v.id; changed(); return; }
    const more = t.closest('[data-more]'); if (more) { const tb = more.dataset.more;
      dlg('Table ' + tb, `<p>Que voulez-vous faire de la table <b>${tb}</b> ?</p>`, [['Supprimer du modèle', () => { S.loaded = S.loaded.filter(x => x !== tb); S.vis.forEach(v => { ['axe'].forEach(w => v[w] = v[w].filter(f => !f.startsWith(tb + '.'))); v.val = v.val.filter(m => !m.f.startsWith(tb + '.')); v.col = v.col.filter(m => !m.f.startsWith(tb + '.')); }); if (S.tview === tb) S.tview = S.loaded[0]; closeDlg(); changed(); flash('Table ' + tb + ' supprimée du modèle. Le classeur Excel, lui, n\'a pas changé.'); }, 0], ['Annuler', closeDlg, 1]]); return; }
    const tn = t.closest('[data-tbl]'); if (tn && S.view === 'T') { S.tview = tn.dataset.tbl; changed(); return; }

    if (t.closest('#closeRel')) { S.relOpen = false; changed(); return; }
    const xk = t.closest('[data-xk]'); if (xk) { const v = byId(+xk.dataset.xv); S.sel = v.id;
      const f = v.type === 'table' ? (v.col.find(c => !c.a) || {}).f : v.axe[0]; const lvl = v.type === 'table' ? 3 : (v.lvl || 0);
      if (S.xf && S.xf.vid === v.id && S.xf.k === xk.dataset.xk) S.xf = null; else S.xf = { vid: v.id, f, k: xk.dataset.xk, lvl };
      changed(); return; }
    const vis = t.closest('.vis'); if (vis) { if (t.closest('[data-sl]')) return; const id = +vis.dataset.v; if (S.sel !== id) { S.sel = id; changed(); } return; }
    if (t.closest('#page') || (t.closest('#cv'))) { if (S.sel || S.xf) { S.sel = null; S.xf = null; changed(); } }
  });
  document.addEventListener('change', e => {
    const t = e.target;
    if (t.dataset.f) { if (S.view !== 'R') { S.view = 'R'; } if (t.checked) addField(t.dataset.f); else removeField(t.dataset.f); changed(); return; }
    if (t.dataset.agg) { const [w, i] = t.dataset.agg.split(':'); byId(S.sel)[w][+i].a = t.value; changed(); return; }
    if (t.dataset.sl) { const v = byId(+t.dataset.sl); const s = new Set(v.pick || []); t.checked ? s.add(t.value) : s.delete(t.value); v.pick = [...s]; S.sel = v.id; changed(); return; }
  });
  $('srch').addEventListener('input', renderFields);
  document.addEventListener('keydown', e => { if (e.key === 'Delete' && S.sel && S.view === 'R' && !/INPUT|SELECT/.test(document.activeElement.tagName)) { S.vis = S.vis.filter(v => v.id !== S.sel); if (S.xf && S.xf.vid === S.sel) S.xf = null; S.sel = null; changed(); } if (e.key === 'Escape') closeDlg(); });
  // info-bulles
  const tip = $('tip');
  document.addEventListener('mousemove', e => { const d = e.target.closest && e.target.closest('[data-tip]');
    if (!d) { tip.style.display = 'none'; return; } const [a, b, c, x, h] = d.dataset.tip.split('|');
    tip.innerHTML = `${esc(a)} <b>${esc(b)}</b><br>${esc(c)} <b>${esc(x)}</b>` + (h !== undefined ? `<br>Mis en surbrillance <b>${esc(h)}</b>` : '');
    tip.style.display = 'block'; tip.style.left = Math.min(e.clientX + 14, innerWidth - 260) + 'px'; tip.style.top = (e.clientY + 14) + 'px'; });

  // ---------- boîtes de dialogue ----------
  function dlg(titre, html, btns) {
    $('dlg').innerHTML = `<div class="dh"><span>${titre}</span><button onclick="PBI.closeDlg()">✕</button></div><div class="dbd">${html}</div><div class="df">` + btns.map((b, i) => `<button class="btn${b[2] ? '' : ' p'}" data-db="${i}" ${b[3] ? 'disabled' : ''}>${b[0]}</button>`).join('') + '</div>';
    $('dlg').querySelectorAll('[data-db]').forEach(x => x.onclick = () => btns[+x.dataset.db][1]());
    $('mask').style.display = 'flex';
  }
  function closeDlg() { $('mask').style.display = 'none'; }
  function openFile() {
    let pick = null;
    dlg('Ouvrir', `<div style="color:#605e5c;font-size:12.5px">Ce PC › Documents › Atelier Martin</div><div class="files" id="fl">
      <div data-fn="ventes">📗 <span>Atelier_Martin_Ventes.xlsx</span><span style="margin-left:auto;color:#605e5c">Classeur Excel · 21 Ko</span></div>
      <div class="dis">📄 <span>Planning_chantiers.docx</span><span style="margin-left:auto">Document Word</span></div>
      <div class="dis">📄 <span>Tarifs_fournisseurs.pdf</span><span style="margin-left:auto">PDF</span></div></div>
      <p style="color:#605e5c;font-size:12px">Type de fichier : Fichiers Excel (*.xlsx; *.xlsm; *.xls)</p>`, [['Ouvrir', () => { if (pick) navigator(); }, 0, 1], ['Annuler', closeDlg, 1]]);
    const ob = $('dlg').querySelector('[data-db="0"]');
    $('fl').querySelector('[data-fn]').onclick = function () { this.classList.add('on'); pick = 1; ob.disabled = false; };
    $('fl').querySelector('[data-fn]').ondblclick = () => navigator();
  }
  function navigator(keep) {
    const ck = keep || new Set(); let pv = keep && keep.size ? [...keep][0] : 'Devis';
    const prev = t => { const fs = FIELDS[t]; const rows = t === 'Devis' ? D.devis.slice(0, 14) : t === 'Clients' ? D.clients.slice(0, 14) : [['Notes de Karim – ne pas importer'], ['Export du logiciel de devis, mis à jour chaque lundi.'], ['Les montants sont hors taxes.'], ['À faire : relancer les devis en attente de plus de 30 jours.']];
      return `<table><tr>${fs.map(f => `<th>${esc(f[0])}</th>`).join('')}</tr>${rows.map(r => '<tr>' + fs.map((f, k) => `<td>${esc(f[1] === 'date' && r[k] ? r[k].split('-').reverse().join('/') : r[k] ?? '')}</td>`).join('') + '</tr>').join('')}</table>`; };
    const draw = () => { $('nl').innerHTML = `<div style="padding:4px 6px;font-weight:600">📗 Atelier_Martin_Ventes.xlsx [3]</div>` + ['Clients', 'Devis', 'Notes'].map(t => `<label class="${pv === t ? 'on' : ''}" data-pv="${t}"><input type="checkbox" data-nk="${t}" ${ck.has(t) ? 'checked' : ''}>▦ ${t}</label>`).join('');
      $('npv').innerHTML = `<div style="padding:6px 8px;font-weight:600;border-bottom:1px solid #e1dfdd">${pv}</div>` + prev(pv);
      $('dlg').querySelectorAll('[data-db]').forEach((b, i) => { if (i < 2) b.disabled = !ck.size; }); };
    dlg('Navigateur', `<div class="nav"><div class="lst" id="nl"></div><div class="pv" id="npv"></div></div>`, [
      ['Charger', () => doLoad([...ck]), 0, 1],
      ['Transformer les données', () => dlg('Power Query – Transformer les données', `<p>Ici s'ouvrirait l'<b>éditeur Power Query</b> : on y nettoie les données <i>avant</i> de les charger (colonnes inutiles, types, valeurs à corriger…). Vous l'utiliserez à la leçon 2.</p><p>Les tables cochées sont déjà propres : revenez au Navigateur et choisissez <b>Charger</b>.</p>`, [['Retour au Navigateur', () => navigator(ck), 0], ['Annuler', closeDlg, 1]]), 1, 1],
      ['Annuler', closeDlg, 1]]);
    $('nl').addEventListener('click', e => { const l = e.target.closest('[data-pv]'); if (l && !e.target.dataset.nk) { pv = l.dataset.pv; draw(); } });
    $('nl').addEventListener('change', e => { const k = e.target.dataset.nk; if (!k) return; e.target.checked ? ck.add(k) : ck.delete(k); pv = k; draw(); });
    draw();
  }
  function doLoad(list) {
    const dup = list.filter(t => S.loaded.includes(t)); list = list.filter(t => !S.loaded.includes(t));
    if (!list.length) { closeDlg(); flash(dup.join(', ') + ' : déjà chargée(s). Rien de nouveau à charger.'); return; }
    dlg('Charger', `<div class="load">Création de connexions dans les tables du modèle<div class="lb"><i></i></div>${list.map(t => `▦ ${t} : ${t === 'Devis' ? D.devis.length : t === 'Clients' ? D.clients.length : 4} lignes chargées`).join('<br>')}</div>`, []);
    setTimeout(() => { list.forEach(t => S.loaded.push(t)); S.loaded.sort((a, b) => ['Clients', 'Devis', 'Notes'].indexOf(a) - ['Clients', 'Devis', 'Notes'].indexOf(b)); S.view = 'R'; closeDlg(); changed();
      flash(list.join(' et ') + ' : chargée(s). Les colonnes apparaissent dans le volet Données, à droite.'); }, 1300);
  }
  function refresh() {
    if (!S.loaded.length) return;
    dlg('Actualiser', `<div class="load">Actualisation des données depuis Atelier_Martin_Ventes.xlsx<div class="lb"><i></i></div></div>`, []);
    setTimeout(() => { closeDlg(); if (S.event && !S.refreshed) { S.refreshed = true; changed(); flash(`Actualisation terminée : la table Devis compte maintenant ${D.devis.length + D.nouveaux.length} lignes.`); }
      else { S.refreshed = S.refreshed; changed(); flash('Actualisation terminée : les données sont déjà à jour.'); } }, 1100);
  }
  let ft; function flash(m) { const f = $('flash'); f.textContent = m; f.style.display = 'block'; clearTimeout(ft); ft = setTimeout(() => f.style.display = 'none', 4200); }
  function karim(msg) { const k = $('karim'); k.innerHTML = `<b>💬 Karim</b>${msg}<br><button class="b" onclick="this.parentElement.style.display='none'">OK</button>`; k.style.display = 'block'; }

  // ---------- API pour steps.js ----------
  window.PBI = {
    get S() { return S; }, compute, rowsFor, filtersFor, FT, D, devisRows, keyOf, closeDlg, flash, karim, render, changed,
    load(j) { try { const o = JSON.parse(j); if (o && o.vis) S = Object.assign(blank(), o); } catch (e) {} },
    saved() { try { return localStorage.getItem('pbi01'); } catch (e) { return null; } },
    reset() { S = blank(); try { localStorage.removeItem('pbi01'); } catch (e) {} closeDlg(); changed(); },
  };
  setTimeout(render, 0);
})();
