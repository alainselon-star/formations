from playwright.sync_api import sync_playwright
import json, time
from PIL import Image
OUT='/home/claude/pbi/l01/img/'
def st(**k):
    s=dict(loaded=['Clients','Devis'],refreshed=False,event=False,vis=[],sel=None,view='R',xf=None,relSeen=False,ans={},nid=10,tview='Devis'); s.update(k); return s
V=lambda id,type,axe=[],val=[],col=[],lvl=0,pick=[]: dict(id=id,type=type,axe=axe,val=val,col=col,lvl=lvl,pick=pick)
M=[dict(f='Devis.Montant HT',a='sum')]
FULL=[V(1,'carte',val=M),V(2,'barres',['Devis.Commercial'],M),V(3,'courbes',['Devis.Date du devis'],M,lvl=2),V(4,'segment',['Clients.Commune']),V(5,'barres',['Devis.Type de travaux'],M)]
HIDE="aside,#karim,#flash{display:none!important}.app{grid-template-columns:1fr!important}"
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1280,'height':720},device_scale_factor=2)
    pg.goto('file:///home/claude/pbi/atelier/index.html'); pg.add_style_tag(content=HIDE)
    def setS(s): pg.evaluate(f"PBI.load({json.dumps(json.dumps(s))});PBI.changed()"); pg.mouse.move(1,700); time.sleep(0.15)
    def shot(name, sel=None, clip=None):
        if sel: pg.locator(sel).screenshot(path=OUT+name)
        else: pg.screenshot(path=OUT+name, clip=clip)
    # empty
    setS(st(loaded=[])); shot('P01_vide.png')
    # navigator
    pg.click('#bXl'); pg.click('[data-fn]'); pg.click('[data-db="0"]'); pg.click('[data-nk="Devis"]'); pg.click('[data-nk="Clients"]'); pg.click('[data-pv="Devis"]')
    shot('P02_navigateur.png','#dlg'); pg.evaluate('PBI.closeDlg()')
    # full report
    setS(st(vis=FULL)); shot('P03_rapport.png')
    # one card + fields pane, with card selected
    setS(st(vis=[V(1,'barres',['Devis.Commercial'],M)],sel=1)); shot('P04_cocher.png')
    # hierarchie
    setS(st(vis=[V(3,'courbes',['Devis.Date du devis'],M,lvl=0)],sel=3)); shot('P05_annees.png','.vis')
    setS(st(vis=[V(3,'courbes',['Devis.Date du devis'],M,lvl=2)],sel=3)); shot('P06_mois.png','.vis')
    # surbrillance
    setS(st(vis=FULL,xf=dict(vid=5,f='Devis.Type de travaux',k='Salle de bain',lvl=0),sel=5)); shot('P07_surbrillance.png','#page')
    # segment Compiègne
    F2=[dict(v) for v in FULL]; F2[3]=V(4,'segment',['Clients.Commune'],pick=['Compiègne'])
    setS(st(vis=F2)); shot('P08_segment.png','#page')
    # modele
    setS(st(view='M',relOpen=True,relSeen=True)); shot('P09_modele.png')
    # tableau
    setS(st(view='T')); shot('P10_tableau.png')
    b.close()
import os
dims={f:Image.open(OUT+f).size for f in os.listdir(OUT)}
json.dump(dims,open('/home/claude/pbi/l01/dims.json','w')); print(dims)
