#!/usr/bin/env python3
"""SCORM 1.2 de la leçon commentée Power BI. usage: make_scorm_pbi.py <dossier> <num> <titre> <section_id> <player_dir>"""
import sys, os, re, json, subprocess, shutil, zipfile
from pptx import Presentation
d, num, titre, sec, player = sys.argv[1:6]
os.chdir(d)
src = open('build.js', encoding='utf-8').read()
titles = [m.group(1) or m.group(2) for m in re.finditer(
    r"(?:contenu\(|s\.addText\()(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\")(?=,\s*'\d|,\s*\{ placeholder)", src)]
titles = [t.replace("\\'", "'") for t in titles]
shutil.rmtree('sc', ignore_errors=True); os.makedirs('sc/slides')
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', 'scorm_src.pptx'], capture_output=True)
subprocess.run(['pdftoppm', '-r', '160', '-png', 'scorm_src.pdf', 'sc/slides/s'], check=True)
p = Presentation('scorm_src.pptx')
SP = {'NARRATEUR': 'narr', 'SOPHIE': 'sophie', 'KARIM': 'karim'}
REPL = [('Power BI', 'Pauwer B I'), ('TCD', 'T C D'), ('CA ', 'C A '), ('HT', 'H T'), ('Power Query', 'Pauwer Query')]
slides = []; n = len(p.slides)
for i, s in enumerate(p.slides, 1):
    lines = []
    for line in s.notes_slide.notes_text_frame.text.split('\n'):
        k, _, t = line.partition(' : '); t = t.strip(); say = t
        for a, b in REPL: say = say.replace(a, b)
        lines.append({'who': SP[k], 'text': t, 'say': say})
    slides.append({'img': 'slides/s-%02d.png' % i, 'title': titles[i - 1] if i - 1 < len(titles) else '', 'lines': lines})
qs = json.load(open('questions_L%s.json' % num, encoding='utf-8'))
data = {'title': f"Power BI Desktop · Leçon {num} – {titre}", 'slides': slides, 'quizAfter': n - 1, 'questions': qs, 'pass': 75,
        'review': f"Revoyez les diapositives 4 à {n-2}, puis réessayez le quiz.", 'reviewFrom': 3,
        'atelier': f'https://academie-numerique.moodlecloud.com/course/section.php?id={sec}'}
open('sc/data.js', 'w', encoding='utf-8').write('window.LESSON=' + json.dumps(data, ensure_ascii=False) + ';')
shutil.copy(os.path.join(player, 'index.html'), 'sc/index.html')
man = open(os.path.join(player, 'imsmanifest.xml'), encoding='utf-8').read().replace('MD102_L01', f'PBI_L{num}').replace(
    "MD-102 · Leçon 01 – Relier un appareil à l'entreprise", data['title']).replace("Relier un appareil à l'entreprise", titre)
open('sc/imsmanifest.xml', 'w', encoding='utf-8').write(man)
z = f'PowerBI_L{num}_v1.zip'
if os.path.exists(z): os.remove(z)
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, _, files in os.walk('sc'):
        for f in files:
            full = os.path.join(root, f); zf.write(full, os.path.relpath(full, 'sc'))
print('OK', z, n, 'diapos', len(qs), 'questions', len(titles), 'titres')
