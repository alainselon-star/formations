// 1 — Titre
{ const s = P.addSlide({ masterName: 'SOMBRE' });
  s.addText('Du classeur de Karim au premier rapport', { placeholder: 'title' });
  s.addText("Importer un classeur Excel et construire un tableau de bord qui se met à jour", { x: 0.6, y: 2.85, w: 8.8, h: 0.6, fontFace: F, fontSize: 19, italic: true, color: C.blanc });
  s.addText('Power BI Desktop · Leçon 01 · 15 min', { x: 0.6, y: 4.6, w: 6, h: 0.4, fontFace: F, fontSize: 12, color: C.bleuClair });
  s.addNotes("NARRATEUR : Chaque lundi, Karim refait les mêmes tableaux pour Sophie. Dans cette leçon, vous allez importer son classeur Excel dans Power BI Desktop, construire un premier tableau de bord en cochant des cases, et le mettre à jour d'un seul clic."); }

// 2 — Dialogue
{ const s = contenu('Lundi, 8 h : le point de la semaine', '1 · Le besoin',
  "SOPHIE : Chaque lundi, je veux savoir où on en est : le chiffre d'affaires des devis, qui vend quoi, et si l'activité monte ou baisse. Et Julie et Thomas veulent voir leurs communes.\nKARIM : Je refais trois tableaux croisés, je copie les graphiques dans un mail… Deux heures. Et mardi, c'est déjà faux.");
  avatars(s);
  box(s, 4.5, 1.3, 5.0, 2.0, C.clair);
  s.addText([{ text: 'Sophie', options: { bold: true, color: C.acc, breakLine: true } },
    { text: "« Le CA, qui vend quoi, et la tendance. Chaque lundi. »" }],
    { x: 4.7, y: 1.38, w: 4.6, h: 1.85, valign: 'top', fontFace: F, fontSize: 15, color: C.dk });
  box(s, 5.2, 3.5, 4.3, 1.4, C.gris);
  s.addText([{ text: 'Karim', options: { bold: true, color: C.dk, breakLine: true } }, { text: "« Deux heures de copier-coller, faux dès mardi. »" }],
    { x: 5.4, y: 3.55, w: 4.0, h: 1.3, valign: 'top', fontFace: F, fontSize: 15, color: C.dk }); }

// 3 — Solution 1
{ const s = contenu('Solution 1 : tout refaire chaque lundi', '2 · Sans l\'outil',
  "NARRATEUR : Sans l'outil, Karim exporte les devis du logiciel, refait un tableau croisé par commercial, un autre par mois, un autre par commune. Il copie les graphiques dans un mail. Si Julie veut une seule commune, il refait un tableau. Et si trois devis arrivent mardi, tout est à recommencer. Deux heures par semaine, et des chiffres qui vieillissent aussitôt.");
  carte(s, 0.5, 1.2, 2.9, 2.6, C.gris, 'Exporter', 'chaque lundi', 'Copier l\'export dans le classeur, vérifier les lignes.');
  carte(s, 3.55, 1.2, 2.9, 2.6, C.gris, 'Trois TCD', 'à refaire', 'Par commercial, par mois, par commune : un tableau par question.');
  carte(s, 6.6, 1.2, 2.9, 2.6, C.gris, 'Copier-coller', 'dans un mail', 'Une image figée : impossible de filtrer, fausse dès le lendemain.');
  bandeau(s, 4.05, [B('Bilan : ', C.rougeTxt), T('deux heures par semaine, et des chiffres déjà vieux le mardi.')], C.rouge, 0.8); }

// 4 — Comprendre
{ const s = contenu('Power BI Desktop : de la source au rapport', '3 · Comprendre',
  "NARRATEUR : Power BI Desktop est un logiciel gratuit pour Windows. Il ne remplace pas le classeur de Karim : il s'y connecte. Obtenir des données copie les tables du classeur dans le modèle de Power BI. Le rapport, avec ses visuels, se calcule à partir de ce modèle. Le classeur Excel n'est jamais modifié. Et quand il change, un clic suffit pour recharger la copie. Le partage avec l'équipe viendra à la leçon quatorze.");
  const etp = [['Classeur Excel', 'la source, chez Karim', C.gris], ['Obtenir des données', 'copie les tables', C.clair], ['Modèle', 'tables et relations', C.clair], ['Rapport', 'cartes, barres, courbes', C.clair]];
  etp.forEach(([t, st, f], i) => { const x = 0.5 + i * 2.32; carte(s, x, 1.3, 2.0, 1.7, f, t, st, '', i ? C.acc : C.dk);
    if (i < 3) s.addText('→', { x: x + 2.0, y: 1.85, w: 0.32, h: 0.5, align: 'center', fontFace: F, fontSize: 22, bold: true, color: C.mute }); });
  s.addText('🔄 Actualiser : relit la source', { x: 2.6, y: 3.1, w: 6.6, h: 0.4, align: 'center', fontFace: F, fontSize: 13, italic: true, color: C.mute });
  bandeau(s, 3.8, [B('Power BI ne modifie jamais le classeur : '), T('il en garde une copie, qu\'on recharge d\'un clic.')], C.jaune, 0.8); }

// 5 — Obtenir des données
{ const s = contenu('Obtenir des données depuis Excel', '4 · Avec Power BI',
  "NARRATEUR : Dans le ruban Accueil, cliquez sur Classeur Excel, ou sur Obtenir des données, puis Classeur Excel. Choisissez le fichier. Le Navigateur s'ouvre : il liste les feuilles du classeur. Cliquez sur un nom pour voir un aperçu, et cochez seulement ce qui sert : ici, Devis et Clients. La feuille Notes ne contient que du texte libre : on la laisse.");
  pic(s, 'P02_navigateur.png', 0.5, 1.15, 5.6, 3.2, 'Le Navigateur');
  etapes(s, 6.35, 1.15, 3.15, 3.2, ['Accueil → Classeur Excel', 'Choisir le fichier', 'Cliquer sur une feuille : aperçu', 'Cocher Devis et Clients', 'Laisser Notes de côté'], 13);
  bandeau(s, 4.55, [B('Ne cochez que les tables utiles : '), T('chaque table chargée alourdit le modèle.')], C.gris, 0.65); }

// 6 — Charger ou transformer
{ const s = contenu('Charger ou Transformer les données ?', '3 · Comprendre',
  "NARRATEUR : En bas du Navigateur, deux boutons. Charger importe directement les tables cochées. Transformer les données ouvre d'abord l'éditeur Power Query, pour nettoyer : supprimer des colonnes, corriger un type, remplacer des valeurs. Les données de Karim sont propres : on choisit Charger. Power Query sera le sujet de la leçon deux.");
  s.addTable([
    [HD('Bouton'), HD('Ce qu\'il fait'), HD('Quand le choisir')],
    ['Charger', 'importe les tables telles quelles', 'les données sont déjà propres'],
    ['Transformer les données', 'ouvre Power Query avant de charger', 'colonnes en trop, types faux, valeurs à corriger'],
    ['Annuler', 'ne fait rien', 'mauvais fichier']],
    Object.assign({ x: 0.5, y: 1.2, w: 9.0, colW: [2.6, 3.2, 3.2], fontSize: 14, rowH: 0.62 }, TB));
  bandeau(s, 4.0, [B('Le doute ? '), T('Transformer les données ne coûte rien : on regarde, puis Fermer et appliquer.')], C.jaune, 0.75); }

// 7 — Trois vues
{ const s = contenu('Trois vues pour un même fichier', '3 · Comprendre',
  "NARRATEUR : Tout à gauche, trois icônes. La vue Rapport, où l'on construit les visuels. La vue Tableau, qui montre les lignes chargées, pour vérifier. La vue Modèle, qui dessine les tables et leurs relations. Ici, Power BI a relié tout seul Clients et Devis, par la colonne Code client : un client, plusieurs devis.");
  pic(s, 'P09b_modele.png', 0.5, 1.15, 5.4, 3.1, 'La vue Modèle');
  s.addTable([
    [HD('Vue'), HD('Pour…')],
    ['📊 Rapport', 'construire les visuels'],
    ['▦ Tableau', 'vérifier les lignes chargées'],
    ['⛓ Modèle', 'voir les tables et relations']],
    Object.assign({ x: 6.1, y: 1.15, w: 3.4, colW: [1.35, 2.05], fontSize: 12.5, rowH: 0.6 }, TB));
  bandeau(s, 4.4, [B('Relation 1 → * : '), T('un client (1) a plusieurs devis (*). Le filtre va du client vers ses devis.')], C.gris, 0.7); }

// 8 — Cocher un champ
{ const s = contenu('Cocher un champ crée un visuel', '4 · Avec Power BI',
  "NARRATEUR : Dans le volet Données, à droite, cochez Commercial puis Montant HT. Power BI crée un visuel et additionne tout seul les montants par commercial : le symbole sigma signale une colonne de nombres, résumée par défaut en Somme. Un champ texte devient des catégories. Choisissez le type de visuel dans le volet Visualisations, et décochez un champ pour le retirer.");
  pic(s, 'P04b_cocher.png', 0.5, 1.1, 9.0, 2.75, 'Volet Données');
  bandeau(s, 4.15, [B('Un texte '), T('→ des catégories.   '), B('Σ Un nombre '), T('→ additionné (Somme).   '), B('Décocher '), T('→ retire le champ.')], C.jaune, 0.7); }

// 9 — Le bon visuel
{ const s = contenu('Le bon visuel pour la bonne question', '4 · Avec Power BI',
  "NARRATEUR : Chaque question de Sophie a son visuel. Un seul chiffre, le chiffre d'affaires : la carte. Comparer les commerciaux : un graphique à barres. Suivre l'évolution dans le temps : un graphique en courbes. Laisser Julie et Thomas filtrer eux-mêmes : un segment. Et pour le détail ligne par ligne : une table.");
  s.addTable([
    [HD('Question de Sophie'), HD('Visuel'), HD('Champs')],
    ['Combien, au total ?', 'Carte', 'Montant HT'],
    ['Qui vend le plus ?', 'Graphique à barres', 'Commercial + Montant HT'],
    ['Ça monte ou ça baisse ?', 'Graphique en courbes', 'Date du devis + Montant HT'],
    ['Seulement Compiègne ?', 'Segment', 'Commune (table Clients)'],
    ['Le détail ?', 'Table', 'les colonnes utiles']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.0, 2.8, 3.2], fontSize: 14, rowH: 0.58 }, TB)); }

// 10 — Dates
{ const s = contenu('Les dates : des années aux mois', '4 · Avec Power BI',
  "NARRATEUR : Placez Date du devis sur une courbe : Power BI affiche d'abord les années, donc deux points seulement. Il a découpé la date en hiérarchie : année, trimestre, mois, jour. Le bouton à double flèche, en haut du visuel, descend d'un niveau. Deux clics, et l'on voit l'activité mois par mois.");
  pic(s, 'P05_annees.png', 0.6, 1.15, 3.6, 3.0, 'Par année');
  s.addText('⇊ ⇊', { x: 4.3, y: 2.25, w: 1.0, h: 0.6, align: 'center', fontFace: F, fontSize: 22, bold: true, color: C.acc });
  pic(s, 'P06_mois.png', 5.4, 1.15, 3.6, 3.0, 'Par mois');
  bandeau(s, 4.35, [B('Année → Trimestre → Mois → Jour : '), T('⇊ descend d\'un niveau, ↑ remonte.')], C.jaune, 0.7); }

// 11 — Filtrage croisé
{ const s = contenu('Un clic filtre toute la page', '4 · Avec Power BI',
  "NARRATEUR : Cliquez sur la barre Salle de bain. Les autres graphiques à barres mettent en surbrillance la part des salles de bain : la barre de Julie garde sa longueur totale, sa partie foncée montre ses salles de bain. La carte et la courbe, elles, se filtrent. C'est le filtrage croisé. Recliquez sur la barre pour tout libérer.");
  pic(s, 'P07_surbrillance.png', 0.5, 1.15, 4.9, 3.5, 'Filtrage croisé');
  carte(s, 5.65, 1.15, 3.85, 1.65, C.clair, 'Mise en surbrillance', 'graphiques à barres', 'Partie foncée = la sélection, partie claire = le reste.', C.acc);
  carte(s, 5.65, 3.0, 3.85, 1.65, C.gris, 'Filtre', 'carte, courbe, table', 'Le visuel ne montre plus que la sélection.'); }

// 12 — Segment
{ const s = contenu('Le segment : chacun filtre sa page', '4 · Avec Power BI',
  "NARRATEUR : Pour Julie et Thomas, un segment avec la commune. La commune est dans la table Clients, pas dans Devis. Pourtant, cochez Compiègne : la carte, les barres et la courbe ne montrent plus que les devis des clients de Compiègne. C'est la relation par Code client qui transmet le filtre, des clients vers leurs devis.");
  pic(s, 'P08_segment.png', 0.5, 1.15, 4.9, 3.5, 'Segment Commune');
  puces(s, 5.7, 1.15, 3.8, 3.5, ['Visuel Segment + Clients → Commune', 'Cocher une ou plusieurs communes', 'Tous les visuels de la page suivent', 'Le filtre passe par la relation Code client'], 14); }

// 13 — Actualiser
{ const s = contenu('Actualiser : un clic, des chiffres à jour', '4 · Avec Power BI',
  "NARRATEUR : Mardi, Karim ajoute huit devis dans le classeur Excel. Le rapport ne les voit pas encore : il travaille sur la copie faite au chargement. Accueil, Actualiser : Power BI relit le classeur, rejoue le chargement, et tous les visuels se recalculent. Rien à reconstruire.");
  carte(s, 0.5, 1.2, 2.9, 2.5, C.gris, 'Mardi', 'dans Excel', 'Karim ajoute 8 devis au classeur.');
  carte(s, 3.55, 1.2, 2.9, 2.5, C.gris, 'Le rapport', 'avant', 'Toujours 188 devis : la copie date du chargement.');
  carte(s, 6.6, 1.2, 2.9, 2.5, C.clair, 'Actualiser', 'Accueil', '196 devis : carte, barres et courbe recalculées.', C.acc);
  bandeau(s, 4.0, [B('Le classeur reste la source : '), T('on corrige dans Excel, puis on actualise dans Power BI.')], C.jaune, 0.75); }

// 14 — Avant / maintenant
{ const s = contenu('Avant / maintenant', '5 · À retenir',
  "NARRATEUR : Avant : trois tableaux croisés refaits chaque lundi, des images copiées dans un mail, deux heures de travail. Maintenant : un rapport construit une fois, qu'on filtre d'un clic et qu'on met à jour avec Actualiser.");
  s.addTable([
    [HD('Besoin'), HD('Avant (Excel)'), HD('Maintenant (Power BI)')],
    ['Les chiffres de la semaine', 'refaire 3 TCD', 'Actualiser'],
    ['Une seule commune', 'un TCD de plus', 'un clic dans le segment'],
    ['Partager', 'images dans un mail', 'le rapport (leçon 14)'],
    ['Temps passé', '2 h chaque lundi', 'quelques secondes']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [2.8, 3.0, 3.2], fontSize: 15, rowH: 0.62 }, TB)); }

// 15 — À retenir
{ const s = contenu('À retenir', '5 · À retenir',
  "NARRATEUR : Retenez. Obtenir des données copie les tables utiles du classeur ; Charger si elles sont propres, Transformer sinon. Trois vues : Rapport, Tableau, Modèle. Cocher un champ crée un visuel, et un nombre est additionné. Un clic dans un visuel filtre ou met en surbrillance les autres. Le segment filtre toute la page. Et Actualiser recharge la source, sans jamais la modifier.");
  s.addTable([
    [HD('Geste'), HD('Où')],
    ['Importer un classeur', 'Accueil → Classeur Excel → Navigateur'],
    ['Données propres / à nettoyer', 'Charger / Transformer les données'],
    ['Créer un visuel', 'cocher des champs dans le volet Données'],
    ['Voir mois par mois', '⇊ en haut du visuel'],
    ['Filtrer la page', 'clic dans un visuel, ou un segment'],
    ['Mettre à jour', 'Accueil → Actualiser']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.4, 5.6], fontSize: 14, rowH: 0.55 }, TB)); }

// 16 — Fin
{ const s = P.addSlide({ masterName: 'SOMBRE' });
  s.addText('Le tableau de bord du lundi est prêt', { placeholder: 'title' });
  s.addText("Vous savez importer un classeur, construire des visuels en cochant des champs, filtrer d'un clic et actualiser. Passez à l'atelier : le classeur de Karim vous attend.",
    { x: 0.6, y: 2.85, w: 8.8, h: 1.0, valign: 'top', fontFace: F, fontSize: 18, color: C.blanc });
  if (!SCORM) {
    s.addShape(P.shapes.ROUNDED_RECTANGLE, { x: 0.6, y: 4.2, w: 3.6, h: 0.7, fill: { color: C.or }, line: { color: C.or }, rectRadius: 0.1 });
    s.addText("Passer à l'atelier →", { x: 0.6, y: 4.2, w: 3.6, h: 0.7, align: 'center', valign: 'middle', fontFace: F, fontSize: 15, bold: true, color: C.dk }); }
  s.addNotes("SOPHIE : Le lundi, j'ouvre le rapport, et c'est tout.\nKARIM : Et moi, je clique sur Actualiser.\nNARRATEUR : Bravo. Passez maintenant à l'atelier."); }

P.writeFile({ fileName: __dirname + (SCORM ? '/scorm_src.pptx' : '/PowerBI_L01_Premier_rapport.pptx') }).then(f => console.log('OK', f));
