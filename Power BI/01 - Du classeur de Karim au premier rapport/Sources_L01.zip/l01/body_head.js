const SCORM = process.env.SCORM === '1';
function avatars(s) {
  box(s, 0.5, 1.3, 3.6, 3.8, C.gris);
  s.addShape(P.shapes.OVAL, { x: 0.85, y: 1.75, w: 1.3, h: 1.3, fill: { color: C.acc }, line: { color: C.acc } });
  s.addText('S', { x: 0.85, y: 1.75, w: 1.3, h: 1.3, align: 'center', valign: 'middle', fontFace: F, fontSize: 40, bold: true, color: C.blanc });
  s.addText([{ text: 'Sophie', options: { bold: true, breakLine: true } }, { text: 'la gérante', options: { fontSize: 11, color: C.mute } }], { x: 0.6, y: 3.15, w: 1.8, h: 0.6, align: 'center', fontFace: F, fontSize: 14, color: C.dk });
  s.addShape(P.shapes.OVAL, { x: 2.45, y: 2.55, w: 1.3, h: 1.3, fill: { color: C.or }, line: { color: C.or } });
  s.addText('K', { x: 2.45, y: 2.55, w: 1.3, h: 1.3, align: 'center', valign: 'middle', fontFace: F, fontSize: 40, bold: true, color: C.dk });
  s.addText([{ text: 'Karim', options: { bold: true, breakLine: true } }, { text: "l'administratif", options: { fontSize: 11, color: C.mute } }], { x: 2.2, y: 3.95, w: 1.8, h: 0.6, align: 'center', fontFace: F, fontSize: 14, color: C.dk });
}
const HD = (t) => ({ text: t, options: { bold: true, color: C.blanc, fill: { color: C.acc } } });
const TB = { fontFace: F, color: C.dk, border: { type: 'solid', pt: 0.75, color: 'C9D3DD' }, valign: 'middle' };

