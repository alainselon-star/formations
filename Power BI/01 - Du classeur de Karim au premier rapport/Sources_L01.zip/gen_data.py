import random, json, datetime as dt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
random.seed(2026)
COM = [("Compiègne","60200","Oise",9),("Margny-lès-Compiègne","60280","Oise",4),("Pierrefonds","60350","Oise",3),("Noyon","60400","Oise",3),
       ("Clermont","60600","Oise",2),("Senlis","60300","Oise",3),("Crépy-en-Valois","60800","Oise",3),("Chantilly","60500","Oise",2),
       ("Lacroix-Saint-Ouen","60610","Oise",3),("Thourotte","60150","Oise",2),("Soissons","02200","Aisne",1),("Villers-Cotterêts","02600","Aisne",1),("Roye","80700","Somme",1)]
NOMS = ["Lambert","Dupont","Moreau","Lefèvre","Garnier","Faure","Rousseau","Blanc","Guérin","Muller","Henry","Roussel","Nicolas","Perrin","Morin",
        "Mathieu","Clément","Gauthier","Dumont","Lopez","Fontaine","Chevalier","Robin","Masson","Sanchez","Gérard","Nguyen","Boyer","Denis","Lemaire",
        "Duval","Joly","Gautier","Roger","Roche","Roy","Noël","Meyer","Lucas","Meunier","Jean","Perez","Marchand","Dufour","Blanchard"]
TYPES = {"Salle de bain":(6000,18000),"Cuisine":(8000,24000),"Toiture":(9000,38000),"Isolation":(4000,15000),"Peinture":(1500,6500),"Menuiserie":(2000,12000)}
TW = [24,18,10,16,18,14]
COMMS = [("Julie",5),("Thomas",4),("Sophie",2)]
clients=[]
pool=[c for c in COM for _ in range(c[3])]
for i,n in enumerate(NOMS,1):
    c=random.choice(pool)
    clients.append(dict(code=f"C{i:03d}",nom=("SCI " if i%11==0 else "")+n,commune=c[0],cp=c[1],dep=c[2]))
def devis(n0, d0, d1, k, pending=False):
    out=[]; span=(d1-d0).days
    dates=sorted(d0+dt.timedelta(days=random.randint(0,span)) for _ in range(k))
    for j,d in enumerate(dates):
        while d.weekday()>4: d-=dt.timedelta(days=1)
        t=random.choices(list(TYPES),TW)[0]; lo,hi=TYPES[t]
        m=round(random.uniform(lo,hi)/10)*10
        age=(dt.date(2026,11,13)-d).days
        st=random.choices(["Signé","Refusé","En attente"],[58,22,20] if age>60 else [25,10,65])[0]
        sig=(d+dt.timedelta(days=random.randint(5,40))) if st=="Signé" else None
        if sig and sig>dt.date(2026,11,13): sig=None; st="En attente"
        out.append(dict(num=f"D-{d.year}-{n0+j:03d}" ,date=d,code=random.choice(clients)["code"],com=random.choices([c for c,_ in COMMS],[w for _,w in COMMS])[0],type=t,mt=m,st=st,sig=sig))
    return out
D25=devis(1,dt.date(2025,1,6),dt.date(2025,12,19),96)
D26=devis(1,dt.date(2026,1,5),dt.date(2026,11,6),92)
for i,x in enumerate(D25,1): x['num']=f"D-2025-{i:03d}"
for i,x in enumerate(D26,1): x['num']=f"D-2026-{i:03d}"
NEW=devis(93,dt.date(2026,11,9),dt.date(2026,11,13),8)
for i,x in enumerate(NEW,93): x['num']=f"D-2026-{i:03d}"; x['st']="En attente"; x['sig']=None
ALL=D25+D26
# Excel pour la pratique dans Power BI Desktop
wb=Workbook(); ws=wb.active; ws.title="Devis"
H=["N° devis","Date du devis","Code client","Commercial","Type de travaux","Montant HT","Statut","Date de signature"]
ws.append(H)
for x in ALL: ws.append([x['num'],x['date'],x['code'],x['com'],x['type'],x['mt'],x['st'],x['sig']])
for r in ws.iter_rows(min_row=2):
    r[1].number_format=r[7].number_format='DD/MM/YYYY'; r[5].number_format='#,##0 €'
c=wb.create_sheet("Clients"); c.append(["Code client","Client","Commune","Code postal","Département"])
for x in clients: c.append([x['code'],x['nom'],x['commune'],x['cp'],x['dep']])
for r in c.iter_rows(min_row=2): r[3].number_format='@'
n=wb.create_sheet("Notes")
for l in ["Notes de Karim – ne pas importer","Export du logiciel de devis, mis à jour chaque lundi.","Les montants sont hors taxes.","À faire : relancer les devis en attente de plus de 30 jours."]: n.append([l])
for s in (ws,c):
    for cell in s[1]: cell.font=Font(bold=True,color="FFFFFF"); cell.fill=PatternFill("solid",fgColor="1F3864")
    for col,w in zip("ABCDEFGH",[13,14,12,12,16,12,12,16]): s.column_dimensions[col].width=w
    s.freeze_panes="A2"
n.column_dimensions['A'].width=70
wb.save("/home/claude/pbi/PowerBI_01_Atelier_Martin_Ventes.xlsx")
iso=lambda d: d.isoformat() if d else None
J=dict(devis=[[x['num'],iso(x['date']),x['code'],x['com'],x['type'],x['mt'],x['st'],iso(x['sig'])] for x in ALL],
       nouveaux=[[x['num'],iso(x['date']),x['code'],x['com'],x['type'],x['mt'],x['st'],iso(x['sig'])] for x in NEW],
       clients=[[x['code'],x['nom'],x['commune'],x['cp'],x['dep']] for x in clients])
open("/home/claude/pbi/atelier/data.js","w").write("window.PBD="+json.dumps(J,ensure_ascii=False)+";")
import collections
tot=sum(x['mt'] for x in ALL); print(len(ALL),'devis',tot)
print(collections.Counter(x['st'] for x in ALL)); 
cc=collections.defaultdict(int)
for x in ALL: cc[x['com']]+=x['mt']
print(dict(cc))
cm={c['code']:c for c in clients}; print(collections.Counter(cm[x['code']]['commune'] for x in ALL).most_common(5))
print('Julie SdB', sum(x['mt'] for x in ALL if x['com']=='Julie' and x['type']=='Salle de bain'), 'new', sum(x['mt'] for x in NEW))
