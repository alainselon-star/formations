// Mini moteur de formules Excel (français, séparateur ;) — Académie numérique
(function () {
  'use strict';
  const ERR = e => ({ err: e });
  const isErr = v => v && typeof v === 'object' && 'err' in v;
  const isRange = v => v && typeof v === 'object' && 'r1' in v;
  const EPOCH = Date.UTC(1899, 11, 30);
  function serialToParts(n) {
    n = Math.floor(n);
    if (n === 60) return { y: 1900, m: 2, d: 29 };
    const t = n < 60 ? Date.UTC(1899, 11, 31) + n * 864e5 : EPOCH + n * 864e5;
    const d = new Date(t);
    return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate(), wd: d.getUTCDay() };
  }
  function partsToSerial(y, m, d) { // m 1-based, overflow ok
    const t = Date.UTC(y, m - 1, d);
    let s = Math.round((t - EPOCH) / 864e5);
    if (s < 61) s -= 1; // bogue 1900 d'Excel
    return s;
  }
  function todaySerial() { const d = new Date(); return partsToSerial(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function weekday(n) { const p = serialToParts(n); return p.wd === undefined ? 0 : p.wd; }

  // ---------- références ----------
  const colToNum = s => s.toUpperCase().split('').reduce((a, ch) => a * 26 + ch.charCodeAt(0) - 64, 0) - 1;
  const numToCol = n => { let s = ''; n++; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const REFRE = /^(?:('(?:[^']|'')+'|[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*)!)?(\$?)([A-Za-z]{1,3})(\$?)(\d+)(?::(\$?)([A-Za-z]{1,3})(\$?)(\d+))?/;

  // ---------- lexer ----------
  function tokenize(src) {
    const t = []; let i = 0;
    while (i < src.length) {
      const ch = src[i];
      if (ch === ' ') { i++; continue; }
      if (ch === '"') { let j = i + 1, s = ''; while (j < src.length) { if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j += 2; continue; } break; } s += src[j++]; } if (j >= src.length) throw 'syntax'; t.push({ k: 'str', v: s }); i = j + 1; continue; }
      const rest = src.slice(i);
      let m = rest.match(/^\d+(?:,\d+)?(?:[eE][+-]?\d+)?/);
      if (m && !/^[A-Za-z]/.test(rest.slice(m[0].length)) ) { t.push({ k: 'num', v: parseFloat(m[0].replace(',', '.')) }); i += m[0].length; continue; }
      m = rest.match(REFRE);
      if (m && !/^[\w(.]/.test(rest.slice(m[0].length)) && !(m[1] === undefined && /^[A-Za-z]{1,3}\d+[A-Za-z.]/.test(rest))) {
        let sheet = m[1]; if (sheet && sheet[0] === "'") sheet = sheet.slice(1, -1).replace(/''/g, "'");
        const r = { k: 'ref', sheet: sheet || null, c1: colToNum(m[3]), r1: +m[5] - 1 };
        if (m[7]) { r.c2 = colToNum(m[7]); r.r2 = +m[9] - 1; } else { r.c2 = r.c1; r.r2 = r.r1; }
        t.push(r); i += m[0].length; continue;
      }
      m = rest.match(/^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*/);
      if (m) {
        const name = m[0].toUpperCase(); i += m[0].length;
        if (src[i] === '(') { t.push({ k: 'fn', v: name }); i++; }
        else if (name === 'VRAI' || name === 'FAUX') t.push({ k: 'bool', v: name === 'VRAI' });
        else t.push({ k: 'name', v: name });
        continue;
      }
      m = rest.match(/^(<=|>=|<>|[-+*/^&=<>%();:])/);
      if (m) { t.push({ k: 'op', v: m[0] }); i += m[0].length; continue; }
      if (ch === ',') throw 'comma';
      throw 'syntax';
    }
    return t;
  }

  // ---------- parser ----------
  function parse(src) {
    const t = tokenize(src); let p = 0;
    const peek = () => t[p], next = () => t[p++];
    const isOp = (v) => t[p] && t[p].k === 'op' && t[p].v === v;
    function cmp() { let a = cat(); while (t[p] && t[p].k === 'op' && ['=', '<>', '<', '>', '<=', '>='].includes(t[p].v)) { const o = next().v; a = { k: 'bin', o, a, b: cat() }; } return a; }
    function cat() { let a = add(); while (isOp('&')) { next(); a = { k: 'bin', o: '&', a, b: add() }; } return a; }
    function add() { let a = mul(); while (isOp('+') || isOp('-')) { const o = next().v; a = { k: 'bin', o, a, b: mul() }; } return a; }
    function mul() { let a = pow(); while (isOp('*') || isOp('/')) { const o = next().v; a = { k: 'bin', o, a, b: pow() }; } return a; }
    function pow() { let a = un(); while (isOp('^')) { next(); a = { k: 'bin', o: '^', a, b: un() }; } return a; }
    function un() { if (isOp('-')) { next(); return { k: 'neg', a: un() }; } if (isOp('+')) { next(); return un(); } let a = prim(); while (isOp('%')) { next(); a = { k: 'pct', a }; } return a; }
    function prim() {
      const x = next(); if (!x) throw 'syntax';
      if (x.k === 'num' || x.k === 'str' || x.k === 'bool') return { k: 'lit', v: x.v };
      if (x.k === 'ref') return x;
      if (x.k === 'name') return { k: 'badname', v: x.v };
      if (x.k === 'fn') {
        const args = [];
        if (isOp(')')) { next(); return { k: 'fn', v: x.v, args }; }
        while (true) {
          if (isOp(';') || isOp(')')) args.push({ k: 'empty' }); else args.push(cmp());
          if (isOp(';')) { next(); continue; }
          if (isOp(')')) { next(); break; }
          throw 'syntax';
        }
        return { k: 'fn', v: x.v, args };
      }
      if (x.k === 'op' && x.v === '(') { const a = cmp(); if (!isOp(')')) throw 'syntax'; next(); return a; }
      throw 'syntax';
    }
    const ast = cmp(); if (p < t.length) throw 'syntax'; return ast;
  }

  // ---------- évaluation ----------
  function makeEvaluator(wb) {
    const memo = new Map(), busy = new Set();
    const sheetIdx = name => { if (name == null) return -1; const i = wb.sheets.findIndex(s => s.name.toLowerCase() === name.toLowerCase()); return i; };
    function cellValue(si, r, c) {
      const key = si + ':' + r + ':' + c;
      if (memo.has(key)) return memo.get(key);
      const cell = wb.sheets[si].cells[numToCol(c) + (r + 1)];
      if (!cell || cell.raw === undefined || cell.raw === '') return null;
      if (cell.ast === undefined) return cell.v;
      if (busy.has(key)) return ERR('#REF!');
      busy.add(key);
      let v; try { v = ev(cell.ast, si); } catch (e) { v = ERR('#VALEUR!'); }
      busy.delete(key);
      if (isRange(v)) v = v.r1 === v.r2 && v.c1 === v.c2 ? cellValue(v.si, v.r1, v.c1) : ERR('#VALEUR!');
      if (v === null) v = 0;
      if (typeof v === 'number' && !isFinite(v)) v = ERR('#NOMBRE!');
      memo.set(key, v); return v;
    }
    const num = v => {
      if (isErr(v)) throw v; if (v === null || v === undefined) return 0; if (typeof v === 'number') return v; if (typeof v === 'boolean') return v ? 1 : 0;
      const d = parseText(String(v)); if (typeof d.v === 'number') return d.v; throw ERR('#VALEUR!');
    };
    const str = v => { if (isErr(v)) throw v; if (v === null) return ''; if (typeof v === 'boolean') return v ? 'VRAI' : 'FAUX'; if (typeof v === 'number') return fmtGeneral(v); return String(v); };
    const scalar = (v) => isRange(v) ? (v.r1 === v.r2 && v.c1 === v.c2 ? cellValue(v.si, v.r1, v.c1) : ERR('#VALEUR!')) : v;
    function* cells(v) { if (isRange(v)) { for (let r = v.r1; r <= v.r2; r++) for (let c = v.c1; c <= v.c2; c++) yield { v: cellValue(v.si, r, c), fromRange: true }; } else yield { v, fromRange: false }; }
    function nums(args, si) { const out = []; for (const a of args) { const v = ev(a, si); for (const x of cells(v)) { if (isErr(x.v)) throw x.v; if (x.fromRange) { if (typeof x.v === 'number') out.push(x.v); } else if (x.v !== null) out.push(num(x.v)); } } return out; }
    function crit(c) {
      c = c === null ? '' : c; let op = '=', val = c;
      if (typeof c === 'string') { const m = c.match(/^(<=|>=|<>|=|<|>)(.*)$/); if (m) { op = m[1]; val = m[2]; } const pn = parseText(val); if (typeof pn.v === 'number' && val !== '') val = pn.v; }
      return x => {
        if (typeof val === 'number') { if (typeof x !== 'number') return op === '<>'; return { '=': x === val, '<>': x !== val, '<': x < val, '>': x > val, '<=': x <= val, '>=': x >= val }[op]; }
        const s = x === null ? '' : str(x).toLowerCase(), v2 = String(val).toLowerCase();
        const re = new RegExp('^' + v2.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$');
        if (op === '=') return re.test(s); if (op === '<>') return !re.test(s);
        return { '<': s < v2, '>': s > v2, '<=': s <= v2, '>=': s >= v2 }[op];
      };
    }
    const F = {
      SOMME: (a, si) => nums(a, si).reduce((x, y) => x + y, 0),
      MOYENNE: (a, si) => { const n = nums(a, si); if (!n.length) throw ERR('#DIV/0!'); return n.reduce((x, y) => x + y, 0) / n.length; },
      MAX: (a, si) => { const n = nums(a, si); return n.length ? Math.max(...n) : 0; },
      MIN: (a, si) => { const n = nums(a, si); return n.length ? Math.min(...n) : 0; },
      NB: (a, si) => { let k = 0; for (const x of a) for (const c of cells(ev(x, si))) if (typeof c.v === 'number') k++; return k; },
      NBVAL: (a, si) => { let k = 0; for (const x of a) for (const c of cells(ev(x, si))) if (c.v !== null && c.v !== '') k++; return k; },
      'NB.SI': (a, si) => { const r = ev(a[0], si), f = crit(scalar(ev(a[1], si))); let k = 0; for (const c of cells(r)) if (!isErr(c.v) && f(c.v)) k++; return k; },
      'SOMME.SI': (a, si) => { const r = ev(a[0], si), f = crit(scalar(ev(a[1], si))); const s = a[2] ? ev(a[2], si) : r; let t = 0; if (!isRange(r)) throw ERR('#VALEUR!');
        for (let i = 0; i <= r.r2 - r.r1; i++) for (let j = 0; j <= r.c2 - r.c1; j++) { const v = cellValue(r.si, r.r1 + i, r.c1 + j); if (f(v)) { const w = isRange(s) ? cellValue(s.si, s.r1 + i, s.c1 + j) : null; if (typeof w === 'number') t += w; } } return t; },
      SI: null,
      ET: (a, si) => a.every(x => num(scalar(ev(x, si))) !== 0),
      OU: (a, si) => a.some(x => num(scalar(ev(x, si))) !== 0),
      NON: (a, si) => num(scalar(ev(a[0], si))) === 0,
      ABS: (a, si) => Math.abs(num(scalar(ev(a[0], si)))),
      ARRONDI: (a, si) => { const n = num(scalar(ev(a[0], si))), d = a[1] ? num(scalar(ev(a[1], si))) : 0, f = Math.pow(10, d); return Math.round(n * f) / f; },
      ENT: (a, si) => Math.floor(num(scalar(ev(a[0], si)))),
      AUJOURDHUI: () => todaySerial(),
      MAINTENANT: () => { const d = new Date(); return todaySerial() + (d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds()) / 86400; },
      ANNEE: (a, si) => serialToParts(num(scalar(ev(a[0], si)))).y,
      MOIS: (a, si) => serialToParts(num(scalar(ev(a[0], si)))).m,
      JOUR: (a, si) => serialToParts(num(scalar(ev(a[0], si)))).d,
      DATE: (a, si) => partsToSerial(num(scalar(ev(a[0], si))), num(scalar(ev(a[1], si))), num(scalar(ev(a[2], si)))),
      JOURSEM: (a, si) => { const w = weekday(num(scalar(ev(a[0], si)))), t = a[1] ? num(scalar(ev(a[1], si))) : 1; if (t === 2) return w === 0 ? 7 : w; if (t === 3) return w === 0 ? 6 : w - 1; return w + 1; },
      'MOIS.DECALER': (a, si) => { const p = serialToParts(num(scalar(ev(a[0], si)))), n = Math.trunc(num(scalar(ev(a[1], si)))); const last = new Date(Date.UTC(p.y, p.m - 1 + n + 1, 0)).getUTCDate(); return partsToSerial(p.y, p.m + n, Math.min(p.d, last)); },
      'FIN.MOIS': (a, si) => { const p = serialToParts(num(scalar(ev(a[0], si)))), n = Math.trunc(num(scalar(ev(a[1], si)))); return partsToSerial(p.y, p.m + n + 1, 0); },
      'NB.JOURS.OUVRES': (a, si) => { let s = Math.floor(num(scalar(ev(a[0], si)))), e = Math.floor(num(scalar(ev(a[1], si)))); const hol = new Set(a[2] ? nums([a[2]], si).map(Math.floor) : []); let sign = 1; if (s > e) { [s, e] = [e, s]; sign = -1; } let k = 0; for (let d = s; d <= e; d++) { const w = weekday(d); if (w !== 0 && w !== 6 && !hol.has(d)) k++; } return k * sign; },
      DATEDIF: (a, si) => { const s = num(scalar(ev(a[0], si))), e = num(scalar(ev(a[1], si))), u = str(scalar(ev(a[2], si))).toUpperCase(); if (s > e) throw ERR('#NOMBRE!'); const p = serialToParts(s), q = serialToParts(e); let m = (q.y - p.y) * 12 + q.m - p.m; if (q.d < p.d) m--; if (u === 'D') return Math.floor(e) - Math.floor(s); if (u === 'M') return m; if (u === 'Y') return Math.floor(m / 12); throw ERR('#NOMBRE!'); },
      CONCAT: (a, si) => { let s = ''; for (const x of a) for (const c of cells(ev(x, si))) s += str(c.v); return s; },
      MAJUSCULE: (a, si) => str(scalar(ev(a[0], si))).toUpperCase(),
    };
    F.CONCATENER = F.CONCAT;
    function ev(n, si) {
      switch (n.k) {
        case 'lit': return n.v;
        case 'empty': return null;
        case 'badname': return ERR('#NOM?');
        case 'ref': { const s = n.sheet == null ? si : sheetIdx(n.sheet); if (s < 0) return ERR('#REF!'); const r = { si: s, r1: Math.min(n.r1, n.r2), r2: Math.max(n.r1, n.r2), c1: Math.min(n.c1, n.c2), c2: Math.max(n.c1, n.c2) }; return r; }
        case 'neg': return -num(scalar(ev(n.a, si)));
        case 'pct': return num(scalar(ev(n.a, si))) / 100;
        case 'bin': {
          const a = scalar(ev(n.a, si)), b = scalar(ev(n.b, si));
          if (isErr(a)) return a; if (isErr(b)) return b;
          switch (n.o) {
            case '+': return num(a) + num(b); case '-': return num(a) - num(b); case '*': return num(a) * num(b);
            case '/': { const d = num(b); if (d === 0) return ERR('#DIV/0!'); return num(a) / d; }
            case '^': return Math.pow(num(a), num(b)); case '&': return str(a) + str(b);
            default: {
              let x = a === null ? (typeof b === 'string' ? '' : 0) : a, y = b === null ? (typeof a === 'string' ? '' : 0) : b;
              let c;
              if (typeof x === 'string' && typeof y === 'string') { x = x.toLowerCase(); y = y.toLowerCase(); c = x < y ? -1 : x > y ? 1 : 0; }
              else if (typeof x === 'string') c = 1; else if (typeof y === 'string') c = -1; else { x = num(x); y = num(y); c = x < y ? -1 : x > y ? 1 : 0; }
              return { '=': c === 0, '<>': c !== 0, '<': c < 0, '>': c > 0, '<=': c <= 0, '>=': c >= 0 }[n.o];
            }
          }
        }
        case 'fn': {
          if (n.v === 'SI') { const c = scalar(ev(n.args[0], si)); if (isErr(c)) return c; const t = num(c) !== 0; const br = t ? n.args[1] : n.args[2]; if (!br) return t ? true : false; if (br.k === 'empty') return 0; return ev(br, si); }
          const f = F[n.v]; if (!f) return ERR('#NOM?');
          try { return f(n.args, si); } catch (e) { if (isErr(e)) return e; return ERR('#VALEUR!'); }
        }
      }
      return ERR('#VALEUR!');
    }
    return { cellValue, reset: () => memo.clear() };
  }

  // ---------- saisie ----------
  function parseText(s) {
    const t = s.trim();
    if (t === '') return { v: null };
    let m = t.match(/^(\d{1,2})[/-](\d{1,2})(?:[/-](\d{2,4}))?$/);
    if (m) { let y = m[3] ? +m[3] : new Date().getFullYear(); if (m[3] && m[3].length === 2) y += y < 30 ? 2000 : 1900; const d = +m[1], mo = +m[2];
      if (mo >= 1 && mo <= 12 && d >= 1 && d <= 31) return { v: partsToSerial(y, mo, d), fmt: 'date' }; }
    m = t.replace(/[\s  ]/g, '').match(/^(-?\d+(?:,\d+)?)(€|%)?$/);
    if (m) { let v = parseFloat(m[1].replace(',', '.')); if (m[2] === '%') return { v: v / 100, fmt: 'pct' }; return { v, fmt: m[2] === '€' ? 'eur2' : undefined }; }
    if (/^(vrai|faux)$/i.test(t)) return { v: /^vrai$/i.test(t) };
    return { v: s };
  }

  // ---------- affichage ----------
  function fmtGeneral(v) {
    if (Math.abs(v) >= 1e11 || (Math.abs(v) < 1e-9 && v !== 0)) return v.toExponential(4).replace('.', ',');
    let s = String(+v.toPrecision(10)); return s.replace('.', ',');
  }
  const pad = n => String(n).padStart(2, '0');
  const MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
  const grp = (n, dec) => { const s = Math.abs(n).toFixed(dec).split('.'); s[0] = s[0].replace(/\B(?=(\d{3})+(?!\d))/g, ' '); return (n < 0 ? '-' : '') + s.join(','); };
  function display(v, fmt) {
    if (v === null || v === undefined) return '';
    if (isErr(v)) return v.err;
    if (typeof v === 'boolean') return v ? 'VRAI' : 'FAUX';
    if (typeof v === 'string') return v;
    switch (fmt) {
      case 'date': if (v < 0 || v > 2958465) return '########'; { const p = serialToParts(v); return pad(p.d) + '/' + pad(p.m) + '/' + p.y; }
      case 'dlong': if (v < 0) return '########'; { const p = serialToParts(v); return JOURS[p.wd === undefined ? 0 : p.wd] + ' ' + p.d + ' ' + MOIS[p.m - 1] + ' ' + p.y; }
      case 'eur0': return grp(v, 0) + ' €';
      case 'eur2': return grp(v, 2) + ' €';
      case 'num': return grp(v, 2);
      case 'pct': return grp(v * 100, 0) + ' %';
      default: return fmtGeneral(v);
    }
  }

  // ---------- décalage des références (recopie) ----------
  function shiftFormula(f, dr, dc) {
    let out = '', i = 0;
    while (i < f.length) {
      if (f[i] === '"') { const j = f.indexOf('"', i + 1); const e = j < 0 ? f.length : j + 1; out += f.slice(i, e); i = e; continue; }
      const prev = out.slice(-1);
      if (/[A-Za-z$']/.test(f[i]) && !/[\wÀ-ÿ.]/.test(prev)) {
        const m = f.slice(i).match(REFRE);
        if (m && !/^[\w(.]/.test(f.slice(i + m[0].length))) {
          const one = (d1, col, d2, row) => {
            let c = colToNum(col), r = +row - 1;
            if (!d1) c += dc; if (!d2) r += dr;
            if (c < 0 || r < 0) return '#REF!';
            return d1 + numToCol(c) + d2 + (r + 1);
          };
          let s = (m[1] ? m[1] + '!' : '') + one(m[2], m[3], m[4], m[5]);
          if (m[7]) s += ':' + one(m[6], m[7], m[8], m[9]);
          out += s; i += m[0].length; continue;
        }
        const w = f.slice(i).match(/^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*/); if (w) { out += w[0]; i += w[0].length; continue; }
      }
      out += f[i++];
    }
    return out;
  }

  window.XL = { parse, makeEvaluator, parseText, display, shiftFormula, colToNum, numToCol, todaySerial, serialToParts, partsToSerial, isErr, REFRE };
})();
