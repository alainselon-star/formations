// Étapes, vérifications et suivi SCORM — atelier 17
(function () {
  'use strict';
  const A = XLAPP, D = 0, F = 1;
  const v = (si, ref) => A.val(si, ref), c = (si, ref) => A.cell(si, ref) || {};
  const isF = (si, ref) => c(si, ref).ast !== undefined;
  const raw = (si, ref) => String(c(si, ref).raw || '').toUpperCase().replace(/[\s$]/g, '');
  const fmt = (si, ref) => c(si, ref).f || 'gen';
  const isDate = f => f === 'date' || f === 'dlong';
  const today = A.todaySerial();
  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });

  const MOY = { lu: (() => { try { return localStorage.getItem('xl17-moy') === '1'; } catch (e) { return false; } })() };
  const STEPS = [
    { t: 'Le délai de signature', go: [D, 'D2'],
      mission: 'Sophie veut savoir combien de jours chaque client a mis à signer son devis. Feuille <b>Devis signés</b> : calculez ce délai en D2, pour le premier devis.',
      h: ['Pour Excel, une date est un nombre de jours. On peut donc faire une opération entre deux dates.', 'Le délai, c\'est la date la plus récente moins la plus ancienne. Après le signe =, cliquez sur les cellules plutôt que de taper leurs références.'],
      sol: '<code>=C2-B2</code>, puis Entrée.',
      check() { if (!isF(D, 'D2')) return KO('D2 doit contenir un calcul, qui commence par =.'); const x = v(D, 'D2');
        if (x === -33) return KO('Le résultat est négatif : vous avez soustrait dans le mauvais ordre.');
        if (x !== 33) return KO('Le résultat n\'est pas l\'écart entre les deux dates de la ligne 2.');
        return OK(isDate(fmt(D, 'D2')) ? 'Le calcul est juste… mais D2 affiche 02/02/1900. Étrange ? C\'est l\'objet de l\'étape suivante.' : 'Le calcul est juste : 33 jours.'); } },
    { t: 'Un délai qui s\'affiche en date', go: [D, 'D2'],
      mission: 'D2 affiche une date de 1900 au lieu d\'un nombre de jours. Faites afficher le délai correctement dans toute la colonne D, sans modifier la formule.',
      h: ['Le calcul est juste : c\'est l\'habillage de la cellule qui trompe, pas la formule.', 'Sélectionnez toute la colonne D (clic sur la lettre D), puis changez son format : menu Nombre du ruban, ou clic droit → Format de cellule.'],
      sol: 'Colonne D sélectionnée → format <b>Standard</b>.',
      check() { if (v(D, 'D2') !== 33) return KO('Terminez d\'abord l\'étape 1.'); if (isDate(fmt(D, 'D2'))) return KO('D2 affiche toujours une date.'); return OK('D2 affiche 33 : la date de 1900, c\'était le nombre 33 habillé en date.'); } },
    { t: 'Le délai moyen', go: [D, 'D2'],
      mission: 'Calculez le délai des 40 devis. Puis trouvez le délai moyen de signature… sans écrire de formule pour la moyenne.',
      h: ['Inutile de retaper la formule 40 fois : recopiez celle de D2 jusqu\'au dernier devis.', 'Double-cliquez sur la poignée verte en bas à droite de D2. Ensuite, sélectionnez les 40 délais : la barre d\'état, en bas à droite, calcule pour vous.'],
      sol: 'D2 → double-clic sur la poignée ▪, puis sélection de D2:D41 et lecture de la <b>Moyenne</b> dans la barre d\'état.',
      check() { const bad = range(2, 41).filter(r => !isF(D, 'D' + r) || v(D, 'D' + r) !== v(D, 'C' + r) - v(D, 'B' + r));
        if (bad.length === 40) return KO('Les délais des autres devis ne sont pas encore calculés.');
        if (bad.length) return KO(`${bad.length} devis n'ont pas encore leur délai, par exemple ligne ${bad[0]}.`);
        if (range(2, 41).some(r => isDate(fmt(D, 'D' + r)))) return KO('Certains délais s\'affichent encore en date.');
        const s = A.sel(); if (s.si === D && s.c1 === 3 && s.c2 === 3 && s.r1 <= 1 && s.r2 >= 40) MOY.lu = true; try { if (MOY.lu) localStorage.setItem('xl17-moy', '1'); } catch (e) {}
        return MOY.lu ? OK('Délai moyen : 13,75 jours (Moyenne 13,75 · Nombre 40 · Somme 550 dans la barre d\'état).') : KO('Les 40 délais sont calculés. Il reste à lire le délai moyen : sélectionnez les 40 délais.'); } },
    { t: 'Les signatures lentes', go: [D, 'I2'],
      mission: 'Sophie veut trois chiffres. En I2 : combien de devis ont été signés en 15 jours ou plus. En I3 : le délai le plus long. En I4 : le délai le plus court. Chaque chiffre doit se mettre à jour si un délai change.',
      h: ['Il faut trois fonctions : une qui compte les cellules qui respectent une condition, une pour le maximum, une pour le minimum.', 'La fonction qui compte selon un critère s\'écrit NB.SI(plage;critère). Le critère « 15 ou plus » s\'écrit entre guillemets, avec le signe >=.'],
      sol: 'I2 : <code>=NB.SI(D2:D41;"&gt;=15")</code> · I3 : <code>=MAX(D2:D41)</code> · I4 : <code>=MIN(D2:D41)</code>',
      check() { const m = [];
        if (!isF(D, 'I2')) m.push('I2 : il faut une formule.'); else if (v(D, 'I2') !== 15) m.push(raw(D, 'I2').includes('NB.SI') ? 'I2 : le critère n\'est pas le bon (« 15 jours ou plus »).' : 'I2 n\'affiche pas le bon nombre de devis.');
        if (!isF(D, 'I3') || v(D, 'I3') !== 33) m.push('I3 n\'affiche pas le délai le plus long.'); if (!isF(D, 'I4') || v(D, 'I4') !== 2) m.push('I4 n\'affiche pas le délai le plus court.');
        return m.length ? KO(m.join(' ')) : OK('15 devis ont mis 15 jours ou plus ; le plus long 33 jours, le plus court 2 jours.'); } },
    { t: 'Sans les week-ends', go: [D, 'I6'],
      mission: 'Le premier devis a mis 33 jours à être signé, week-ends compris. En I6, calculez combien de jours ouvrés (du lundi au vendredi) séparent ses deux dates.',
      h: ['Une fonction de date compte les jours ouvrés entre deux dates.', 'Son nom commence par NB.JOURS… Elle prend la date de début, puis la date de fin.'],
      sol: '<code>=NB.JOURS.OUVRES(B2;C2)</code>',
      check() { if (!isF(D, 'I6')) return KO('I6 doit contenir une formule.'); if (v(D, 'I6') === 24) return OK('24 jours ouvrés, contre 33 jours calendaires.');
        if (isDate(fmt(D, 'I6'))) return KO('I6 s\'affiche en date : vérifiez son format.'); return KO('Le résultat ne correspond pas aux jours ouvrés entre les deux dates du premier devis.'); } },
    { t: 'Les échéances', go: [F, 'D2'],
      mission: 'Onglet <b>Factures</b> : chaque facture doit être payée dans un délai (colonne C). Calculez la date d\'échéance de chaque facture, dans la colonne D.',
      h: ['Une date plus un nombre de jours donne une nouvelle date.', 'Date de facture + délai de paiement, puis recopie jusqu\'à la dernière facture. Si vous voyez un nombre à 5 chiffres, c\'est encore une question de format.'],
      sol: 'D2 : <code>=B2+C2</code>, puis double-clic sur la poignée.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'D' + r) || v(F, 'D' + r) !== v(F, 'B' + r) + v(F, 'C' + r));
        if (bad.length === 30) return KO('Aucune échéance calculée pour l\'instant (feuille Factures, colonne D).'); if (bad.length) return KO(`${bad.length} facture(s) sans échéance juste, par exemple ligne ${bad[0]}.`);
        if (range(2, 31).some(r => !isDate(fmt(F, 'D' + r)))) return KO('Certaines échéances s\'affichent comme des nombres à 5 chiffres.');
        return OK('16/12/2026 pour la première facture, et la ligne 23 passe à 2027 : Excel change de mois et d\'année tout seul.'); } },
    { t: 'Les jours restants', go: [F, 'E2'],
      mission: 'Colonne E : combien de jours reste-t-il avant chaque échéance, à la date d\'aujourd\'hui ? Le résultat doit se mettre à jour tout seul demain, sans rien retaper.',
      h: ['Une fonction renvoie la date du jour, et change chaque jour. Elle n\'a besoin de rien entre ses parenthèses.', 'Échéance moins la date du jour. Attention : Excel risque d\'habiller le résultat en date.'],
      sol: 'E2 : <code>=D2-AUJOURDHUI()</code>, recopie, puis format <b>Standard</b> sur la colonne E.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'E' + r) || v(F, 'E' + r) !== v(F, 'D' + r) - today);
        if (bad.length === 30) return KO('Aucun nombre de jours restants pour l\'instant (colonne E).'); if (bad.length) return KO(`${bad.length} ligne(s) sans le bon calcul, par exemple ligne ${bad[0]}.`);
        if (range(2, 31).some(r => isDate(fmt(F, 'E' + r)))) return KO('Le calcul est juste, mais des résultats s\'affichent en dates de 1900.');
        return OK('Positif : jours avant l\'échéance. Négatif : échéance dépassée. Demain, tout aura baissé de 1.'); } },
    { t: 'Les factures en retard', go: [F, 'F2'],
      mission: 'Colonne F : Sophie veut lire d\'un coup d\'œil « En retard » quand l\'échéance est dépassée, et « À venir » sinon.',
      h: ['Il faut un test : les jours restants sont-ils négatifs ?', 'La fonction SI prend trois éléments : le test ; ce qu\'on affiche si c\'est vrai ; ce qu\'on affiche sinon. Les textes s\'écrivent entre guillemets.'],
      sol: 'F2 : <code>=SI(E2&lt;0;"En retard";"À venir")</code>, puis recopie.',
      check() { const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
        const bad = range(2, 31).filter(r => { const e = v(F, 'E' + r); if (!isF(F, 'F' + r) || typeof e !== 'number') return true; return norm(v(F, 'F' + r)) !== (e < 0 ? 'en retard' : 'a venir'); });
        if (bad.length === 30) return KO('La colonne F n\'affiche encore aucune situation.'); if (bad.length) return KO(`${bad.length} ligne(s) incorrecte(s), par exemple ligne ${bad[0]}. Vérifiez le test et l'orthographe des textes.`);
        return OK('Chaque facture affiche sa situation, recalculée chaque jour.'); } },
    { t: 'Une date qui bouge, une date qui ne bouge pas', go: [F, 'I1'],
      mission: 'Feuille Factures. En I1, notez la date du jour comme on noterait la date d\'un paiement reçu : elle ne doit plus jamais changer. En I2, affichez une date du jour qui avancera toute seule. Comparez ensuite les deux cellules dans la barre de formule.',
      h: ['Pour la date figée, un raccourci clavier tape la date du jour, sans formule.', 'Le raccourci est Ctrl+; (point-virgule). Pour la date qui avance, c\'est la fonction de l\'étape 7.'],
      sol: 'I1 : <b>Ctrl+;</b> puis Entrée · I2 : <code>=AUJOURDHUI()</code>',
      check() { const m = [];
        if (isF(F, 'I1')) m.push('I1 contient une formule : elle changera demain.'); else if (v(F, 'I1') !== today) m.push('I1 ne contient pas la date du jour.');
        if (!isF(F, 'I2') || !raw(F, 'I2').includes('AUJOURDHUI')) m.push('I2 n\'affiche pas une date qui avance toute seule.');
        return m.length ? KO(m.join(' ')) : OK('Même date affichée, mais I1 est une valeur figée et I2 une formule : demain, seule I2 changera.'); } },
  ];
  const AIDE = JSON.parse((() => { try { return localStorage.getItem('xl17-aide') || '{}'; } catch (e) { return '{}'; } })());
  const saveAide = () => { try { localStorage.setItem('xl17-aide', JSON.stringify(AIDE)); } catch (e) {} };

  // ---------- SCORM 1.2 ----------
  const SC = (() => { let api = null; function find(w) { let n = 0; while (w && !w.API && w.parent && w.parent !== w && n < 10) { w = w.parent; n++; } return w && w.API ? w.API : null; }
    try { api = find(window) || (window.opener && find(window.opener)); } catch (e) {}
    const call = (f, ...a) => { try { return api ? api[f](...a) : ''; } catch (e) { return ''; } };
    return { api: () => !!api, init: () => call('LMSInitialize', ''), get: k => call('LMSGetValue', k), set: (k, x) => call('LMSSetValue', k, String(x)), commit: () => call('LMSCommit', ''), finish: () => call('LMSFinish', '') }; })();
  SC.init();
  const susp = SC.get('cmi.suspend_data'); const local = A.savedLocal();
  if (susp && susp.length > 2) A.load(susp); else if (local) A.load(local);
  let saveT; window.onSave = d => { clearTimeout(saveT); saveT = setTimeout(() => { SC.set('cmi.suspend_data', d.length < 60000 ? d : ''); SC.commit(); }, 800); };
  window.addEventListener('beforeunload', () => { SC.commit(); SC.finish(); });

  // ---------- panneau ----------
  let cur = 0; const done = new Set(); let lastScore = -1;
  const el = document.getElementById('steps');
  function draw(res) {
    el.innerHTML = STEPS.map((s, i) => { const lv = AIDE[i] || 0;
      const aides = s.h.slice(0, Math.min(lv, 2)).map((x, k) => `<div class="hint"><b>Indice ${k + 1} :</b> ${x}</div>`).join('') + (lv >= 3 ? `<div class="hint"><b>Solution :</b> ${s.sol}</div>` : '');
      const btn = res[i].ok ? '' : lv < 2 ? `<button class="b" data-h="${i}">Indice ${lv + 1}</button>` : lv === 2 ? `<button class="b" data-h="${i}">Voir la solution</button>` : '';
      const tag = lv ? `<span class="lvl">${lv >= 3 ? 'avec la solution' : lv + ' indice' + (lv > 1 ? 's' : '')}</span>` : '';
      return `<div class="st${res[i].ok ? ' ok' : ''}${i === cur ? ' on' : ''}" data-i="${i}">
      <div class="hd"><span class="ic">${res[i].ok ? '✓' : i + 1}</span><span>${s.t}</span>${tag}</div>
      <div class="bd"><p>${s.mission}</p>${aides}
      <div class="fb ${res[i].ok ? 'ok' : 'ko'}">${res[i].ok ? '✓ ' : ''}${res[i].msg}</div>
      <div class="btns">${btn}<button class="b" data-go="${i}">Aller à la cellule</button>${i < STEPS.length - 1 ? `<button class="b p" data-next="${i}">Suivant →</button>` : ''}</div></div></div>`; }).join('')
      + (res.every(r => r.ok) ? `<div class="done"><b>Atelier terminé.</b> ${Object.keys(AIDE).length ? 'Refaites plus tard les étapes où vous avez eu besoin d\'aide.' : 'Sans aucune aide : bravo !'} Passez au quiz de contrôle, en bas de la section.</div>` : '');
  }
  function evaluate() {
    const res = STEPS.map(s => { try { return s.check(); } catch (e) { return KO('Étape à faire.'); } });
    res.forEach((r, i) => { if (r.ok && !done.has(i)) { done.add(i); } });
    const n = res.filter(r => r.ok).length; document.getElementById('pt').textContent = n + ' / 9'; document.getElementById('pb').style.width = (n / 9 * 100) + '%';
    const scroll = el.scrollTop; draw(res); el.scrollTop = scroll;
    const score = Math.round(n / 9 * 100); if (score !== lastScore) { lastScore = score; SC.set('cmi.core.score.min', 0); SC.set('cmi.core.score.max', 100); SC.set('cmi.core.score.raw', score); SC.set('cmi.core.lesson_status', n === 9 ? 'completed' : 'incomplete'); SC.commit(); }
    return res;
  }
  window.onWorkbookChange = () => { const before = done.size; const res = evaluate(); if (res[cur] && res[cur].ok && !evaluate.prevOk) {} };
  el.addEventListener('click', ev => {
    const hb = ev.target.closest('[data-h]'); if (hb) { const i = +hb.dataset.h; AIDE[i] = (AIDE[i] || 0) + 1; saveAide(); evaluate(); return; }
    const g = ev.target.closest('[data-go]'), nx = ev.target.closest('[data-next]'), hd = ev.target.closest('.hd');
    if (g) { const s = STEPS[+g.dataset.go]; A.goto(s.go[0], s.go[1]); return; }
    if (nx) { cur = +nx.dataset.next + 1; evaluate(); const s = STEPS[cur]; A.goto(s.go[0], s.go[1]); return; }
    if (hd) { cur = +hd.parentElement.dataset.i; evaluate(); }
  });
  let armed = false; const rb = document.getElementById('reset');
  rb.addEventListener('click', () => { if (!armed) { armed = true; rb.textContent = 'Confirmer la remise à zéro'; rb.classList.add('p'); setTimeout(() => { armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); }, 4000); return; }
    armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); A.reset(); cur = 0; done.clear(); for (const k in AIDE) delete AIDE[k]; MOY.lu = false; try { localStorage.removeItem('xl17-moy'); } catch (e) {} saveAide(); evaluate(); });
  // première étape non faite
  const r0 = evaluate(); cur = Math.max(0, r0.findIndex(r => !r.ok)); if (cur < 0) cur = 0; evaluate();
})();
