// Étapes, vérifications et suivi SCORM — atelier 17
(function () {
  'use strict';
  const A = XLAPP, D = 0, F = 1, E = 2;
  const v = (si, ref) => A.val(si, ref), c = (si, ref) => A.cell(si, ref) || {};
  const isF = (si, ref) => c(si, ref).ast !== undefined;
  const raw = (si, ref) => String(c(si, ref).raw || '').toUpperCase().replace(/[\s$]/g, '');
  const fmt = (si, ref) => c(si, ref).f || 'gen';
  const isDate = f => f === 'date' || f === 'dlong';
  const today = A.todaySerial();
  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });

  const MOY = { lu: (() => { try { return localStorage.getItem('xl17-moy2') === '1'; } catch (e) { return false; } })() };
  const STEPS = [
    { t: 'Le délai de signature', go: [D, 'D2'], tg: [D, ['D2']],
      need: 'Sophie veut savoir combien de jours chaque client a mis à signer son devis. On commence par le premier devis.',
      ou: 'Feuille <b>Devis signés</b>, cellule <b>D2</b> (en jaune), dans la colonne « Délai (jours) ».',
      verif: 'D2 doit contenir un calcul qui utilise la date du devis (B2) et la date de signature (C2).',
      h: ['Pour Excel, une date est un nombre de jours. On peut donc faire une opération entre deux dates.', 'Le délai, c\'est la date la plus récente moins la plus ancienne. Après le signe =, cliquez sur les cellules plutôt que de taper leurs références.'],
      sol: '<code>=C2-B2</code>, puis Entrée.',
      check() { if (!isF(D, 'D2')) return KO('D2 doit contenir un calcul, qui commence par =.'); const x = v(D, 'D2');
        if (x === -33) return KO('Le résultat est négatif : vous avez soustrait dans le mauvais ordre.');
        if (x !== 33) return KO('Le résultat n\'est pas l\'écart entre les deux dates de la ligne 2.');
        return OK(isDate(fmt(D, 'D2')) ? 'Le calcul est juste… mais D2 affiche 02/02/1900. Étrange ? C\'est l\'objet de l\'étape suivante.' : 'Le calcul est juste : 33 jours.'); } },
    { t: 'Un délai qui s\'affiche en date', go: [D, 'D2'], tg: [D, ['D2:D41']],
      need: 'D2 affiche une date de 1900 au lieu d\'un nombre de jours. Il faut que toute la colonne affiche des nombres de jours.',
      ou: 'Toute la colonne <b>D</b> : cliquez sur la lettre D, en haut de la colonne.',
      verif: 'D2 affiche un nombre. La formule ne doit pas changer.',
      h: ['Le calcul est juste : c\'est l\'habillage de la cellule (son format) qui trompe, pas la formule.', 'Colonne D sélectionnée, changez son format : menu Nombre du ruban, ou clic droit → Format de cellule.'],
      sol: 'Colonne D sélectionnée → format <b>Standard</b>.',
      check() { if (v(D, 'D2') !== 33) return KO('Terminez d\'abord l\'étape 1.'); if (isDate(fmt(D, 'D2'))) return KO('D2 affiche toujours une date.'); return OK('D2 affiche 33 : la date de 1900, c\'était le nombre 33 habillé en date.'); } },
    { t: 'Le délai moyen', go: [D, 'D2'], tg: [D, ['D3:D41', 'I2']],
      need: 'Sophie veut le délai des 40 devis, puis le délai moyen de signature.',
      ou: 'D\'abord la colonne <b>D</b>, de D3 à D41 (un délai par devis). Puis la cellule <b>I2</b>, en face de « Délai moyen ».',
      verif: 'Chaque ligne a son délai. En I2, tapez le délai moyen. Contrainte : trouvez-le sans écrire de formule de moyenne.',
      h: ['Inutile de retaper la formule 40 fois : recopiez celle de D2 jusqu\'au dernier devis.', 'Double-clic sur la poignée verte en bas à droite de D2. Puis sélectionnez les 40 délais : la barre d\'état, en bas à droite, affiche leur moyenne. Recopiez ce nombre en I2.'],
      sol: 'D2 → double-clic sur la poignée ▪ ; sélection de D2:D41 ; la barre d\'état affiche <b>Moyenne 13,75</b> ; tapez <code>13,75</code> en I2.',
      check() { const bad = range(2, 41).filter(r => !isF(D, 'D' + r) || v(D, 'D' + r) !== v(D, 'C' + r) - v(D, 'B' + r));
        if (bad.length === 40) return KO('Les délais des devis 2 à 40 ne sont pas encore calculés (colonne D).');
        if (bad.length) return KO(`${bad.length} devis ${bad.length > 1 ? "n'ont" : "n'a"} pas encore le bon délai, par exemple ligne ${bad[0]}.`);
        if (range(2, 41).some(r => isDate(fmt(D, 'D' + r)))) return KO('Certains délais s\'affichent encore en date.');
        const m = v(D, 'I2'); if (m === null || m === undefined || m === '') return KO('Les 40 délais sont calculés. Il reste à écrire le délai moyen en I2.');
        if (typeof m !== 'number' || Math.abs(m - 13.75) > 0.01) return KO('I2 ne contient pas le délai moyen des 40 devis.');
        return OK('Délai moyen : 13,75 jours. La barre d\'état affichait aussi Nombre 40 et Somme 550.'); } },
    { t: 'Les signatures lentes', go: [D, 'I3'], tg: [D, ['I3:I5']],
      need: 'Sophie veut trois chiffres : combien de devis ont été signés en 15 jours ou plus, le délai le plus long et le délai le plus court.',
      ou: 'Cellules <b>I3</b>, <b>I4</b> et <b>I5</b>, en face de leur libellé.',
      verif: 'Chaque chiffre doit être calculé par une formule, pour se mettre à jour si un délai change.',
      h: ['Il faut trois fonctions : une qui compte les cellules qui respectent une condition, une pour le maximum, une pour le minimum.', 'La fonction qui compte selon un critère s\'écrit NB.SI(plage;critère). Le critère « 15 ou plus » s\'écrit entre guillemets, avec le signe >=.'],
      sol: 'I3 : <code>=NB.SI(D2:D41;"&gt;=15")</code> · I4 : <code>=MAX(D2:D41)</code> · I5 : <code>=MIN(D2:D41)</code>',
      check() { const m = [];
        if (!isF(D, 'I3')) m.push('I3 : il faut une formule.'); else if (v(D, 'I3') !== 15) m.push(raw(D, 'I3').includes('NB.SI') ? 'I3 : le critère n\'est pas le bon (« 15 jours ou plus »).' : 'I3 n\'affiche pas le bon nombre de devis.');
        if (!isF(D, 'I4') || v(D, 'I4') !== 33) m.push('I4 n\'affiche pas le délai le plus long (avec une formule).'); if (!isF(D, 'I5') || v(D, 'I5') !== 2) m.push('I5 n\'affiche pas le délai le plus court (avec une formule).');
        return m.length ? KO(m.join(' ')) : OK('15 devis ont mis 15 jours ou plus ; le plus long 33 jours, le plus court 2 jours.'); } },
    { t: 'Sans les week-ends', go: [D, 'I7'], tg: [D, ['I7']],
      need: 'Le premier devis (D-2026-001) a mis 33 jours à être signé, week-ends compris. Sophie veut savoir combien de jours ouvrés (du lundi au vendredi) cela représente.',
      ou: 'Cellule <b>I7</b>, en face de « Jours ouvrés, 1er devis ».',
      verif: 'Un calcul à partir des deux dates du premier devis (B2 et C2).',
      h: ['Une fonction de date compte les jours ouvrés entre deux dates.', 'Son nom commence par NB.JOURS… Elle prend la date de début, puis la date de fin.'],
      sol: '<code>=NB.JOURS.OUVRES(B2;C2)</code>',
      check() { if (!isF(D, 'I7')) return KO('I7 doit contenir une formule.'); if (v(D, 'I7') === 24) return OK('24 jours ouvrés, contre 33 jours calendaires.');
        if (isDate(fmt(D, 'I7'))) return KO('I7 s\'affiche en date : vérifiez son format.'); return KO('Le résultat ne correspond pas aux jours ouvrés entre les deux dates du premier devis.'); } },
    { t: 'Les échéances', go: [F, 'D2'], tg: [F, ['D2:D31']],
      need: 'Chaque facture doit être payée dans un délai, en jours (colonne C). Sophie veut la date limite de paiement de chaque facture.',
      ou: 'Onglet <b>Factures</b> (en bas), colonne <b>D</b> « Échéance », de D2 à D31.',
      verif: 'Chaque échéance s\'affiche comme une date.',
      h: ['Une date plus un nombre de jours donne une nouvelle date.', 'Date de facture + délai de paiement, puis recopie jusqu\'à la dernière facture. Un nombre à 5 chiffres ? C\'est encore une question de format.'],
      sol: 'D2 : <code>=B2+C2</code>, puis double-clic sur la poignée.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'D' + r) || v(F, 'D' + r) !== v(F, 'B' + r) + v(F, 'C' + r));
        if (bad.length === 30) return KO('Aucune échéance calculée pour l\'instant (feuille Factures, colonne D).'); if (bad.length) return KO(`${bad.length} facture(s) sans échéance juste, par exemple ligne ${bad[0]}.`);
        if (range(2, 31).some(r => !isDate(fmt(F, 'D' + r)))) return KO('Certaines échéances s\'affichent comme des nombres à 5 chiffres.');
        return OK('16/12/2026 pour la première facture, et la ligne 23 passe à 2027 : Excel change de mois et d\'année tout seul.'); } },
    { t: 'Les jours restants', go: [F, 'E2'], tg: [F, ['E2:E31']],
      need: 'Sophie veut savoir combien de jours il reste avant chaque échéance, à la date d\'aujourd\'hui.',
      ou: 'Feuille Factures, colonne <b>E</b> « Jours restants », de E2 à E31.',
      verif: 'Un nombre de jours (pas une date). Contrainte : demain, les résultats doivent changer tout seuls, sans rien retaper.',
      h: ['Une fonction renvoie la date du jour, et change chaque jour. Elle n\'a besoin de rien entre ses parenthèses.', 'Échéance moins la date du jour. Attention : Excel risque d\'habiller le résultat en date.'],
      sol: 'E2 : <code>=D2-AUJOURDHUI()</code>, recopie, puis format <b>Standard</b> sur la colonne E.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'E' + r) || v(F, 'E' + r) !== v(F, 'D' + r) - today);
        if (bad.length === 30) return KO('Aucun nombre de jours restants pour l\'instant (colonne E).'); if (range(2, 31).filter(r => isF(F, 'E' + r)).every(r => v(F, 'E' + r) === today - v(F, 'D' + r))) return KO('Les résultats ont le mauvais signe : une échéance future doit donner un nombre positif. Vérifiez l\'ordre de la soustraction.'); if (bad.length) return KO(`${bad.length} ligne(s) sans le bon calcul, par exemple ligne ${bad[0]}.`);
        if (range(2, 31).some(r => isDate(fmt(F, 'E' + r)))) return KO('Le calcul est juste, mais des résultats s\'affichent en dates de 1900.');
        return OK('Positif : jours avant l\'échéance. Négatif : échéance dépassée. Demain, tout aura baissé de 1.'); } },
    { t: 'Les factures en retard', go: [F, 'F2'], tg: [F, ['F2:F31']],
      need: 'Sophie veut repérer d\'un coup d\'œil les factures dont l\'échéance est dépassée.',
      ou: 'Feuille Factures, colonne <b>F</b> « Situation », de F2 à F31.',
      verif: 'Chaque ligne affiche « En retard » si l\'échéance est dépassée, sinon « À venir ».',
      h: ['Il faut un test : les jours restants sont-ils négatifs ?', 'La fonction SI prend trois éléments : le test ; ce qu\'on affiche si c\'est vrai ; ce qu\'on affiche sinon. Les textes s\'écrivent entre guillemets.'],
      sol: 'F2 : <code>=SI(E2&lt;0;"En retard";"À venir")</code>, puis recopie.',
      check() { const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
        const bad = range(2, 31).filter(r => { const e = v(F, 'E' + r); if (!isF(F, 'F' + r) || typeof e !== 'number') return true; return norm(v(F, 'F' + r)) !== (e < 0 ? 'en retard' : 'a venir'); });
        if (bad.length === 30) return KO('La colonne F n\'affiche encore aucune situation.'); if (bad.length) return KO(`${bad.length} ligne(s) incorrecte(s), par exemple ligne ${bad[0]}. Vérifiez le test et l'orthographe des textes.`);
        return OK('Chaque facture affiche sa situation, recalculée chaque jour.'); } },
    { t: 'Une date qui bouge, une date qui ne bouge pas', go: [F, 'I1'], tg: [F, ['I1:I2']],
      need: 'Karim note la date d\'un paiement reçu : elle ne doit plus jamais changer. Sophie, elle, veut une date du jour qui avance toute seule.',
      ou: 'Feuille Factures : cellule <b>I1</b> pour la date figée, cellule <b>I2</b> pour la date qui avance.',
      verif: 'Les deux cellules affichent la date d\'aujourd\'hui. Cliquez sur I1 puis sur I2 et comparez la barre de formule.',
      h: ['Pour la date figée, un raccourci clavier tape la date du jour, sans formule.', 'Le raccourci est Ctrl+; (point-virgule). Pour la date qui avance, c\'est la fonction de l\'étape 7.'],
      sol: 'I1 : <b>Ctrl+;</b> puis Entrée · I2 : <code>=AUJOURDHUI()</code>',
      check() { const m = [];
        if (isF(F, 'I1')) m.push('I1 contient une formule : elle changera demain.'); else if (v(F, 'I1') !== today) m.push('I1 ne contient pas la date du jour.');
        if (!isF(F, 'I2') || !raw(F, 'I2').includes('AUJOURDHUI')) m.push('I2 n\'affiche pas une date qui avance toute seule.');
        return m.length ? KO(m.join(' ')) : OK('Même date affichée, mais I1 est une valeur figée et I2 une formule : demain, seule I2 changera.'); } },
    { t: 'Les formules en erreur de Karim', go: [E, 'B2'], tg: [E, ['B2:C6']],
      need: 'Karim a écrit cinq formules qui affichent des erreurs. Pour chacune, trouvez la cause, puis réparez-la. Infos utiles : Karim a envoyé <b>40 devis</b> ce mois ; la feuille « Devis 2025 » a été supprimée, le premier devis se trouve maintenant dans « Devis signés ».',
      ou: 'Onglet <b>Erreurs</b>. Colonne <b>C</b> : choisissez la cause dans la liste (petit bouton ▾ à droite de la cellule). Pour réparer : la formule en colonne <b>B</b>, ou la donnée qu\'elle utilise en colonne <b>F</b>.',
      verif: 'Plus aucune erreur en colonne B, et la bonne cause en face de chaque ligne.',
      h: ['#NOM? : Excel ne reconnaît pas un mot. #VALEUR! : il reconnaît la fonction, mais pas la donnée. #DIV/0! : division par zéro ou par une cellule vide. #REF! : la référence a disparu. #NOMBRE! : un résultat impossible.', 'Lisez la barre de formule de chaque cellule, puis regardez les données qu\'elle utilise : une date calée à gauche est du texte ; une cellule vide vaut 0 ; DATEDIF veut la date la plus ancienne en premier.'],
      sol: 'B2 : <code>=NB.SI(\'Devis signés\'!G2:G41;"&gt;=5000")</code> → Nom de fonction inconnu · F2 : retaper <code>05/06/2026</code> → Texte à la place d\'une date · F4 : taper <code>40</code> → Division par une cellule vide · B5 : <code>=\'Devis signés\'!G2</code> → Référence disparue · B6 : <code>=DATEDIF(F6;AUJOURDHUI();"y")</code> → Dates inversées',
      check() { const bad = CC[9]().filter(x => x[2]); if (!bad.length) return OK('Les cinq erreurs sont réparées. #NOM? : le mot · #VALEUR! : la donnée · #DIV/0! : le diviseur · #REF! : la référence · #NOMBRE! : le résultat impossible.');
        const nb = bad.filter(x => x[1][0] === 'B').length, nc = bad.filter(x => x[1][0] === 'C').length;
        return KO([nb ? `${nb} formule${nb > 1 ? 's' : ''} encore en erreur ou fausse${nb > 1 ? 's' : ''}` : '', nc ? `${nc} cause${nc > 1 ? 's' : ''} à revoir` : ''].filter(Boolean).join(' · ') + '.'); } },
  ];
  const AIDE = JSON.parse((() => { try { return localStorage.getItem('xl17-aide2') || '{}'; } catch (e) { return '{}'; } })());
  const saveAide = () => { try { localStorage.setItem('xl17-aide2', JSON.stringify(AIDE)); } catch (e) {} };


  // ---------- vérification cellule par cellule ----------
  const col = (si, L, a, b, fn) => range(a, b).map(r => [si, L + r, fn(r)]);
  const nof = (si, ref) => !isF(si, ref) ? 'Pas de formule : il faut un calcul qui commence par =.' : null;
  const CC = [
    () => [[D, 'D2', nof(D, 'D2') || (v(D, 'D2') === -33 ? 'Résultat négatif : ordre de la soustraction inversé.' : v(D, 'D2') !== 33 ? 'Ce n\'est pas l\'écart entre B2 et C2.' : null)]],
    () => [[D, 'D2', v(D, 'D2') !== 33 ? 'Terminez d\'abord l\'étape 1.' : isDate(fmt(D, 'D2')) ? 'Toujours affiché en date.' : null]],
    () => col(D, 'D', 3, 41, r => nof(D, 'D' + r) || (v(D, 'D' + r) !== v(D, 'C' + r) - v(D, 'B' + r) ? 'Ce n\'est pas le délai de cette ligne.' : isDate(fmt(D, 'D' + r)) ? 'Affiché en date.' : null))
      .concat([[D, 'I2', (() => { const m = v(D, 'I2'); if (m === null || m === '') return 'Vide : écrivez ici le délai moyen.'; return typeof m !== 'number' || Math.abs(m - 13.75) > 0.01 ? 'Ce n\'est pas le délai moyen des 40 devis.' : null; })()]]),
    () => [[D, 'I3', nof(D, 'I3') || (v(D, 'I3') !== 15 ? 'Pas le bon nombre de devis.' : null)], [D, 'I4', nof(D, 'I4') || (v(D, 'I4') !== 33 ? 'Pas le délai le plus long.' : null)], [D, 'I5', nof(D, 'I5') || (v(D, 'I5') !== 2 ? 'Pas le délai le plus court.' : null)]],
    () => [[D, 'I7', nof(D, 'I7') || (isDate(fmt(D, 'I7')) ? 'Affiché en date.' : v(D, 'I7') !== 24 ? 'Pas le nombre de jours ouvrés entre B2 et C2.' : null)]],
    () => col(F, 'D', 2, 31, r => nof(F, 'D' + r) || (v(F, 'D' + r) !== v(F, 'B' + r) + v(F, 'C' + r) ? 'Ce n\'est pas l\'échéance de cette facture.' : !isDate(fmt(F, 'D' + r)) ? 'Nombre à 5 chiffres : c\'est une date sans son format.' : null)),
    () => col(F, 'E', 2, 31, r => nof(F, 'E' + r) || (v(F, 'E' + r) === today - v(F, 'D' + r) && v(F, 'E' + r) !== 0 ? 'Signe inversé : on veut l\'échéance moins la date du jour.' : v(F, 'E' + r) !== v(F, 'D' + r) - today ? 'Ce n\'est pas le nombre de jours avant l\'échéance.' : isDate(fmt(F, 'E' + r)) ? 'Affiché en date.' : null)),
    () => { const norm = x => String(x).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim(); return col(F, 'F', 2, 31, r => { const e = v(F, 'E' + r); return nof(F, 'F' + r) || (typeof e !== 'number' ? 'Les jours restants (colonne E) manquent.' : norm(v(F, 'F' + r)) !== (e < 0 ? 'en retard' : 'a venir') ? 'Ne correspond pas à la situation de cette facture.' : null); }); },
    () => [[F, 'I1', isF(F, 'I1') ? 'C\'est une formule : elle changera demain.' : v(F, 'I1') !== today ? 'Ce n\'est pas la date du jour.' : null], [F, 'I2', !isF(F, 'I2') || !raw(F, 'I2').includes('AUJOURDHUI') ? 'Cette date ne bougera pas toute seule.' : null]],
    () => { const CAUSES = ["Nom de fonction inconnu", "Texte à la place d'une date ou d'un nombre", "Division par zéro ou par une cellule vide", "Référence à une feuille ou une cellule qui n'existe plus", "Valeur impossible pour la fonction (dates inversées)"];
      let n5k = 0; for (let r = 2; r <= 41; r++) { const g = v(D, 'G' + r); if (typeof g === 'number' && g >= 5000) n5k++; }
      const p6 = A.serialToParts ? null : null; const d6 = v(E, 'F6'); let yrs = null; if (typeof d6 === 'number') { const a = XL.serialToParts(d6), b = XL.serialToParts(today); yrs = b.y - a.y - ((b.m < a.m || (b.m === a.m && b.d < a.d)) ? 1 : 0); }
      const exp = { B2: n5k, B3: 14, B4: 0.3, B5: 3680, B6: yrs };
      const out = [];
      for (let r = 2; r <= 6; r++) { const ref = 'B' + r, x = v(E, ref);
        out.push([E, ref, x && typeof x === 'object' && x.err ? 'Toujours en erreur : ' + x.err : (typeof x !== 'number' || Math.abs(x - exp[ref]) > 1e-9) ? 'Plus d\'erreur, mais le résultat n\'est pas celui attendu.' : null]); }
      for (let r = 2; r <= 6; r++) { const ref = 'C' + r, x = v(E, ref); out.push([E, ref, !x ? 'Choisissez une cause dans la liste ▾.' : x !== CAUSES[r - 2] ? 'Ce n\'est pas la cause de cette erreur.' : null]); }
      return out; },
  ];
  const ESS = JSON.parse((() => { try { return localStorage.getItem('xl17-ess3') || '{}'; } catch (e) { return '{}'; } })());
  const DONE = new Set(JSON.parse((() => { try { return localStorage.getItem('xl17-done3') || '[]'; } catch (e) { return '[]'; } })()));
  const VR = {};
  const persist = () => { try { localStorage.setItem('xl17-ess3', JSON.stringify(ESS)); localStorage.setItem('xl17-done3', JSON.stringify([...DONE])); } catch (e) {} };

  // ---------- SCORM 1.2 ----------
  const SC = (() => { let api = null; function find(w) { let n = 0; while (w && !w.API && w.parent && w.parent !== w && n < 10) { w = w.parent; n++; } return w && w.API ? w.API : null; }
    try { api = find(window) || (window.opener && find(window.opener)); } catch (e) {}
    const call = (f, ...a) => { try { return api ? api[f](...a) : ''; } catch (e) { return ''; } };
    return { api: () => !!api, init: () => call('LMSInitialize', ''), get: k => call('LMSGetValue', k), set: (k, x) => call('LMSSetValue', k, String(x)), commit: () => call('LMSCommit', ''), finish: () => call('LMSFinish', '') }; })();
  SC.init();
  const susp = SC.get('cmi.suspend_data'); const local = A.savedLocal();
  if (susp && susp.length > 2) A.load(susp); else if (local) A.load(local);
  let saveT; window.onSave = d => { clearTimeout(saveT); saveT = setTimeout(() => { SC.set('cmi.suspend_data', d.length < 60000 ? d : ''); SC.commit(); }, 800); };
  window.addEventListener('beforeunload', () => { SC.commit(); SC.finish(); });

  // ---------- panneau ----------
  let cur = 0, lastScore = -1;
  const el = document.getElementById('steps');
  function draw() {
    el.innerHTML = STEPS.map((s, i) => { const lv = AIDE[i] || 0, ok = DONE.has(i), vr = VR[i], ne = ESS[i] || 0;
      const aides = s.h.slice(0, Math.min(lv, 2)).map((x, k) => `<div class="hint"><b>Indice ${k + 1} :</b> ${x}</div>`).join('') + (lv >= 3 ? `<div class="hint"><b>Solution :</b> ${s.sol}</div>` : '');
      const hbtn = ok ? '' : lv < 2 ? `<button class="b" data-h="${i}">Indice ${lv + 1}</button>` : lv === 2 ? `<button class="b" data-h="${i}">Voir la solution</button>` : '';
      const tags = [ne ? (ok ? `réussi au ${ne === 1 ? '1er' : ne + 'e'} essai` : `${ne} essai${ne > 1 ? 's' : ''}`) : '', lv ? (lv >= 3 ? 'avec la solution' : lv + ' indice' + (lv > 1 ? 's' : '')) : ''].filter(Boolean).join(' · ');
      const fb = vr ? `<div class="fb ${vr.ok ? 'ok' : 'ko'}">${vr.ok ? '✓ ' : ''}${vr.msg}${vr.summ ? `<div class="summ">${vr.summ}</div>` : ''}</div>` : (ok ? '' : '<div class="fb" style="background:#f4f6f5;color:#555">Faites l\'exercice dans le classeur, puis cliquez sur <b>Vérifier</b>.</div>');
      return `<div class="st${ok ? ' ok' : ''}${i === cur ? ' on' : ''}" data-i="${i}">
      <div class="hd"><span class="ic">${ok ? '✓' : i + 1}</span><span>${s.t}</span>${tags ? `<span class="lvl">${tags}</span>` : ''}</div>
      <div class="bd"><p class="need"><span class="lab">Le besoin :</span> ${s.need}</p><p class="where"><span class="lab">Où répondre :</span> ${s.ou}</p><p><span class="lab">Pour vérifier :</span> ${s.verif}</p>${aides}${fb}
      <div class="btns"><button class="b v" data-v="${i}">Vérifier</button>${hbtn}<button class="b" data-go="${i}">Aller à la cellule</button>${i < STEPS.length - 1 ? `<button class="b p" data-next="${i}">Suivant →</button>` : ''}</div></div></div>`; }).join('')
      + (DONE.size === STEPS.length ? `<div class="done"><b>Atelier terminé.</b> ${Object.keys(AIDE).length || Object.values(ESS).some(n => n > 1) ? 'Refaites plus tard les étapes où vous avez eu besoin d\'indices ou de plusieurs essais.' : 'Tout au premier essai, sans aide : bravo !'} Passez au quiz de contrôle, en bas de la section.</div>` : '');
  }
  function refresh() {
    const n = DONE.size; document.getElementById('pt').textContent = n + ' / ' + STEPS.length; document.getElementById('pb').style.width = (n / STEPS.length * 100) + '%';
    const scroll = el.scrollTop; draw(); el.scrollTop = scroll;
    if (STEPS[cur] && refresh.tgCur !== cur) { refresh.tgCur = cur; A.setTargets(STEPS[cur].tg[0], STEPS[cur].tg[1]); }
    const score = Math.round(n / STEPS.length * 100); if (score !== lastScore) { lastScore = score; SC.set('cmi.core.score.min', 0); SC.set('cmi.core.score.max', 100); SC.set('cmi.core.score.raw', score); SC.set('cmi.core.lesson_status', n === STEPS.length ? 'completed' : 'incomplete'); SC.commit(); }
  }
  function verify(i) {
    let res; try { res = STEPS[i].check(); } catch (e) { res = KO('Étape à faire.'); }
    const cells = CC[i](); const ko = cells.filter(x => x[2]), okc = cells.filter(x => !x[2]);
    const long = cells.length > 7; const marks = []; const si = cells[0][0];
    for (const [s2, ref, why] of cells) { if (why) marks.push([ref, 'ko', why]); else if (!long) marks.push([ref, 'ok', '']); }
    if (A.sel().si !== si) A.goto(si, cells[0][1]);
    A.setMarks(si, marks);
    ESS[i] = (ESS[i] || 0) + (DONE.has(i) ? 0 : 1);
    if (res.ok) DONE.add(i);
    VR[i] = { ok: res.ok, msg: res.msg, summ: long ? `${okc.length} juste${okc.length > 1 ? 's' : ''}, ${ko.length} à revoir${ko.length ? ' (en rouge ; survolez une cellule pour voir pourquoi)' : ''}.` : (ko.length ? 'Survolez une cellule en rouge pour voir pourquoi.' : '') };
    persist(); refresh();
  }
  window.onWorkbookChange = () => {};
  el.addEventListener('click', ev => {
    const vb = ev.target.closest('[data-v]'); if (vb) { verify(+vb.dataset.v); return; }
    const hb = ev.target.closest('[data-h]'); if (hb) { const i = +hb.dataset.h; AIDE[i] = (AIDE[i] || 0) + 1; saveAide(); refresh(); return; }
    const g = ev.target.closest('[data-go]'), nx = ev.target.closest('[data-next]'), hd = ev.target.closest('.hd');
    if (g) { const s = STEPS[+g.dataset.go]; A.goto(s.go[0], s.go[1]); return; }
    if (nx) { cur = +nx.dataset.next + 1; A.clearMarks(); refresh(); const s = STEPS[cur]; A.goto(s.go[0], s.go[1]); return; }
    if (hd) { const i = +hd.parentElement.dataset.i; if (i !== cur) { cur = i; A.clearMarks(); } refresh(); }
  });
  let armed = false; const rb = document.getElementById('reset');
  rb.addEventListener('click', () => { if (!armed) { armed = true; rb.textContent = 'Confirmer la remise à zéro'; rb.classList.add('p'); setTimeout(() => { armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); }, 4000); return; }
    armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); A.reset(); cur = 0; DONE.clear(); for (const k in ESS) delete ESS[k]; for (const k in VR) delete VR[k]; persist(); A.clearMarks(); for (const k in AIDE) delete AIDE[k]; MOY.lu = false; try { localStorage.removeItem('xl17-moy2'); } catch (e) {} saveAide(); refresh(); });
  // reprise : étapes déjà réussies (classeur rechargé) ; ouvrir la première étape non faite
  STEPS.forEach((s, i) => { try { if (s.check().ok) DONE.add(i); } catch (e) {} });
  cur = STEPS.findIndex((s, i) => !DONE.has(i)); if (cur < 0) cur = 0; refresh();
})();
