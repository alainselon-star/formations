// Étapes, vérifications et suivi SCORM — atelier 17
(function () {
  'use strict';
  const A = XLAPP, D = 0, F = 1;
  const v = (si, ref) => A.val(si, ref), c = (si, ref) => A.cell(si, ref) || {};
  const isF = (si, ref) => c(si, ref).ast !== undefined;
  const raw = (si, ref) => String(c(si, ref).raw || '').toUpperCase().replace(/[\s$]/g, '');
  const fmt = (si, ref) => c(si, ref).f || 'gen';
  const isDate = f => f === 'date' || f === 'dlong';
  const today = A.todaySerial();
  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });

  const STEPS = [
    { t: 'Le piège de 1900', go: [D, 'D2'],
      faites: 'Feuille <b>Devis signés</b>, cliquez en D2, tapez <code>=C2-B2</code> puis Entrée. Astuce : après le signe =, vous pouvez cliquer sur C2 au lieu de taper sa référence.',
      voir: 'D2 affiche 02/02/1900. La colonne D était déjà au format Date.',
      pourquoi: 'Le calcul est juste : 33 jours. Mais au format Date, 33 s\'affiche comme le 33e jour du calendrier d\'Excel.',
      check() { if (!isF(D, 'D2')) return KO('Tapez la formule en D2, en commençant par =.'); const x = v(D, 'D2');
        if (x === -33) return KO('Vous voyez -33 ? Vous avez tapé =B2-C2 : la date la plus récente (C2) doit venir en premier.');
        if (x !== 33) return KO('La formule de D2 ne donne pas le bon écart. Attendu : =C2-B2.');
        return OK(isDate(fmt(D, 'D2')) ? 'Exact : 02/02/1900, c\'est le nombre 33 habillé en date.' : 'Formule juste.'); } },
    { t: 'Le bon format', go: [D, 'D2'],
      faites: 'Cliquez sur l\'en-tête de la colonne <b>D</b> pour la sélectionner, puis dans le ruban, <b>Nombre → Standard</b>.',
      voir: '33 en D2 : le devis D-2026-001 a été signé 33 jours après son envoi.',
      check() { if (v(D, 'D2') !== 33) return KO('Faites d\'abord l\'étape 1.'); if (isDate(fmt(D, 'D2'))) return KO('D2 affiche encore une date : sélectionnez la colonne D, puis Nombre → Standard.'); return OK('D2 affiche 33 : un nombre de jours.'); } },
    { t: 'Recopier et lire les chiffres', go: [D, 'D2'],
      faites: 'Cliquez sur D2, puis double-cliquez sur la petite poignée verte en bas à droite de la cellule. Sélectionnez ensuite D2:D41 et lisez la barre d\'état, en bas à droite.',
      voir: 'Moyenne 13,75 ; Nombre 40 ; Somme 550. Les clients mettent en moyenne près de 14 jours à signer.',
      check() { const bad = range(2, 41).filter(r => !isF(D, 'D' + r) || v(D, 'D' + r) !== v(D, 'C' + r) - v(D, 'B' + r));
        if (bad.length === 40) return KO('Recopiez la formule de D2 jusqu\'en D41 (double-clic sur la poignée).');
        if (bad.length) return KO(`${bad.length} ligne(s) sans la bonne formule, par exemple D${bad[0]}.`);
        if (range(2, 41).some(r => isDate(fmt(D, 'D' + r)))) return KO('Certaines cellules de D sont encore au format Date : passez toute la colonne en Standard.');
        const s = A.sel(); const lu = s.si === D && s.c1 === 3 && s.c2 === 3 && s.r1 <= 1 && s.r2 >= 40;
        return OK(lu ? 'Bravo : la barre d\'état affiche Moyenne 13,75, Nombre 40, Somme 550.' : 'Formules recopiées. Sélectionnez D2:D41 pour lire la moyenne dans la barre d\'état.'); } },
    { t: 'Les signatures lentes', go: [D, 'I2'],
      faites: 'En I2, tapez <code>=NB.SI(D2:D41;"&gt;=15")</code>. En I3, <code>=MAX(D2:D41)</code>. En I4, <code>=MIN(D2:D41)</code>.',
      voir: '15 devis signés en 15 jours ou plus, un délai maximal de 33 jours et minimal de 2 jours.',
      check() { const m = [];
        if (!isF(D, 'I2') || v(D, 'I2') !== 15) m.push(raw(D, 'I2').includes('NB.SI') ? 'I2 : vérifiez le critère, entre guillemets : ">=15".' : 'I2 : =NB.SI(D2:D41;">=15").');
        if (!isF(D, 'I3') || v(D, 'I3') !== 33) m.push('I3 : =MAX(D2:D41).'); if (!isF(D, 'I4') || v(D, 'I4') !== 2) m.push('I4 : =MIN(D2:D41).');
        return m.length ? KO(m.join(' ')) : OK('15 devis lents, 33 jours au plus, 2 jours au moins.'); } },
    { t: 'Les jours ouvrés', go: [D, 'I6'],
      faites: 'En I6, tapez <code>=NB.JOURS.OUVRES(B2;C2)</code>.',
      voir: '24 : entre le 02/01/2026 et le 04/02/2026, il y a 24 jours ouvrés (sans les samedis et dimanches), contre 33 jours calendaires.',
      check() { if (!isF(D, 'I6')) return KO('Tapez la formule en I6.'); if (v(D, 'I6') === 24) return OK('24 jours ouvrés, contre 33 jours calendaires.');
        if (isDate(fmt(D, 'I6'))) return KO('I6 affiche une date : passez-la au format Standard.'); return KO('Attendu : =NB.JOURS.OUVRES(B2;C2), avec un point-virgule.'); } },
    { t: 'Les échéances', go: [F, 'D2'],
      faites: 'Onglet <b>Factures</b> (en bas). En D2, tapez <code>=B2+C2</code>, puis recopiez jusqu\'en D31.',
      voir: '16/12/2026 en D2 (01/11/2026 + 45 jours). En D23, la facture F-2026-321 passe à l\'année suivante : 14/01/2027.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'D' + r) || v(F, 'D' + r) !== v(F, 'B' + r) + v(F, 'C' + r));
        if (bad.length === 30) return KO('Tapez =B2+C2 en D2 de la feuille Factures.'); if (bad.length) return KO(`${bad.length} ligne(s) à compléter, par exemple D${bad[0]}.`);
        if (range(2, 31).some(r => !isDate(fmt(F, 'D' + r)))) return KO('Vous voyez des nombres comme 46372 ? Sélectionnez D2:D31, puis Nombre → Date courte.');
        return OK('16/12/2026 en D2, et 14/01/2027 en D23 : Excel change de mois et d\'année tout seul.'); } },
    { t: 'Les jours restants', go: [F, 'E2'],
      faites: 'En E2, tapez <code>=D2-AUJOURDHUI()</code>, puis recopiez jusqu\'en E31.',
      voir: 'Des nombres positifs (jours avant l\'échéance) et négatifs (échéance dépassée). Demain, ils auront tous baissé de 1.',
      check() { const bad = range(2, 31).filter(r => !isF(F, 'E' + r) || v(F, 'E' + r) !== v(F, 'D' + r) - today);
        if (bad.length === 30) return KO('Tapez =D2-AUJOURDHUI() en E2.'); if (bad.length) return KO(`${bad.length} ligne(s) à compléter, par exemple E${bad[0]}.`);
        if (range(2, 31).some(r => isDate(fmt(F, 'E' + r)))) return KO('Vous voyez des dates ? Excel a habillé le résultat en date : sélectionnez E2:E31, puis Nombre → Standard.');
        return OK('Positif : jours avant l\'échéance. Négatif : échéance dépassée.'); } },
    { t: 'La situation', go: [F, 'F2'],
      faites: 'En F2, tapez <code>=SI(E2&lt;0;"En retard";"À venir")</code>, puis recopiez jusqu\'en F31.',
      voir: '« En retard » pour F-2026-319 (échéance 03/10/2026), « À venir » pour F-2026-321 (échéance 14/01/2027).',
      check() { const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
        const bad = range(2, 31).filter(r => { const e = v(F, 'E' + r); if (!isF(F, 'F' + r) || typeof e !== 'number') return true; return norm(v(F, 'F' + r)) !== (e < 0 ? 'en retard' : 'a venir'); });
        if (bad.length === 30) return KO('Tapez la formule SI en F2.'); if (bad.length) return KO(`${bad.length} ligne(s) incorrecte(s), par exemple F${bad[0]}. Vérifiez les guillemets et le point-virgule.`);
        return OK('Chaque facture affiche sa situation, recalculée chaque jour.'); } },
    { t: 'Date figée ou date qui avance', go: [F, 'I1'],
      faites: 'Feuille Factures, cliquez en I1, appuyez sur <b>Ctrl+;</b> (point-virgule) puis Entrée. En I2, tapez <code>=AUJOURDHUI()</code>. Cliquez sur I1, puis sur I2, en regardant la barre de formule.',
      voir: 'La même date dans les deux cellules ; mais I1 contient la date tapée, I2 la formule. Demain, seule I2 changera.',
      pourquoi: 'Ctrl+; sert à noter la date d\'un événement (un paiement reçu) ; AUJOURDHUI sert aux comptes à rebours.',
      check() { const m = [];
        if (isF(F, 'I1') || v(F, 'I1') !== today) m.push(isF(F, 'I1') ? 'I1 doit contenir la date tapée avec Ctrl+;, pas une formule.' : 'I1 : appuyez sur Ctrl+; puis Entrée.');
        if (!isF(F, 'I2') || !raw(F, 'I2').includes('AUJOURDHUI')) m.push('I2 : =AUJOURDHUI().');
        return m.length ? KO(m.join(' ')) : OK('I1 est figée, I2 avancera demain.'); } },
  ];

  // ---------- SCORM 1.2 ----------
  const SC = (() => { let api = null; function find(w) { let n = 0; while (w && !w.API && w.parent && w.parent !== w && n < 10) { w = w.parent; n++; } return w && w.API ? w.API : null; }
    try { api = find(window) || (window.opener && find(window.opener)); } catch (e) {}
    const call = (f, ...a) => { try { return api ? api[f](...a) : ''; } catch (e) { return ''; } };
    return { api: () => !!api, init: () => call('LMSInitialize', ''), get: k => call('LMSGetValue', k), set: (k, x) => call('LMSSetValue', k, String(x)), commit: () => call('LMSCommit', ''), finish: () => call('LMSFinish', '') }; })();
  SC.init();
  const susp = SC.get('cmi.suspend_data'); const local = A.savedLocal();
  if (susp && susp.length > 2) A.load(susp); else if (local) A.load(local);
  let saveT; window.onSave = d => { clearTimeout(saveT); saveT = setTimeout(() => { SC.set('cmi.suspend_data', d.length < 60000 ? d : ''); SC.commit(); }, 800); };
  window.addEventListener('beforeunload', () => { SC.commit(); SC.finish(); });

  // ---------- panneau ----------
  let cur = 0; const done = new Set(); let lastScore = -1;
  const el = document.getElementById('steps');
  function draw(res) {
    el.innerHTML = STEPS.map((s, i) => `<div class="st${res[i].ok ? ' ok' : ''}${i === cur ? ' on' : ''}" data-i="${i}">
      <div class="hd"><span class="ic">${res[i].ok ? '✓' : i + 1}</span><span>${s.t}</span></div>
      <div class="bd"><p><span class="lab">Faites :</span> ${s.faites}</p><p><span class="lab">Vous devez voir :</span> ${s.voir}</p>${s.pourquoi ? `<p><span class="lab">Pourquoi :</span> ${s.pourquoi}</p>` : ''}
      <div class="fb ${res[i].ok ? 'ok' : 'ko'}">${res[i].ok ? '✓ ' : ''}${res[i].msg}</div>
      <div class="btns"><button class="b" data-go="${i}">Aller à la cellule</button>${i < STEPS.length - 1 ? `<button class="b p" data-next="${i}">Étape suivante →</button>` : ''}</div></div></div>`).join('')
      + (res.every(r => r.ok) ? '<div class="done"><b>Atelier terminé.</b> Toutes les étapes sont validées. Passez au quiz de contrôle, en bas de la section.</div>' : '');
  }
  function evaluate() {
    const res = STEPS.map(s => { try { return s.check(); } catch (e) { return KO('Étape à faire.'); } });
    res.forEach((r, i) => { if (r.ok && !done.has(i)) { done.add(i); } });
    const n = res.filter(r => r.ok).length; document.getElementById('pt').textContent = n + ' / 9'; document.getElementById('pb').style.width = (n / 9 * 100) + '%';
    const scroll = el.scrollTop; draw(res); el.scrollTop = scroll;
    const score = Math.round(n / 9 * 100); if (score !== lastScore) { lastScore = score; SC.set('cmi.core.score.min', 0); SC.set('cmi.core.score.max', 100); SC.set('cmi.core.score.raw', score); SC.set('cmi.core.lesson_status', n === 9 ? 'completed' : 'incomplete'); SC.commit(); }
    return res;
  }
  window.onWorkbookChange = () => { const before = done.size; const res = evaluate(); if (res[cur] && res[cur].ok && !evaluate.prevOk) {} };
  el.addEventListener('click', ev => {
    const g = ev.target.closest('[data-go]'), nx = ev.target.closest('[data-next]'), hd = ev.target.closest('.hd');
    if (g) { const s = STEPS[+g.dataset.go]; A.goto(s.go[0], s.go[1]); return; }
    if (nx) { cur = +nx.dataset.next + 1; evaluate(); const s = STEPS[cur]; A.goto(s.go[0], s.go[1]); return; }
    if (hd) { cur = +hd.parentElement.dataset.i; evaluate(); }
  });
  let armed = false; const rb = document.getElementById('reset');
  rb.addEventListener('click', () => { if (!armed) { armed = true; rb.textContent = 'Confirmer la remise à zéro'; rb.classList.add('p'); setTimeout(() => { armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); }, 4000); return; }
    armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); A.reset(); cur = 0; done.clear(); evaluate(); });
  // première étape non faite
  const r0 = evaluate(); cur = Math.max(0, r0.findIndex(r => !r.ok)); if (cur < 0) cur = 0; evaluate();
})();
