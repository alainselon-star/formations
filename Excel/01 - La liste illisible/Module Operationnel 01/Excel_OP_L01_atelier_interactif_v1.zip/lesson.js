// Atelier 01 interactif — La liste illisible
(function () {
  'use strict';
  const A = XLAPP, P = 0;
  const v = ref => A.val(P, ref), c = ref => A.cell(P, ref) || {};
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });
  const rows = []; for (let r = 4; r <= 28; r++) rows.push(r);
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  const W = window.WB[0].cells, orig = ref => W[ref] ? String(W[ref].v) : '';
  const S = [];

  S.push({ t: 'Diagnostiquer la liste', go: [P, 'H4'], tg: [P, ['L4:L5']],
    need: 'Sophie doit envoyer les factures de février à l\'expert-comptable. Karim les a saisies dans l\'urgence : des dates avec des points, des montants suivis de « euros » ou « EUR ». Avant de corriger, on fait le diagnostic : pour Excel, ces montants sont-ils des nombres ?',
    ou: 'Cliquez sur la lettre <b>H</b> (en haut de la colonne) et lisez la barre d\'état, en bas à droite. Notez vos constats dans les cellules jaunes : <b>L4</b> et <b>L5</b>.',
    verif: 'L4 : combien de montants Excel reconnaît comme des nombres. L5 : le nombre affiché par la barre d\'état. Remarquez aussi de quel côté de la cellule les montants sont calés.',
    h: ['Un nombre se cale à droite de la cellule, un texte à gauche. Ici, tous les montants sont à gauche.', 'La barre d\'état affiche « Nombre » (les cellules non vides) mais aucune « Somme » : la Somme ne compte que les vrais nombres.'],
    sol: 'L4 : <code>0</code> (aucun montant n\'est un nombre) ; L5 : <code>26</code> (25 montants + l\'en-tête ; 25 si vous avez sélectionné H4:H28).',
    cells: () => [[P, 'L4', v('L4') === 0 ? null : (v('L4') === 25 ? 'La barre d\'état affiche-t-elle une Somme ? Non : aucun montant n\'est un vrai nombre.' : 'Combien de montants sont calés à droite ? Aucun.')],
      [P, 'L5', v('L5') === 26 || v('L5') === 25 ? null : 'Lisez « Nombre : … » dans la barre d\'état, la colonne H sélectionnée.']],
    check() { return summary(this.cells(), 'Diagnostic posé : 26 cellules non vides, mais 0 nombre. Pour Excel, « 6370 EUR » est un texte : impossible de l\'additionner.'); } });

  S.push({ t: 'Des montants en vrais nombres', go: [P, 'H4'], tg: [P, ['H4:H28']],
    need: 'Il faut retirer « euros » et « EUR » de tous les montants, sans retaper un seul chiffre.',
    ou: 'Colonne <b>H</b>, de H4 à H28. Outil : <b>Rechercher / Remplacer</b> (bouton du ruban ou Ctrl+H).',
    verif: 'Les 25 montants passent à droite. Sélectionnez la colonne H : la barre d\'état affiche maintenant une Somme.',
    h: ['Sélectionnez la colonne H, ouvrez Rechercher / Remplacer. Rechercher : « euros » précédé d\'une espace ; Remplacer par : rien ; Remplacer tout. Puis la même chose avec « EUR ».', 'L\'ordre compte : Excel ne respecte pas la casse par défaut, donc « EUR » se trouve aussi dans « euros ». Commencez par « euros ».'],
    sol: 'Colonne H sélectionnée → Ctrl+H → Rechercher <code> euros</code> (espace devant), Remplacer par vide → Remplacer tout ; puis <code> EUR</code> → Remplacer tout.',
    cells: () => rows.map(r => { const ref = 'H' + r, x = v(ref); let w = null;
      if (typeof x !== 'number') { const t = String(x == null ? '' : x); w = /os\s*$/i.test(t) && !/euros/i.test(t) ? `« ${t} » : « EUR » a été remplacé avant « euros » et a mangé le début du mot. Ctrl+Z, puis remplacez « euros » en premier.` : `« ${t} » est encore du texte : il reste des lettres à retirer.`; }
      else if (x !== +orig(ref).split(/\s/)[0]) w = 'Ce montant a changé : il devait rester ' + orig(ref).split(/\s/)[0] + '.';
      return [P, ref, w]; }),
    check() { return summary(this.cells(), 'Les 25 montants sont de vrais nombres, calés à droite : la barre d\'état affiche enfin une Somme.'); } });

  S.push({ t: 'Des dates en vraies dates', go: [P, 'A4'], tg: [P, ['A4:A28']],
    need: 'Les dates sont écrites avec des points (02.02.2026) : pour Excel, ce sont des textes. Il faut les transformer en vraies dates, sans rien abîmer d\'autre dans la liste.',
    ou: 'Colonne <b>A</b>, de A4 à A28, avec Rechercher / Remplacer.',
    verif: 'Les 25 dates passent à droite. Le reste de la liste n\'a pas bougé (attention aux autres cellules qui contiennent un point).',
    h: ['Remplacez le point « . » par la barre oblique « / » : Excel relit alors chaque cellule comme une date tapée au clavier.', 'Sélectionnez d\'abord la colonne A. Si une seule cellule est sélectionnée, Excel remplace dans toute la feuille… y compris dans « Faure S.A.R.L. ».'],
    sol: 'Colonne A sélectionnée → Ctrl+H → Rechercher <code>.</code>, Remplacer par <code>/</code> → Remplacer tout.',
    cells: () => { const o = rows.map(r => { const ref = 'A' + r, x = v(ref); return [P, ref, typeof x === 'number' ? null : `« ${x} » est encore du texte : remplacez les points par des barres obliques.`]; });
      const d = c('D22').raw; if (d !== orig('D22')) o.unshift([P, 'D22', `« ${d} » : le remplacement a touché toute la feuille. Ctrl+Z, sélectionnez la colonne A, et recommencez.`]); return o; },
    check() { return summary(this.cells(), 'Les 25 dates sont de vraies dates : Excel saura les trier et calculer des délais.'); } });

  S.push({ t: 'Habiller les nombres', go: [P, 'H4'], tg: [P, ['A4:A28', 'H4:H28']],
    need: 'Sophie veut des montants lisibles (« 6 370 € ») et des dates avec le jour de la semaine (« lun. 02/02/2026 »), comme dans ses autres tableaux.',
    ou: 'Colonne <b>H</b> : format <b>Monétaire (0 déc.)</b>. Colonne <b>A</b> : format <b>Date avec jour</b>. Liste « Nombre » du ruban, ou clic droit → Format de cellule.',
    verif: 'Les montants affichent l\'espace des milliers et le symbole €, sans décimales. Cliquez sur un montant : la barre de formule montre toujours le nombre seul.',
    h: ['Sélectionnez la colonne entière (clic sur la lettre), puis choisissez le format dans la liste « Nombre ».', 'Le format ne change jamais la valeur : il l\'habille. C\'est pour ça qu\'on nettoie d\'abord, et qu\'on habille ensuite.'],
    sol: 'Colonne H → Monétaire (0 déc.) ; colonne A → Date avec jour. (Dans Excel : Monétaire puis Réduire les décimales, et Ctrl+1 → Personnalisée → <code>jjj jj/mm/aaaa</code>.)',
    cells: () => rows.map(r => [P, 'H' + r, c('H' + r).f === 'eur0' ? null : (c('H' + r).f === 'eur2' ? 'Monétaire avec décimales : choisissez « Monétaire (0 déc.) ».' : 'Format Monétaire (0 déc.) attendu.')])
      .concat(rows.map(r => [P, 'A' + r, c('A' + r).f === 'djour' ? null : 'Format « Date avec jour » attendu.'])),
    check() { return summary(this.cells(), 'Montants en euros, dates avec le jour : la valeur ne change pas, seul l\'affichage change.'); } });

  S.push({ t: 'Présenter la liste', go: [P, 'A1'], tg: [P, ['A1', 'A3:I3']],
    need: 'Avant l\'envoi, Sophie veut un titre correct et des en-têtes qui se distinguent des données.',
    ou: 'Cellule <b>A1</b> : corrigez le titre en « Factures de février 2026 ». Ligne <b>3</b>, de A3 à I3 : mettez les en-têtes en <b>gras</b>.',
    verif: 'Le titre commence par une majuscule. Les neuf en-têtes sont en gras.',
    h: ['Pour corriger A1 : sélectionnez-la et tapez le nouveau texte (ou F2 pour modifier).', 'Sélectionnez A3:I3 puis bouton G du ruban (ou Ctrl+G). Dans Excel, vous ajouteriez aussi un remplissage, des bordures et l\'ajustement des colonnes : c\'est dans l\'exercice « Pour aller plus loin ».'],
    sol: 'A1 : <code>Factures de février 2026</code> ; A3:I3 → G (Ctrl+G).',
    cells: () => [[P, 'A1', String(c('A1').raw || '').trim() === 'Factures de février 2026' ? null : 'Le titre attendu est « Factures de février 2026 ».']]
      .concat('ABCDEFGHI'.split('').map(L => [P, L + '3', c(L + '3').b ? null : 'Cet en-tête n\'est pas en gras.'])),
    check() { return summary(this.cells(), 'Titre et en-têtes propres : la liste se lit d\'un coup d\'œil.'); } });

  S.push({ t: 'Lire le total', go: [P, 'L6'], tg: [P, ['L6']],
    need: 'L\'expert-comptable demande le total HT des factures de février. Maintenant que les montants sont de vrais nombres, la barre d\'état le donne sans aucune formule.',
    ou: 'Sélectionnez <b>H4:H28</b>, lisez la Somme dans la barre d\'état, et notez-la en <b>L6</b>.',
    verif: 'L6 contient le total des 25 montants. Si vous trouvez moins, un montant est resté du texte : cherchez la cellule calée à gauche.',
    h: ['Cliquez sur H4, puis Maj + clic sur H28 : la barre d\'état affiche Moyenne, Nombre et Somme.', 'Tapez le nombre lu (sans l\'espace ni le €) en L6.'],
    sol: 'H4:H28 → Somme : 120 920 € → tapez <code>120920</code> en L6.',
    cells: () => [[P, 'L6', v('L6') === 120920 ? null : (v('L6') == null || v('L6') === '' ? 'Notez ici la Somme lue dans la barre d\'état.' : 'Ce n\'est pas la Somme de H4:H28. Tous les montants sont-ils à droite ?')]],
    check() { return summary(this.cells(), '120 920 € : le total est juste parce que les 25 montants sont de vrais nombres. À la leçon 2, vous l\'écrirez avec SOMME, pour qu\'il se mette à jour seul.'); } });

  window.LESSON = { steps: S };
})();
