// Atelier 04 interactif — Le tableau qui réfléchit
(function () {
  'use strict';
  const A = XLAPP, P = 0;
  const v = ref => A.val(P, ref), c = ref => A.cell(P, ref) || {};
  const isF = ref => c(ref).ast !== undefined;
  const raw = ref => String(c(ref).raw || '').toUpperCase().replace(/\s/g, '');
  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.005;
  const R = range(4, 123), H = r => v('H' + r), I = r => v('I' + r);
  const nof = ref => !isF(ref) ? 'Pas de formule : il faut un calcul qui commence par =.' : null;
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  const S = [];

  S.push({ t: 'L\'acompte à demander', go: [P, 'J4'], tg: [P, ['J4:J123']],
    need: 'Sophie demande un acompte de 30 % sur les devis d\'au moins 3 000 €, et rien en dessous. Le seuil (O3) et le taux (O4) sont rangés dans les cellules jaunes : ils pourront changer.',
    ou: 'Feuille <b>Devis T1</b>, colonne <b>J</b> « Acompte », de J4 à J123.',
    verif: 'Une seule formule, recopiée. Elle utilise O3 et O4, pas 3000 ni 30 % tapés dans la formule. Un devis de 3 000 € pile a bien un acompte.',
    h: ['Il faut une fonction qui choisit entre deux réponses selon une condition : SI(test ; si vrai ; si faux).', 'Le test compare le montant au seuil avec >= ; le seuil et le taux se bloquent avec F4 ($O$3, $O$4).'],
    sol: 'J4 : <code>=SI(H4&gt;=$O$3;H4*$O$4;0)</code>, puis recopie.',
    cells: () => R.map(r => { const ref = 'J' + r, x = raw(ref); let w = nof(ref);
      if (!w && !/O\$?3/.test(x) || (!w && !/O\$?4/.test(x))) w = /3000|30%|0,3/.test(x) ? 'Seuil ou taux tapé dans la formule : utilisez O3 et O4.' : 'La formule doit utiliser le seuil (O3) et le taux (O4).';
      const exp = H(r) >= v('O3') ? H(r) * v('O4') : 0;
      if (!w && !near(v(ref), exp)) w = H(r) === v('O3') ? 'Montant égal au seuil : il faut >=, pas >.' : (/O\d/.test(x) && !/O\$3/.test(x) ? 'Le seuil ou le taux a glissé : il manque les $.' : 'Ce n\'est pas l\'acompte de ce devis.');
      return [P, ref, w]; }),
    check() { return summary(this.cells(), 'Acomptes justes : 900 € pour le devis à 3 000 € pile (ligne 7), 1 500 € pour celui à 5 000 €.'); } });

  S.push({ t: 'Le total, et un seuil qui change', go: [P, 'J124'], tg: [P, ['J124', 'O3', 'O7']],
    need: 'Sophie veut le total des acomptes du trimestre. Puis elle se demande : « Et si on baissait le seuil à 2 500 € ? »',
    ou: 'Le total en <b>J124</b>. Puis tapez 2 500 en <b>O3</b>, notez le nouveau total en <b>O7</b> (en face de « Total si seuil à 2 500 € »), et remettez 3 000 en O3.',
    verif: 'J124 est une formule. O7 contient le total obtenu avec le seuil à 2 500 €. O3 est revenu à 3 000 €.',
    h: ['Le total est une simple somme de la colonne J.', 'Une fois O3 changé, toute la colonne J et J124 se recalculent seuls : il suffit de lire J124 et de recopier ce nombre en O7.'],
    sol: 'J124 : <code>=SOMME(J4:J123)</code> → 105 351 €. O3 = 2500 → J124 affiche 109 536 € → tapez <code>109536</code> en O7 → O3 = 3000.',
    cells: () => [['J124', !isF('J124') ? 'Il faut une formule de total.' : !near(v('J124'), R.reduce((s, r) => s + (H(r) >= v('O3') ? H(r) * v('O4') : 0), 0)) ? 'Ce n\'est pas le total de la colonne J.' : null],
      ['O3', v('O3') === 3000 ? null : 'Remettez le seuil à 3 000 €.'],
      ['O7', near(v('O7'), 109536) ? null : (v('O7') == null || v('O7') === '' ? 'Notez ici le total obtenu avec un seuil à 2 500 €.' : 'Ce n\'est pas le total obtenu avec un seuil à 2 500 €.')]].map(x => [P, ...x]),
    check() { return summary(this.cells(), '105 351 € avec un seuil à 3 000 €, 109 536 € à 2 500 € : changer une cellule suffit, aucune formule à retoucher.'); } });

  S.push({ t: 'Les devis à relancer', go: [P, 'K4'], tg: [P, ['K4:K123', 'O8']],
    need: 'Thomas doit relancer les clients dont le devis est « En attente ». Sophie veut voir « Relancer » sur ces lignes, et rien sur les autres. Puis : combien y en a-t-il ?',
    ou: 'Colonne <b>K</b> « Relance », de K4 à K123 ; puis le nombre en <b>O8</b>.',
    verif: '« Relancer » exactement sur les devis en attente, une cellule vide ailleurs. En O8, le nombre de devis à relancer.',
    h: ['Le test compare le statut (colonne I) au texte « En attente ». Un texte s\'écrit entre guillemets.', 'Pour « rien », on écrit deux guillemets collés : "". Pour compter : sélectionnez la colonne K, ou utilisez NB.SI.'],
    sol: 'K4 : <code>=SI(I4="En attente";"Relancer";"")</code>, recopie ; O8 : <code>44</code> (ou <code>=NB.SI(K4:K123;"Relancer")</code>).',
    cells: () => R.map(r => { const ref = 'K' + r; let w = nof(ref); const x = v(ref);
      if (!w && x && typeof x === 'object') w = x.err === '#NOM?' ? '#NOM? : un texte est écrit sans guillemets.' : 'Erreur ' + x.err;
      if (!w) { const exp = I(r) === 'En attente' ? 'Relancer' : ''; const got = x == null || x === 0 ? '' : String(x); if (got !== exp) w = exp ? 'Ce devis est en attente : il faut « Relancer ».' : 'Ce devis n\'est pas en attente : la cellule doit rester vide.'; }
      return [P, ref, w]; }).concat([[P, 'O8', v('O8') === 44 ? null : 'Ce n\'est pas le nombre de devis à relancer.']]),
    check() { return summary(this.cells(), '44 devis à relancer sur 120.'); } });

  S.push({ t: 'Deux conditions à la fois', go: [P, 'M4'], tg: [P, ['M4:M123']],
    need: 'Sophie précise : l\'acompte ne concerne que les devis <b>acceptés</b>. Il faut donc deux conditions en même temps : montant au moins égal au seuil, et statut « Accepté ».',
    ou: 'Colonne <b>M</b> « Acompte accepté », de M4 à M123.',
    verif: 'Un acompte seulement quand les deux conditions sont vraies, 0 sinon. Sélectionnez la colonne : la somme fait 44 274 €.',
    h: ['Une fonction répond VRAI seulement si toutes ses conditions sont vraies : ET(condition1 ; condition2).', 'Placez ET(…) comme test du SI : SI(ET(…) ; montant × taux ; 0).'],
    sol: 'M4 : <code>=SI(ET(H4&gt;=$O$3;I4="Accepté");H4*$O$4;0)</code>, puis recopie.',
    cells: () => R.map(r => { const ref = 'M' + r; let w = nof(ref); const exp = H(r) >= v('O3') && I(r) === 'Accepté' ? H(r) * v('O4') : 0;
      if (!w && !near(v(ref), exp)) w = exp === 0 ? (H(r) >= v('O3') ? 'Ce devis n\'est pas accepté : pas d\'acompte.' : 'Montant sous le seuil : pas d\'acompte.') : 'Ce devis remplit les deux conditions : il faut l\'acompte.';
      return [P, ref, w]; }),
    check() { return summary(this.cells(), '44 274 € d\'acomptes sur les seuls devis acceptés : ET exige que les deux conditions soient vraies.'); } });

  S.push({ t: 'Petit, moyen ou gros', go: [P, 'L4'], tg: [P, ['L4:L123', 'O9']],
    need: 'Sophie veut classer chaque chantier : « Petit » sous 1 500 €, « Moyen » de 1 500 € à moins de 5 000 €, « Gros » à partir de 5 000 €. Puis : combien de gros chantiers ?',
    ou: 'Colonne <b>L</b> « Taille », de L4 à L123 ; puis le nombre en <b>O9</b>.',
    verif: 'Les cas limites comptent : 1 500 € pile (D-2026-011) donne « Moyen », 5 000 € pile (D-2026-018) donne « Gros ».',
    h: ['Trois réponses possibles : il faut un SI dans un SI. Le premier teste « Petit », sinon le second départage « Moyen » et « Gros ».', 'Testez dans l\'ordre : &lt;1500, puis &lt;5000. Deux SI, donc deux parenthèses fermantes à la fin.'],
    sol: 'L4 : <code>=SI(H4&lt;1500;"Petit";SI(H4&lt;5000;"Moyen";"Gros"))</code>, recopie ; O9 : <code>26</code>.',
    cells: () => R.map(r => { const ref = 'L' + r; let w = nof(ref); const h = H(r), exp = h < 1500 ? 'Petit' : h < 5000 ? 'Moyen' : 'Gros', x = v(ref);
      if (!w && x !== exp) w = (h === 1500 || h === 5000) ? `Cas limite (${h} €) : on attend « ${exp} ». Vérifiez < ou <=.` : (exp === 'Petit' && x === 'Moyen' ? 'Aucun « Petit » ? L\'ordre des tests est inversé.' : `On attend « ${exp} ».`);
      return [P, ref, w]; }).concat([[P, 'O9', v('O9') === 26 ? null : 'Ce n\'est pas le nombre de gros chantiers.']]),
    check() { return summary(this.cells(), '26 gros chantiers. L\'ordre des questions compte : on teste d\'abord le plus petit seuil.'); } });

  window.LESSON = { steps: S };
})();
