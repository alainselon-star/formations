// Atelier 15 interactif — Coller autrement
(function () {
  'use strict';
  const A = XLAPP, TB = 'Tableau de bord', CP = 'Pour le comptable', PL = 'Planning', CA = 'Catalogue', VE = 'Ventes';
  const v = (s, r) => A.val(s, r), c = (s, r) => A.cell(s, r) || {};
  const isF = (s, r) => c(s, r).ast !== undefined;
  const raw = (s, r) => String(c(s, r).raw || '').toUpperCase().replace(/\s/g, '');
  const OK = m => ({ ok: true, msg: m }), KO = m => ({ ok: false, msg: m });
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.005;
  const empty = (s, r) => { const x = c(s, r).raw; return x === undefined || x === ''; };
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  const W = window.WB, orig = (s, r) => { const sh = W.find(x => x.name === s); return sh && sh.cells[r] ? sh.cells[r].v : undefined; };
  const MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
  const rows = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const S = [];

  S.push({ t: 'Ce que colle Ctrl+V', go: [TB, 'A3'], tg: [CP, ['A3:C13']],
    need: 'Le comptable veut les chiffres du tableau de bord, mais <b>sans formules</b> : il les archive tels quels. Avant de bien faire, voyons ce que colle un Ctrl+V ordinaire.',
    ou: 'Feuille <b>Tableau de bord</b> : copiez A3:C13 (Ctrl+C). Feuille <b>Pour le comptable</b> : cliquez en <b>A3</b> et faites Ctrl+V. Cliquez ensuite sur B4 et regardez la barre de formule.',
    verif: 'En B4 de « Pour le comptable », la barre de formule montre =SOMME(Ventes!B2:F2) : une formule, pas un chiffre. Gardez ce résultat pour la vérification, la mission suivante le remplacera.',
    h: ['Sélectionnez A3:C13 sur le Tableau de bord, Ctrl+C, changez de feuille, cliquez en A3, Ctrl+V.', 'Ctrl+V colle tout : la formule, la valeur et le format. Dans un autre classeur, ces formules deviendraient des liaisons vers votre fichier.'],
    sol: 'Tableau de bord A3:C13 → Ctrl+C → Pour le comptable A3 → Ctrl+V.',
    cells: () => [[CP, 'B4', (isF(CP, 'B4') && /VENTES!/.test(raw(CP, 'B4'))) || (!isF(CP, 'B4') && near(v(CP, 'B4'), 95510) && !isF(CP, 'B13') && near(v(CP, 'B13'), 1005130)) ? null : (empty(CP, 'B4') ? 'Rien en B4 : collez A3:C13 du Tableau de bord en A3.' : 'B4 ne contient pas la formule collée : faites un Ctrl+V ordinaire.')]],
    check() { return summary(this.cells(), 'Ctrl+V a collé des formules : =SOMME(Ventes!B2:F2). Pas question d\'envoyer ça au comptable. Passez à la mission suivante.'); } });

  S.push({ t: 'Les valeurs pour le comptable', go: [CP, 'A3'], tg: [CP, ['A3:C13']],
    need: 'Il faut les mêmes chiffres, en euros et en pourcentages, mais figés : des nombres, sans aucune formule.',
    ou: 'Recopiez A3:C13 du <b>Tableau de bord</b>, puis feuille <b>Pour le comptable</b>, cliquez en <b>A3</b> : <b>Ctrl+Alt+V</b> (ou clic droit → Collage spécial…) et choisissez la bonne option.',
    verif: 'De A3 à C13 : plus aucune formule (cliquez sur B4 : 95510 dans la barre). Les montants gardent leurs euros (95 510 €), les parts leurs pourcentages.',
    h: ['« Valeurs » colle les chiffres mais perd les formats : 95510 au lieu de 95 510 €, 0,095 au lieu de 9,5 %.', 'Choisissez « Valeurs et formats des nombres » : les chiffres et leur habillage, sans les formules.'],
    sol: 'Tableau de bord A3:C13 → Ctrl+C → Pour le comptable A3 → Ctrl+Alt+V → <b>Valeurs et formats des nombres</b> → OK.',
    cells: () => { const o = []; for (const r of rows(3, 13)) for (const L of 'ABC') { const ref = L + r; let w = null;
        if (isF(CP, ref)) w = 'Encore une formule : collez les valeurs, pas Tout.';
        else { const exp = A.val(TB, ref); if (exp !== null && exp !== '' && (typeof exp === 'number' ? !near(v(CP, ref), exp) : v(CP, ref) !== exp)) w = empty(CP, ref) ? 'Cellule vide : collez A3:C13 à partir de A3.' : 'Ce n\'est pas la valeur du tableau de bord.';
          else if (r >= 4 && L === 'B' && c(CP, ref).f !== 'eur0') w = 'Le format € a été perdu : choisissez « Valeurs et formats des nombres ».';
          else if (r >= 4 && L === 'C' && c(CP, ref).f !== 'pct1') w = 'Le format % a été perdu : choisissez « Valeurs et formats des nombres ».'; }
        o.push([CP, ref, w]); } return o; },
    check() { return summary(this.cells(), '95 510 € pour janvier, 1 005 130 € sur l\'année : des nombres habillés, sans aucune formule ni liaison.'); } });

  S.push({ t: 'Des valeurs figées', go: [VE, 'B2'], tg: [CP, ['E5']],
    need: 'Sophie corrige une vente de janvier dans la feuille Ventes. Que deviennent le tableau de bord et la copie du comptable ?',
    ou: 'Feuille <b>Ventes</b>, B2 : tapez 61350. Regardez <b>Tableau de bord</b> B4, puis <b>Pour le comptable</b> B4. Notez le nouveau montant du Tableau de bord en <b>E5</b> de « Pour le comptable ». Puis remettez 51350 en Ventes B2.',
    verif: 'E5 contient le montant de janvier du Tableau de bord avec 61 350. « Pour le comptable » B4 est resté à 95 510 €. Ventes B2 est revenu à 51 350.',
    h: ['Le Tableau de bord se recalcule : janvier gagne 10 000 €. La copie en valeurs, elle, ne bouge pas.', 'Tapez le nombre lu en E5 (sans formule), puis retournez sur Ventes remettre 51350.'],
    sol: 'Ventes B2 = 61350 → Tableau de bord B4 = 105 510 € → tapez <code>105510</code> en E5 → Ventes B2 = 51350.',
    cells: () => [[CP, 'E5', near(v(CP, 'E5'), 105510) ? null : (empty(CP, 'E5') ? 'Notez ici le montant de janvier du Tableau de bord avec 61 350.' : 'Ce n\'est pas le montant du Tableau de bord avec 61 350.')],
      [VE, 'B2', v(VE, 'B2') === 51350 ? null : 'Remettez 51 350 en Ventes B2.'], [CP, 'B4', near(v(CP, 'B4'), 95510) ? null : 'La copie du comptable a bougé : ce ne sont pas des valeurs figées (refaites la mission 2).']],
    check() { return summary(this.cells(), '105 510 € au Tableau de bord, 95 510 € chez le comptable : des valeurs collées ne suivent plus l\'origine. C\'est voulu pour un envoi.'); } });

  S.push({ t: 'Transposer les mois', go: [PL, 'A8'], tg: [PL, ['B1:M1']],
    need: 'Dans le planning, les commerciaux sont en lignes. Sophie veut les mois <b>en colonnes</b>, de B1 à M1, sans les retaper. Ils sont pour l\'instant listés en colonne A.',
    ou: 'Feuille <b>Planning</b> : copiez <b>A8:A19</b>, cliquez en <b>B1</b>, Ctrl+Alt+V → cochez <b>Transposé</b> → OK. Effacez ensuite A7:A19.',
    verif: 'Janvier en B1, Février en C1… Décembre en M1. La colonne A ne garde que « Commercial » et les trois noms.',
    h: ['« Transposé » fait pivoter la plage : une colonne devient une ligne, et inversement.', 'La zone d\'arrivée ne doit pas chevaucher la zone copiée : cliquez bien en B1, pas en A7.'],
    sol: 'A8:A19 → Ctrl+C → B1 → Ctrl+Alt+V → <b>Transposé</b> → OK → A7:A19 → Suppr.',
    cells: () => { const o = MOIS.map((m, i) => { const ref = String.fromCharCode(66 + i) + '1'; return [PL, ref, v(PL, ref) === m ? null : (empty(PL, ref) ? 'Vide : collez les mois transposés à partir de B1.' : `On attend « ${m} ».`)]; });
      let rest = 0; for (const r of rows(7, 19)) if (!empty(PL, 'A' + r)) rest++;
      o.push([PL, 'A8', rest ? `Il reste ${rest} cellule${rest > 1 ? 's' : ''} en A7:A19 : effacez la liste d'origine.` : null]);
      o.push([PL, 'A2', v(PL, 'A2') === 'Julie' && v(PL, 'A3') === 'Thomas' && v(PL, 'A4') === 'Sophie' ? null : 'Les commerciaux en A2:A4 ont été modifiés.']); return o; },
    check() { return summary(this.cells(), 'Douze mois en ligne, en un seul collage, sans faute de frappe possible.'); } });

  S.push({ t: '+5 % sur tout le catalogue', go: [CA, 'C2'], tg: [CA, ['C2:C40']],
    need: 'Le fournisseur augmente ses prix de 5 %. Sophie veut les nouveaux prix <b>à la place</b> des anciens, dans la colonne C, sans colonne de formules en plus. Le coefficient 1,05 est déjà prêt en F1.',
    ou: 'Feuille <b>Catalogue</b> : copiez <b>F1</b>, sélectionnez <b>C2:C40</b>, Ctrl+Alt+V → choisissez ce qu\'il faut coller et l\'opération → OK. Effacez ensuite F1.',
    verif: 'A001 passe de 89,00 € à 93,45 €. Sélectionnez C2:C40 : la Somme passe de 2 603,00 € à 2 733,15 €. Les prix gardent leur format en euros, et ce sont des nombres, pas des formules.',
    h: ['L\'opération « Multiplication » multiplie chaque cellule de la sélection par ce qui a été copié.', 'Collez « Valeurs » + « Multiplication » : avec « Tout », les prix prendraient aussi le format de F1 et perdraient leurs euros.'],
    sol: 'F1 → Ctrl+C → C2:C40 → Ctrl+Alt+V → Coller : <b>Valeurs</b>, Opération : <b>Multiplication</b> → OK → F1 → Suppr.',
    cells: () => { const o = rows(2, 40).map(r => { const ref = 'C' + r, p = orig(CA, ref), x = v(CA, ref); let w = null;
        if (isF(CA, ref)) w = 'Une formule : la multiplication doit se faire par collage spécial, sans formule.';
        else if (near(x, p * 1.05)) w = c(CA, ref).f !== 'eur2' ? 'Le prix a perdu son format € : vous avez collé « Tout ». Ctrl+Z, puis « Valeurs » + Multiplication.' : null;
        else if (near(x, p + 1.05)) w = 'Addition au lieu de Multiplication : Ctrl+Z et choisissez Multiplication.';
        else if (near(x, p * 1.05 * 1.05)) w = 'Multiplié deux fois : Ctrl+Z.';
        else w = near(x, p) ? 'Prix inchangé : la multiplication n\'a pas touché cette cellule.' : 'Ce n\'est pas le prix +5 %.';
        return [CA, ref, w]; });
      o.push([CA, 'F1', empty(CA, 'F1') ? null : 'Effacez le coefficient en F1 une fois l\'opération faite.']); return o; },
    check() { return summary(this.cells(), '39 prix augmentés de 5 % sur place : 2 733,15 € au total, et toujours des nombres en euros.'); } });

  S.push({ t: 'Une copie qui suit', go: [TB, 'B13'], tg: [CP, ['E3']],
    need: 'Pour son propre suivi, Sophie veut aussi, sur la feuille du comptable, le total de l\'année qui <b>reste à jour</b> si une vente change.',
    ou: 'Feuille <b>Tableau de bord</b> : copiez <b>B13</b>. Feuille <b>Pour le comptable</b> : cliquez en <b>E3</b>, Ctrl+Alt+V → bouton <b>Coller avec liaison</b>.',
    verif: 'En E3, la barre de formule montre =\'Tableau de bord\'!$B$13, et la cellule affiche 1 005 130 €. Essayez : 61350 en Ventes B2, E3 passe à 1 015 130 €. Remettez 51350.',
    h: ['« Coller avec liaison » ne colle pas le chiffre : il crée une formule qui renvoie vers la cellule d\'origine.', 'Le bouton est en bas à gauche de la fenêtre Collage spécial.'],
    sol: 'Tableau de bord B13 → Ctrl+C → Pour le comptable E3 → Ctrl+Alt+V → <b>Coller avec liaison</b>.',
    cells: () => [[CP, 'E3', !isF(CP, 'E3') ? (empty(CP, 'E3') ? 'E3 est vide.' : 'E3 contient un nombre figé : utilisez « Coller avec liaison ».') : !/TABLEAUDEBORD'?!\$?B\$?13/.test(raw(CP, 'E3')) ? 'La liaison doit pointer vers Tableau de bord B13.' : null],
      [VE, 'B2', v(VE, 'B2') === 51350 ? null : 'Remettez 51 350 en Ventes B2.']],
    check() { return summary(this.cells(), 'Valeurs pour figer, liaison pour suivre : vous choisissez maintenant ce que vous collez.'); } });

  window.LESSON = { steps: S };
})();
