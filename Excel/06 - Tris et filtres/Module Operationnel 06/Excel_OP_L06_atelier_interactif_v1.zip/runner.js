// Moteur d'étapes commun : missions, indices, Vérifier, SCORM
(function () {
  'use strict';
  const A = XLAPP, K = (window.CFG && CFG.key) || 'xl';
  const STEPS = LESSON.steps, CC = STEPS.map(s => s.cells);
  const KO = (m) => ({ ok: false, msg: m });
  const AIDE = JSON.parse((() => { try { return localStorage.getItem(K + '-aide') || '{}'; } catch (e) { return '{}'; } })());
  const saveAide = () => { try { localStorage.setItem(K + '-aide', JSON.stringify(AIDE)); } catch (e) {} };

  const ESS = JSON.parse((() => { try { return localStorage.getItem(K + '-ess') || '{}'; } catch (e) { return '{}'; } })());
  const DONE = new Set(JSON.parse((() => { try { return localStorage.getItem(K + '-done') || '[]'; } catch (e) { return '[]'; } })()));
  const VR = {};
  const persist = () => { try { localStorage.setItem(K + '-ess', JSON.stringify(ESS)); localStorage.setItem(K + '-done', JSON.stringify([...DONE])); } catch (e) {} };

  // ---------- SCORM 1.2 ----------
  const SC = (() => { let api = null; function find(w) { let n = 0; while (w && !w.API && w.parent && w.parent !== w && n < 10) { w = w.parent; n++; } return w && w.API ? w.API : null; }
    try { api = find(window) || (window.opener && find(window.opener)); } catch (e) {}
    const call = (f, ...a) => { try { return api ? api[f](...a) : ''; } catch (e) { return ''; } };
    return { api: () => !!api, init: () => call('LMSInitialize', ''), get: k => call('LMSGetValue', k), set: (k, x) => call('LMSSetValue', k, String(x)), commit: () => call('LMSCommit', ''), finish: () => call('LMSFinish', '') }; })();
  SC.init();
  const susp = SC.get('cmi.suspend_data'); const local = A.savedLocal();
  const b64 = u8 => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const zip = async d => b64(new Uint8Array(await new Response(new Blob([d]).stream().pipeThrough(new CompressionStream('deflate-raw'))).arrayBuffer()));
  const unzip = async z => new Response(new Blob([Uint8Array.from(atob(z), c => c.charCodeAt(0))]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).text();
  let saveT; window.onSave = d => { clearTimeout(saveT); saveT = setTimeout(async () => { let x = d; if (d.length >= 60000) { try { x = 'z|' + await zip(d); } catch (e) { x = ''; } if (x.length >= 60000) x = ''; } SC.set('cmi.suspend_data', x); SC.commit(); }, 800); };
  (async () => {
  if (susp && susp.startsWith('z|')) { let d = null; try { d = await unzip(susp.slice(2)); } catch (e) {} if (d) A.load(d); else if (local) A.load(local); }
  else if (susp && susp.length > 2) A.load(susp); else if (local) A.load(local);
  window.addEventListener('beforeunload', () => { SC.commit(); SC.finish(); });

  // ---------- panneau ----------
  let cur = 0, lastScore = -1;
  const el = document.getElementById('steps');
  function draw() {
    el.innerHTML = STEPS.map((s, i) => { const lv = AIDE[i] || 0, ok = DONE.has(i), vr = VR[i], ne = ESS[i] || 0;
      const aides = s.h.slice(0, Math.min(lv, 2)).map((x, k) => `<div class="hint"><b>Indice ${k + 1} :</b> ${x}</div>`).join('') + (lv >= 3 ? `<div class="hint"><b>Solution :</b> ${s.sol}</div>` : '');
      const hbtn = ok ? '' : lv < 2 ? `<button class="b" data-h="${i}">Indice ${lv + 1}</button>` : lv === 2 ? `<button class="b" data-h="${i}">Voir la solution</button>` : '';
      const tags = [ne ? (ok ? `réussi au ${ne === 1 ? '1er' : ne + 'e'} essai` : `${ne} essai${ne > 1 ? 's' : ''}`) : '', lv ? (lv >= 3 ? 'avec la solution' : lv + ' indice' + (lv > 1 ? 's' : '')) : ''].filter(Boolean).join(' · ');
      const fb = vr ? `<div class="fb ${vr.ok ? 'ok' : 'ko'}">${vr.ok ? '✓ ' : ''}${vr.msg}${vr.summ ? `<div class="summ">${vr.summ}</div>` : ''}</div>` : (ok ? '' : '<div class="fb" style="background:#f4f6f5;color:#555">Faites l\'exercice dans le classeur, puis cliquez sur <b>Vérifier</b>.</div>');
      return `<div class="st${ok ? ' ok' : ''}${i === cur ? ' on' : ''}" data-i="${i}">
      <div class="hd"><span class="ic">${ok ? '✓' : i + 1}</span><span>${s.t}</span>${tags ? `<span class="lvl">${tags}</span>` : ''}</div>
      <div class="bd"><p class="need"><span class="lab">Le besoin :</span> ${s.need}</p><p class="where"><span class="lab">Où répondre :</span> ${s.ou}</p><p><span class="lab">Pour vérifier :</span> ${s.verif}</p>${aides}${fb}
      <div class="btns"><button class="b v" data-v="${i}">Vérifier</button>${hbtn}<button class="b" data-go="${i}">Aller à la cellule</button>${i < STEPS.length - 1 ? `<button class="b p" data-next="${i}">Suivant →</button>` : ''}</div></div></div>`; }).join('')
      + (DONE.size === STEPS.length ? `<div class="done"><b>Atelier terminé.</b> ${Object.keys(AIDE).length || Object.values(ESS).some(n => n > 1) ? 'Refaites plus tard les étapes où vous avez eu besoin d\'indices ou de plusieurs essais.' : 'Tout au premier essai, sans aide : bravo !'} Passez au quiz de contrôle, en bas de la section.</div>` : '');
  }
  function refresh() {
    const n = DONE.size; document.getElementById('pt').textContent = n + ' / ' + STEPS.length; document.getElementById('pb').style.width = (n / STEPS.length * 100) + '%';
    const scroll = el.scrollTop; draw(); el.scrollTop = scroll;
    if (STEPS[cur] && refresh.tgCur !== cur) { refresh.tgCur = cur; A.setTargets(STEPS[cur].tg[0], STEPS[cur].tg[1]); }
    const score = Math.round(n / STEPS.length * 100); if (score !== lastScore) { lastScore = score; SC.set('cmi.core.score.min', 0); SC.set('cmi.core.score.max', 100); SC.set('cmi.core.score.raw', score); SC.set('cmi.core.lesson_status', n === STEPS.length ? 'completed' : 'incomplete'); SC.commit(); }
  }
  function verify(i) {
    let res; try { res = STEPS[i].check(); } catch (e) { res = KO('Étape à faire.'); }
    const cells = CC[i](); const ko = cells.filter(x => x[2]), okc = cells.filter(x => !x[2]);
    const long = cells.length > 7; const marks = []; const si = A.idx(cells[0][0]);
    for (const [s2, ref, why] of cells) { if (A.idx(s2) !== si) continue; if (why) marks.push([ref, 'ko', why]); else if (!long) marks.push([ref, 'ok', '']); }
    if (A.sel().si !== si) A.goto(si, cells[0][1]);
    A.setMarks(si, marks);
    ESS[i] = (ESS[i] || 0) + (DONE.has(i) ? 0 : 1);
    if (res.ok) DONE.add(i);
    VR[i] = { ok: res.ok, msg: res.msg, summ: long ? `${okc.length} juste${okc.length > 1 ? 's' : ''}, ${ko.length} à revoir${ko.length ? ' (en rouge ; survolez une cellule pour voir pourquoi)' : ''}.` : (ko.length ? 'Survolez une cellule en rouge pour voir pourquoi.' : '') };
    persist(); refresh();
  }
  window.onWorkbookChange = () => {};
  el.addEventListener('click', ev => {
    const vb = ev.target.closest('[data-v]'); if (vb) { verify(+vb.dataset.v); return; }
    const hb = ev.target.closest('[data-h]'); if (hb) { const i = +hb.dataset.h; AIDE[i] = (AIDE[i] || 0) + 1; saveAide(); refresh(); return; }
    const g = ev.target.closest('[data-go]'), nx = ev.target.closest('[data-next]'), hd = ev.target.closest('.hd');
    if (g) { const s = STEPS[+g.dataset.go]; A.goto(s.go[0], s.go[1]); return; }
    if (nx) { cur = +nx.dataset.next + 1; A.clearMarks(); refresh(); const s = STEPS[cur]; A.goto(s.go[0], s.go[1]); return; }
    if (hd) { const i = +hd.parentElement.dataset.i; if (i !== cur) { cur = i; A.clearMarks(); } refresh(); }
  });
  let armed = false; const rb = document.getElementById('reset');
  rb.addEventListener('click', () => { if (!armed) { armed = true; rb.textContent = 'Confirmer la remise à zéro'; rb.classList.add('p'); setTimeout(() => { armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); }, 4000); return; }
    armed = false; rb.textContent = 'Recommencer'; rb.classList.remove('p'); A.reset(); cur = 0; DONE.clear(); for (const k in ESS) delete ESS[k]; for (const k in VR) delete VR[k]; persist(); A.clearMarks(); for (const k in AIDE) delete AIDE[k]; window.onLessonReset && window.onLessonReset(); saveAide(); refresh(); });
  // reprise : étapes déjà réussies (classeur rechargé) ; ouvrir la première étape non faite
  STEPS.forEach((s, i) => { try { if (s.check().ok) DONE.add(i); } catch (e) {} });
  cur = STEPS.findIndex((s, i) => !DONE.has(i)); if (cur < 0) cur = 0; refresh();
  })();
})();
