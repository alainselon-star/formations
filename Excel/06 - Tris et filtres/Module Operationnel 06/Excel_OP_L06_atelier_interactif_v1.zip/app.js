// Classeur interactif — atelier 17
(function () {
  'use strict';
  const { parse, makeEvaluator, parseText, display, shiftFormula, colToNum, numToCol, todaySerial } = XL;
  const EXTRA_ROWS = 4; let NCOLS = 10;
  // ---------- classeur ----------
  const TPL = WB.map(s => ({ name: s.name, w: s.w, nrows: s.rows + EXTRA_ROWS, ncols: s.cols || 10 }));
  const wb = { sheets: TPL.map((t, i) => ({ name: t.name, src: i, w: t.w, nrows: t.nrows, ncols: t.ncols, cells: {}, hid: new Set() })) };
  const DECOR = WB.map(s => { const d = {}; for (const ref in s.cells) { const o = s.cells[ref]; const x = {}; if (o.h) x.h = 1; if (o.l) x.l = 1; if (o.y) x.y = 1; if (o.list) x.list = o.list; if (Object.keys(x).length) d[ref] = x; } return d; });
  function setRaw(si, ref, raw, keepFmt) {
    const sh = wb.sheets[si]; const c = sh.cells[ref] || (sh.cells[ref] = {});
    c.raw = raw; delete c.ast; delete c.v;
    if (raw === '' || raw == null) { c.raw = ''; return; }
    if (typeof raw === 'string' && raw[0] === '=' && raw.length > 1 && c.f !== 'text') {
      try { c.ast = parse(raw.slice(1)); } catch (e) { c.ast = { k: 'lit', v: { err: e === 'comma' ? '#NOM?' : '#NOM?' } }; c.bad = true; }
      if (!keepFmt && (!c.f || c.f === 'gen')) { const af = autoFmt(si, raw); if (af) c.f = af; }
    } else if (typeof raw === 'string' && c.f !== 'text') {
      const p = parseText(raw); c.v = p.v;
      if (p.fmt === 'date' && !/^(date|dlong|djour)$/.test(c.f || '')) c.f = 'date';
      else if (p.fmt && (!c.f || c.f === 'gen')) c.f = p.fmt;
    } else c.v = raw;
  }
  function autoFmt(si, raw) {
    const f = raw.toUpperCase();
    if (/(DATEDIF|NB\.JOURS\.OUVRES|ANNEE|JOURSEM|NB\.SI|NBVAL|SOMME|MOYENNE|MAX|MIN)[.A-Z]*\(|\bMOIS\(|\bJOUR\(|\bNB\(/.test(f)) return null;
    if (/(AUJOURDHUI|DATE|MOIS\.DECALER|FIN\.MOIS)\(/.test(f)) return 'date';
    if (/[A-Z.]+\(/.test(f)) return null;
    const m = raw.slice(1).match(XL.REFRE.source ? new RegExp(XL.REFRE.source.slice(1)) : /x/);
    if (!m) return null;
    let s = si; if (m[1]) { const n = m[1].replace(/^'|'$/g, ''); s = wb.sheets.findIndex(x => x.name.toLowerCase() === n.toLowerCase()); if (s < 0) return null; }
    const c = wb.sheets[s].cells[m[3].toUpperCase() + m[5]];
    return c && c.f === 'date' ? 'date' : null;
  }
  WB.forEach((s, si) => { for (const ref in s.cells) { const o = s.cells[ref]; const c = wb.sheets[si].cells[ref] = {}; if (o.f) c.f = o.f; if (o.h) c.h = 1; if (o.l) c.l = 1; if (o.y) c.y = 1; if (o.list) c.list = o.list; if (o.v !== undefined) { c.raw = typeof o.v === 'number' ? String(o.v) : o.v; c.v = o.v; } else c.raw = ''; } });
  WB.forEach((s, si) => { for (const ref in s.cells) { const o = s.cells[ref]; if (typeof o.v === 'string' && o.v[0] === '=') setRaw(si, ref, o.v, true); } });
  const ORIGINAL = JSON.stringify(serialize());
  function serialize() { return { v: 3, sh: wb.sheets.map(s => { const o = {}; for (const k in s.cells) { const c = s.cells[k]; if ((c.raw !== '' && c.raw !== undefined) || (c.f && c.f !== 'gen') || c.b) o[k] = [c.raw === undefined ? '' : c.raw, c.f || '', typeof c.v === 'number' && c.ast === undefined ? 1 : 0]; if (c.b) o[k].push(1); } const e = { n: s.name, s: s.src, c: o }; if (s.af) e.af = JSON.parse(JSON.stringify(s.af)); if (s.fz) e.fz = { r: s.fz.r, c: s.fz.c }; return e; }) }; }
  function restore(data) {
    const list = Array.isArray(data) ? data.map((c, i) => ({ n: TPL[i].name, s: i, c })) : data.sh;
    wb.sheets.length = 0;
    for (const e of list) { const t = TPL[e.s] || TPL[0]; const sh = { name: e.n, src: e.s, w: t.w, nrows: t.nrows, ncols: t.ncols, cells: {}, hid: new Set(), af: e.af ? JSON.parse(JSON.stringify(e.af)) : null, fz: e.fz ? { r: e.fz.r, c: e.fz.c } : null }; wb.sheets.push(sh); const si = wb.sheets.length - 1; const dec = DECOR[e.s] || {};
      for (const k in e.c) { const [raw, f, isNum, bd] = e.c[k]; const c = sh.cells[k] = {}; if (f) c.f = f; if (bd) c.b = 1; if (dec[k] && dec[k].h) c.h = 1; if (isNum && /^-?\d+(\.\d+)?(e-?\d+)?$/i.test(String(raw))) { c.raw = raw; c.v = +raw; } else setRaw(si, k, raw, true); }
      for (const k in dec) { const c = sh.cells[k] || (sh.cells[k] = { raw: '' }); Object.assign(c, dec[k]); } }
    if (typeof refilter === 'function') { EV.reset(); wb.sheets.forEach((_, i) => refilter(i)); }
  }
  let EV = makeEvaluator(wb);
  const val = (si, r, c) => EV.cellValue(si, r, c);
  const cellObj = (si, r, c) => wb.sheets[si].cells[numToCol(c) + (r + 1)];

  // ---------- état d'interface ----------
  const idx = x => typeof x === 'string' ? wb.sheets.findIndex(s => s.name === x) : x;
  const grpList = () => S.grp && S.grp.size > 1 ? [...S.grp].filter(i => i < wb.sheets.length) : [S.si];
  const S = { grp: null, p3: null, showF: false, marks: null, tg: null, si: 0, ar: 1, ac: 3, r1: 1, c1: 3, r2: 1, c2: 3, edit: null, clip: null, undo: [] };
  const $ = id => document.getElementById(id);
  const grid = $('grid'), fx = $('fx'), nameBox = $('namebox'), cellEd = $('celled');
  function pushUndo() { S.undo.push(JSON.stringify(serialize())); if (S.undo.length > 60) S.undo.shift(); }
  function changed() { EV.reset(); render(); save(); window.onWorkbookChange && window.onWorkbookChange(); }

  // ---------- rendu ----------
  function render() {
    const sh = wb.sheets[S.si]; NCOLS = sh.ncols;
    const rmin = Math.min(S.r1, S.r2), rmax = Math.max(S.r1, S.r2), cmin = Math.min(S.c1, S.c2), cmax = Math.max(S.c1, S.c2);
    let h = '<colgroup><col style="width:42px">';
    for (let c = 0; c < NCOLS; c++) h += `<col style="width:${sh.w[numToCol(c)] || 80}px">`;
    h += '</colgroup><thead><tr><th class="corner"></th>';
    for (let c = 0; c < NCOLS; c++) h += `<th class="ch${c >= cmin && c <= cmax ? ' hs' : ''}" data-col="${c}">${numToCol(c)}</th>`;
    h += '</tr></thead><tbody>';
    const af = sh.af, fl = af && Object.keys(af.crit).length, fz = sh.fz || { r: 0, c: 0 };
    for (let r = 0; r < sh.nrows; r++) {
      if (sh.hid.has(r)) continue;
      const fr = r < fz.r ? ' fr' : '';
      h += `<tr${r === fz.r - 1 ? ' class="frl"' : ''}><th class="rh${r >= rmin && r <= rmax ? ' hs' : ''}${fl && r > af.r && r <= af.r2 ? ' fl' : ''}${fr}" data-row="${r}">${r + 1}</th>`;
      for (let c = 0; c < NCOLS; c++) {
        const o = cellObj(S.si, r, c); let txt = '', cls = '', tip = '';
        if (o && o.raw !== '' && o.raw !== undefined) {
          const v = o.f === 'text' ? o.raw : val(S.si, r, c);
          txt = S.showF && o.ast !== undefined ? o.raw : display(v, o.f);
          cls = XL.isErr(v) ? 'er' : (typeof v === 'number' && o.f !== 'text') ? 'nu' : typeof v === 'boolean' ? 'bo' : '';
          if (typeof v === 'string' && !(S.showF && o.ast !== undefined)) { const nx = cellObj(S.si, r, c + 1); if (!nx || nx.raw === '' || nx.raw === undefined) cls += ' ov'; }
        }
        if (o && o.h) cls += ' hd'; if (o && o.b) cls += ' b'; if (o && o.y) cls += ' pa'; if (S.showF && o && o.ast !== undefined) cls = cls.replace(' nu', '') + ' fx'; if (o && o.l) cls += ' lb'; if (S.tg && S.tg.name === sh.name && S.tg.cells.has(numToCol(c) + (r + 1))) cls += ' tg';
        if (S.marks && S.marks.name === sh.name) { const mk = S.marks.map[numToCol(c) + (r + 1)]; if (mk && mk.sig === (o ? (o.raw || '') + '|' + (o.f || '') + '|' + txt : '')) { cls += ' mk-' + mk.k; if (mk.why) tip = mk.why; } }
        const inSel = r >= rmin && r <= rmax && c >= cmin && c <= cmax;
        if (inSel) cls += ' sel'; if (r === S.ar && c === S.ac) cls += ' act'; cls += fr; if (c < fz.c) cls += ' fc' + (c === fz.c - 1 ? ' fcl' : '');
        let afb = ''; if (af && r === af.r && c >= af.c1 && c <= af.c2) { const on = af.crit[c], so = af.sort && af.sort.c === c ? (af.sort.desc ? '↓' : '↑') : ''; cls += ' afh'; afb = `<span class="afb${on ? ' on' : ''}" data-afc="${c}" title="${on ? 'Filtre appliqué' : 'Filtrer / trier'}">${on ? '⏷' : so || '▾'}</span>`; }
        h += `<td class="${cls}" data-r="${r}" data-c="${c}"${tip ? ` title="${esc(tip)}"` : ''}>${esc(txt)}${afb}</td>`;
      }
      h += '</tr>';
    }
    grid.innerHTML = h + '</tbody>';
    if (fz.r || fz.c) { grid.querySelectorAll('.fr').forEach(e => { e.style.top = e.parentElement.offsetTop + 'px'; }); grid.querySelectorAll('td.fc').forEach(e => { e.style.left = e.offsetLeft + 'px'; }); }
    let tw = 42; for (let c = 0; c < NCOLS; c++) tw += sh.w[numToCol(c)] || 80; grid.style.width = tw + 'px';
    // poignée de recopie
    const last = grid.querySelector(`td[data-r="${rmax}"][data-c="${cmax}"]`);
    const hd = $('handle'); if (last && !S.edit) { hd.style.display = 'block'; hd.style.left = (last.offsetLeft + last.offsetWidth - 4) + 'px'; hd.style.top = (last.offsetTop + last.offsetHeight - 4) + 'px'; } else hd.style.display = 'none';
    const dd = $('dd'), ao = cellObj(S.si, S.ar, S.ac), atd = grid.querySelector(`td[data-r="${S.ar}"][data-c="${S.ac}"]`);
    if (ao && ao.list && atd && !S.edit) { dd.style.display = 'block'; dd.style.left = (atd.offsetLeft + atd.offsetWidth + 1) + 'px'; dd.style.top = atd.offsetTop + 'px'; dd.style.height = atd.offsetHeight + 'px'; } else dd.style.display = 'none';
    // onglets
    const g = S.p3 ? (() => { const a = idx(S.p3[0]), b = idx(S.p3[1]); return new Set(Array.from({ length: Math.abs(a - b) + 1 }, (_, k) => Math.min(a, b) + k)); })() : (S.grp && S.grp.size > 1 ? S.grp : null);
    const th = wb.sheets.map((s, i) => `<button class="tab${i === S.si ? ' on' : ''}${g && g.has(i) && i !== S.si ? ' gp' : ''}" data-si="${i}">${esc(s.name)}</button>`).join(''); if (th !== render.tabs) { $('tabs').innerHTML = th; render.tabs = th; }
    const tt = document.querySelector('.tb span'); if (tt) { if (!tt.dataset.f) tt.dataset.f = tt.textContent; tt.textContent = tt.dataset.f + (S.grp && S.grp.size > 1 ? '  [Groupe]' : ''); }
    nameBox.value = (S.edit && S.edit.si !== S.si ? '' : '') + numToCol(S.ac) + (S.ar + 1);
    if (!S.edit) { const o = cellObj(S.si, S.ar, S.ac); fx.value = o && o.raw !== undefined ? rawForBar(o) : ''; }
    $('fmt').value = (cellObj(S.si, S.ar, S.ac) || {}).f || 'gen';
    status(); placeEditor();
    if (S.scroll) { S.scroll = false; const a = grid.querySelector(`td[data-r="${S.ar}"][data-c="${S.ac}"]`); if (a) a.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }
  }
  function rawForBar(o) { if (o.ast === undefined && typeof o.v === 'number' && (o.f === 'date' || o.f === 'dlong')) return display(o.v, 'date'); if (typeof o.v === 'number' && o.ast === undefined) return String(o.v).replace('.', ','); return o.raw; }
  const esc = s => String(s).replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]));
  function status() {
    const rmin = Math.min(S.r1, S.r2), rmax = Math.max(S.r1, S.r2), cmin = Math.min(S.c1, S.c2), cmax = Math.max(S.c1, S.c2);
    const el = $('stat'), sh0 = wb.sheets[S.si], af = sh0.af; let pre = '';
    if (af && Object.keys(af.crit).length) { let vis = 0; for (let r = af.r + 1; r <= af.r2; r++) if (!sh0.hid.has(r)) vis++; pre = `<span class="afs">${vis} enregistrement${vis > 1 ? 's' : ''} trouvé${vis > 1 ? 's' : ''} sur ${af.r2 - af.r}</span>`; }
    if (rmin === rmax && cmin === cmax) { el.innerHTML = pre; return; }
    let n = 0, cnt = 0, sum = 0, f = null;
    for (let r = rmin; r <= rmax; r++) if (!sh0.hid.has(r)) for (let c = cmin; c <= cmax; c++) { const o = cellObj(S.si, r, c); if (!o || o.raw === '' || o.raw === undefined) continue; cnt++; const v = val(S.si, r, c); if (typeof v === 'number') { n++; sum += v; if (f === null) f = o.f; } }
    if (!cnt) { el.innerHTML = pre; return; }
    const ff = f === 'text' ? 'gen' : f;
    el.innerHTML = pre + (n ? `Moyenne : <b>${display(sum / n, ff)}</b>` : '') + `<span>Nombre : <b>${cnt}</b></span>` + (n ? `<span>Somme : <b>${display(sum, ff)}</b></span>` : '');
  }

  // ---------- édition ----------
  function startEdit(text, mode) {
    S.edit = { si: S.si, r: S.ar, c: S.ac, mode, point: null };
    fx.value = text; render(); const inp = S.si === S.edit.si ? cellEd : fx; inp.value = text; inp.focus(); inp.setSelectionRange(text.length, text.length);
  }
  function placeEditor() {
    if (!S.edit || S.edit.si !== S.si) { cellEd.style.display = 'none'; return; }
    const td = grid.querySelector(`td[data-r="${S.edit.r}"][data-c="${S.edit.c}"]`); if (!td) return;
    cellEd.style.display = 'block'; cellEd.style.left = td.offsetLeft + 'px'; cellEd.style.top = td.offsetTop + 'px'; cellEd.style.minWidth = td.offsetWidth + 'px'; cellEd.style.height = td.offsetHeight + 'px';
    if (cellEd.value !== fx.value) cellEd.value = fx.value;
  }
  function editText() { return fx.value; }
  function setEditText(t, caret) { fx.value = t; cellEd.value = t; const inp = document.activeElement === fx ? fx : cellEd; if (caret !== undefined) inp.setSelectionRange(caret, caret); }
  function commit(dr, dc) {
    if (!S.edit) return; const e = S.edit; let t = editText();
    if (t[0] === '=') { const open = (t.match(/\(/g) || []).length - (t.match(/\)/g) || []).length; if (open > 0) t += ')'.repeat(open); }
    const tc = cellObj(e.si, e.r, e.c);
    if (t[0] === '=' && t.length > 1 && !(tc && tc.f === 'text')) { try { const pb = XL.arityProblem(parse(t.slice(1))); if (pb) { flash(pb.few ? `Vous avez entré trop peu d'arguments pour la fonction ${pb.fn}. Les arguments se séparent par un point-virgule (;) ; les deux-points (:) désignent une plage.` : `Vous avez entré trop d'arguments pour la fonction ${pb.fn}.`, 8000); const inp0 = S.edit.si === S.si ? cellEd : fx; inp0.focus(); return; } } catch (err) {
      flash(err === 'comma' ? "Il y a un problème avec cette formule : en français, les arguments se séparent par un point-virgule (;), pas par une virgule." : "Il y a un problème avec cette formule. Vérifiez les guillemets (tout le critère entre guillemets, par exemple \">=15\"), les parenthèses et les points-virgules.", 7000);
      const inp = S.edit.si === S.si ? cellEd : fx; inp.focus(); return; } }
    pushUndo(); const tgt = e.si === S.si || S.p3 ? (S.grp && S.grp.size > 1 && S.grp.has(e.si) ? grpList() : [e.si]) : [e.si]; for (const gi of tgt) { setRaw(gi, numToCol(e.c) + (e.r + 1), t); }
    S.edit = null; S.p3 = null; S.si = e.si; S.ar = Math.max(0, Math.min(wb.sheets[S.si].nrows - 1, e.r + dr)); S.ac = Math.max(0, Math.min(NCOLS - 1, e.c + dc));
    S.r1 = S.r2 = S.ar; S.c1 = S.c2 = S.ac; cellEd.style.display = 'none'; grid.parentElement.focus(); changed(); lastCommit = { si: e.si, r: e.r, c: e.c, t };
  }
  let lastCommit = null;
  function cancel() { if (!S.edit) return; S.si = S.edit.si; S.edit = null; S.p3 = null; cellEd.style.display = 'none'; grid.parentElement.focus(); render(); }
  function pointable() { const t = editText(); if (t[0] !== '=') return false; const inp = document.activeElement === fx ? fx : cellEd; const pos = inp.selectionStart ?? t.length;
    if (S.edit.point && pos === S.edit.point.end) return true; return /[=+\-*/(;:<>&^]\s*$/.test(t.slice(0, pos)); }
  function refText(r1, c1, r2, c2) {
    let s = numToCol(c1) + (r1 + 1); if (r2 !== r1 || c2 !== c1) s += ':' + numToCol(c2) + (r2 + 1);
    const q = n => /^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(n) ? n : "'" + n.replace(/'/g, "''") + "'";
    if (S.p3) { const a = Math.min(idx(S.p3[0]), idx(S.p3[1])), b = Math.max(idx(S.p3[0]), idx(S.p3[1])); const n1 = wb.sheets[a].name, n2 = wb.sheets[b].name; s = (/^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(n1) && /^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(n2) ? n1 + ':' + n2 : "'" + n1 + ':' + n2 + "'") + '!' + s; }
    else if (S.si !== S.edit.si) s = q(wb.sheets[S.si].name) + '!' + s;
    return s;
  }
  function insertPoint(r1, c1, r2, c2) {
    const t = editText(); const inp = document.activeElement === fx ? fx : cellEd; let pos = inp.selectionStart ?? t.length;
    let start = pos; if (S.edit.point && S.edit.point.end === pos) start = S.edit.point.start;
    const ins = refText(Math.min(r1, r2), Math.min(c1, c2), Math.max(r1, r2), Math.max(c1, c2));
    const nt = t.slice(0, start) + ins + t.slice(pos); S.edit.point = { start, end: start + ins.length, r1, c1, r2, c2 };
    fx.value = nt; cellEd.value = nt; S.r1 = r1; S.c1 = c1; S.r2 = r2; S.c2 = c2; S.ar = r1; S.ac = c1; render();
    const target = S.si === S.edit.si ? cellEd : fx; target.focus(); target.setSelectionRange(start + ins.length, start + ins.length);
  }
  function toggleAbs() {
    const inp = document.activeElement === fx ? fx : cellEd; const t = inp.value, pos = inp.selectionStart;
    const re = /(\$?)([A-Za-z]{1,3})(\$?)(\d+)/g; let m, hit = null;
    while ((m = re.exec(t))) { if (m.index <= pos && re.lastIndex >= pos - 0 && !/[\wÀ-ÿ.]/.test(t[m.index - 1] || '')) hit = m; if (m.index > pos) break; }
    if (!hit) return;
    const st = [hit[1], hit[3]]; const order = [['', ''], ['$', '$'], ['', '$'], ['$', '']]; let k = order.findIndex(o => o[0] === st[0] && o[1] === st[1]); k = (k + 1) % 4;
    const rep = order[k][0] + hit[2].toUpperCase() + order[k][1] + hit[4]; const nt = t.slice(0, hit.index) + rep + t.slice(hit.index + hit[0].length);
    setEditText(nt, hit.index + rep.length); if (S.edit.point) S.edit.point = null;
  }
  const todayText = () => display(todaySerial(), 'date');

  // ---------- souris ----------
  let drag = null;
  grid.addEventListener('mousedown', ev => {
    if (ev.button === 2) { const t = ev.target.closest('td'); if (t) { const r = +t.dataset.r, c = +t.dataset.c; if (r >= Math.min(S.r1, S.r2) && r <= Math.max(S.r1, S.r2) && c >= Math.min(S.c1, S.c2) && c <= Math.max(S.c1, S.c2)) { ev.preventDefault(); return; } } if (S.edit) commit(0, 0); }
    const afbt = ev.target.closest('.afb'); if (afbt && ev.button === 0) { ev.preventDefault(); ev.stopPropagation(); if (S.edit) commit(0, 0); openAF(+afbt.dataset.afc, afbt); return; }
    const td = ev.target.closest('td'), ch = ev.target.closest('th.ch'), rh = ev.target.closest('th.rh');
    if (ch) { if (S.edit && !pointable()) commit(0, 0); const c = +ch.dataset.col; if (S.edit) { insertPoint(0, c, wb.sheets[S.si].nrows - 1, c); } else { S.c1 = S.c2 = S.ac = c; S.r1 = 0; S.ar = 0; S.r2 = wb.sheets[S.si].nrows - 1; render(); } ev.preventDefault(); return; }
    if (rh) { if (S.edit) commit(0, 0); const r = +rh.dataset.row; S.r1 = S.r2 = S.ar = r; S.c1 = 0; S.ac = 0; S.c2 = NCOLS - 1; render(); ev.preventDefault(); return; }
    if (!td) return; const r = +td.dataset.r, c = +td.dataset.c;
    if (S.edit) {
      if (S.edit.si === S.si && S.edit.r === r && S.edit.c === c) return;
      if (pointable()) { ev.preventDefault(); insertPoint(r, c, r, c); drag = { point: true, r, c }; return; }
      commit(0, 0);
    }
    ev.preventDefault();
    if (ev.shiftKey) { S.r2 = r; S.c2 = c; } else { S.ar = S.r1 = S.r2 = r; S.ac = S.c1 = S.c2 = c; }
    drag = { r, c }; grid.parentElement.focus(); render();
  });
  grid.addEventListener('mouseover', ev => {
    if (!drag || !(ev.buttons & 1)) return; const td = ev.target.closest('td'); if (!td) return; const r = +td.dataset.r, c = +td.dataset.c;
    if (drag.fill) { drag.tr = r; drag.tc = c; showFillPreview(); return; }
    if (drag.point) { insertPoint(drag.r, drag.c, r, c); return; }
    S.r2 = r; S.c2 = c; render();
  });
  document.addEventListener('mouseup', () => { if (drag && drag.fill) doFill(drag.tr, drag.tc); drag = null; $('fillprev').style.display = 'none'; });
  grid.addEventListener('dblclick', ev => { const td = ev.target.closest('td'); if (!td) return; const o = cellObj(S.si, S.ar, S.ac); startEdit(o && o.raw !== undefined ? rawForBar(o) : '', 'edit'); });
  const handle = $('handle');
  handle.addEventListener('mousedown', ev => { ev.preventDefault(); ev.stopPropagation(); drag = { fill: true, tr: Math.max(S.r1, S.r2), tc: Math.max(S.c1, S.c2) }; });
  handle.addEventListener('dblclick', ev => { ev.preventDefault(); fillDownAuto(); });
  function showFillPreview() {
    const rmin = Math.min(S.r1, S.r2), cmin = Math.min(S.c1, S.c2), rmax = Math.max(S.r1, S.r2, drag.tr), cmax = Math.max(S.c1, S.c2, drag.tc);
    const down = drag.tr - Math.max(S.r1, S.r2) >= drag.tc - Math.max(S.c1, S.c2);
    const a = grid.querySelector(`td[data-r="${rmin}"][data-c="${cmin}"]`), b = grid.querySelector(`td[data-r="${down ? rmax : Math.max(S.r1, S.r2)}"][data-c="${down ? Math.max(S.c1, S.c2) : cmax}"]`); if (!a || !b) return;
    const p = $('fillprev'); p.style.display = 'block'; p.style.left = a.offsetLeft + 'px'; p.style.top = a.offsetTop + 'px'; p.style.width = (b.offsetLeft + b.offsetWidth - a.offsetLeft) + 'px'; p.style.height = (b.offsetTop + b.offsetHeight - a.offsetTop) + 'px';
  }
  function copyCell(si, from, toR, toC) {
    const [fr, fc] = from; const src = cellObj(si, fr, fc), ref = numToCol(toC) + (toR + 1);
    const sh = wb.sheets[si]; const hdr = sh.cells[ref] && sh.cells[ref].h;
    if (!src || src.raw === '' || src.raw === undefined) { sh.cells[ref] = { raw: '', f: src && src.f }; if (hdr) sh.cells[ref].h = 1; return; }
    const raw = src.ast !== undefined ? shiftFormula(src.raw, toR - fr, toC - fc) : src.raw;
    sh.cells[ref] = { f: src.f }; if (hdr) sh.cells[ref].h = 1;
    if (src.ast === undefined && typeof src.v === 'number') { sh.cells[ref].raw = src.raw; sh.cells[ref].v = src.v; } else setRaw(si, ref, raw, true);
  }
  function doFill(tr, tc) {
    const rmin = Math.min(S.r1, S.r2), rmax = Math.max(S.r1, S.r2), cmin = Math.min(S.c1, S.c2), cmax = Math.max(S.c1, S.c2);
    const down = tr - rmax >= tc - cmax; if (down && tr <= rmax) return; if (!down && tc <= cmax) return;
    pushUndo();
    if (down) { for (let r = rmax + 1; r <= tr; r++) for (let c = cmin; c <= cmax; c++) copyCell(S.si, [rmin + (r - rmin) % (rmax - rmin + 1), c], r, c); S.r2 = tr; S.r1 = rmin; }
    else { for (let c = cmax + 1; c <= tc; c++) for (let r = rmin; r <= rmax; r++) copyCell(S.si, [r, cmin + (c - cmin) % (cmax - cmin + 1)], r, c); S.c2 = tc; S.c1 = cmin; }
    changed();
  }
  function fillDownAuto() {
    const rmax = Math.max(S.r1, S.r2), cmin = Math.min(S.c1, S.c2), cmax = Math.max(S.c1, S.c2);
    const has = (r, c) => { const o = c >= 0 && c < NCOLS ? cellObj(S.si, r, c) : null; return o && o.raw !== '' && o.raw !== undefined; };
    let col = -1; for (let k = cmin - 1; k >= 0; k--) if (has(rmax + 1, k)) { col = k; break; } if (col < 0 && has(rmax + 1, cmax + 1)) col = cmax + 1; if (col < 0) return; let end = rmax;
    while (end + 1 < wb.sheets[S.si].nrows && has(end + 1, col)) end++;
    if (end > rmax) doFill(end, cmax);
  }

  // ---------- clavier ----------
  const box = grid.parentElement;
  box.addEventListener('keydown', ev => {
    if (S.edit) return;
    const k = ev.key, ctrl = ev.ctrlKey || ev.metaKey, nr = wb.sheets[S.si].nrows;
    const hid = wb.sheets[S.si].hid, step = (r, d) => { let x = r + d; while (d && x > 0 && x < nr - 1 && hid.has(x)) x += d; return hid.has(x) ? r : x; };
    const move = (dr, dc) => { if (ev.shiftKey) { S.r2 = Math.max(0, Math.min(nr - 1, step(S.r2, dr))); S.c2 = Math.max(0, Math.min(NCOLS - 1, S.c2 + dc)); } else { S.ar = Math.max(0, Math.min(nr - 1, step(S.ar, dr))); S.ac = Math.max(0, Math.min(NCOLS - 1, S.ac + dc)); S.r1 = S.r2 = S.ar; S.c1 = S.c2 = S.ac; } S.scroll = true; render(); ev.preventDefault(); };
    if (k === 'ArrowDown' || k === 'Enter') return move(1, 0); if (k === 'ArrowUp') return move(-1, 0);
    if (k === 'ArrowRight' || k === 'Tab') return move(0, 1); if (k === 'ArrowLeft') return move(0, -1);
    if (k === 'F2') { const o = cellObj(S.si, S.ar, S.ac); startEdit(o && o.raw !== undefined ? rawForBar(o) : '', 'edit'); ev.preventDefault(); return; }
    if (k === 'Delete' || k === 'Backspace') { pushUndo(); for (const gi of grpList()) for (let r = Math.min(S.r1, S.r2); r <= Math.max(S.r1, S.r2); r++) for (let c = Math.min(S.c1, S.c2); c <= Math.max(S.c1, S.c2); c++) { const o = cellObj(gi, r, c); if (o && !o.h) { o.raw = ''; delete o.ast; delete o.v; } } changed(); if (k === 'Backspace') startEdit('', 'enter'); ev.preventDefault(); return; }
    if (ctrl && ev.shiftKey && (k === 'L' || k === 'l') && $('afon')) { toggleFilter(); ev.preventDefault(); return; }
    if (ctrl && (k === '`' || ev.code === 'Backquote')) { XLAPP.toggleFormulas(); ev.preventDefault(); return; }
    if (ctrl && (k === 'z' || k === 'Z')) { undo(); ev.preventDefault(); return; }
    if (ctrl && /^[hHfF]$/.test(k) && $('findbtn')) { openFind(); ev.preventDefault(); return; }
    if (ctrl && /^[gGbB]$/.test(k) && $('bold')) { toggleBold(); ev.preventDefault(); return; }
    if (ctrl && (k === 'c' || k === 'C')) { S.clip = { si: S.si, r1: Math.min(S.r1, S.r2), r2: Math.max(S.r1, S.r2), c1: Math.min(S.c1, S.c2), c2: Math.max(S.c1, S.c2) }; flash('Copié : sélectionnez la destination puis Ctrl+V'); ev.preventDefault(); return; }
    if (ctrl && ev.altKey && (k === 'v' || k === 'V')) { openPS(); ev.preventDefault(); return; }
    if (ctrl && (k === 'v' || k === 'V')) { paste(); ev.preventDefault(); return; }
    if (ctrl && k === ';') { startEdit(todayText(), 'enter'); ev.preventDefault(); return; }
    if (ctrl && (k === 'd' || k === 'D')) { const rmin = Math.min(S.r1, S.r2), rmax = Math.max(S.r1, S.r2); if (rmax > rmin) { const keep = [S.r1, S.r2]; S.r1 = S.r2 = rmin; doFill(rmax, Math.max(S.c1, S.c2)); } ev.preventDefault(); return; }
    if (k.length === 1 && !ctrl && !ev.altKey) { startEdit(k, 'enter'); ev.preventDefault(); }
  });
  function onEditKey(ev) {
    if (!S.edit) return; const k = ev.key; ev.stopPropagation();
    if (k === 'Enter') { ev.preventDefault(); commit(ev.shiftKey ? -1 : 1, 0); return; }
    if (k === 'Tab') { ev.preventDefault(); commit(0, ev.shiftKey ? -1 : 1); return; }
    if (k === 'Escape') { ev.preventDefault(); cancel(); return; }
    if (k === 'F4') { ev.preventDefault(); toggleAbs(); return; }
    if ((ev.ctrlKey || ev.metaKey) && k === ';') { ev.preventDefault(); const inp = ev.target; const p = inp.selectionStart; setEditText(inp.value.slice(0, p) + todayText() + inp.value.slice(p), p + 10); return; }
    if (k.startsWith('Arrow') && (S.edit.mode === 'enter' || S.edit.point)) {
      if (pointable()) { ev.preventDefault(); const p = S.edit.point; let r = p ? (ev.shiftKey ? p.r2 : p.r1) : S.edit.r, c = p ? (ev.shiftKey ? p.c2 : p.c1) : S.edit.c;
        const d = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[k]; r = Math.max(0, r + d[0]); c = Math.max(0, Math.min(NCOLS - 1, c + d[1]));
        if (ev.shiftKey && p) insertPoint(p.r1, p.c1, r, c); else insertPoint(r, c, r, c); return; }
      if (S.edit.mode === 'enter') { ev.preventDefault(); const d = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] }[k]; commit(d[0], d[1]); }
    }
  }
  function onEditInput(ev) { const t = ev.target.value; if (ev.target === fx) cellEd.value = t; else fx.value = t; if (S.edit) S.edit.point = null; }
  cellEd.addEventListener('keydown', onEditKey); fx.addEventListener('keydown', onEditKey);
  cellEd.addEventListener('input', onEditInput); fx.addEventListener('input', onEditInput);
  fx.addEventListener('focus', () => { if (!S.edit) { const o = cellObj(S.si, S.ar, S.ac); const t = o && o.raw !== undefined ? rawForBar(o) : ''; S.edit = { si: S.si, r: S.ar, c: S.ac, mode: 'edit', point: null }; fx.value = t; cellEd.value = t; placeEditor(); } });
  function paste() {
    if (!S.clip) return; const cl = S.clip; pushUndo(); const h = cl.r2 - cl.r1 + 1, w = cl.c2 - cl.c1 + 1;
    const rmin = Math.min(S.r1, S.r2), cmin = Math.min(S.c1, S.c2); const th = Math.max(h, Math.max(S.r1, S.r2) - rmin + 1), tw = Math.max(w, Math.max(S.c1, S.c2) - cmin + 1);
    for (let i = 0; i < th; i++) for (let j = 0; j < tw; j++) {
      const fr = cl.r1 + i % h, fc = cl.c1 + j % w, src = cellObj(cl.si, fr, fc), tr = rmin + i, tc = cmin + j, ref = numToCol(tc) + (tr + 1), sh = wb.sheets[S.si]; const hdr = sh.cells[ref] && sh.cells[ref].h;
      if (!src || src.raw === '' || src.raw === undefined) { sh.cells[ref] = { raw: '', f: src && src.f }; } else if (src.ast !== undefined) { sh.cells[ref] = { f: src.f }; setRaw(S.si, ref, shiftFormula(src.raw, tr - fr, tc - fc), true); } else { sh.cells[ref] = { raw: src.raw, v: src.v, f: src.f }; }
      if (hdr) sh.cells[ref].h = 1;
    }
    S.r2 = rmin + th - 1; S.c2 = cmin + tw - 1; changed();
  }
  function pasteValues() {
    if (!S.clip) return; const cl = S.clip; pushUndo(); const h = cl.r2 - cl.r1 + 1, w = cl.c2 - cl.c1 + 1, rmin = Math.min(S.r1, S.r2), cmin = Math.min(S.c1, S.c2);
    for (let i = 0; i < h; i++) for (let j = 0; j < w; j++) {
      const src = cellObj(cl.si, cl.r1 + i, cl.c1 + j), ref = numToCol(cmin + j) + (rmin + i + 1), sh = wb.sheets[S.si]; const hdr = sh.cells[ref] && sh.cells[ref].h; const old = sh.cells[ref] || {};
      if (!src || src.raw === '' || src.raw === undefined) sh.cells[ref] = { raw: '', f: old.f };
      else { const x = val(cl.si, cl.r1 + i, cl.c1 + j); sh.cells[ref] = { f: old.f && old.f !== 'gen' ? old.f : src.f, raw: x === null ? '' : (typeof x === 'object' ? x.err : String(x)), v: typeof x === 'object' && x ? x.err : x }; }
      if (hdr) sh.cells[ref].h = 1;
    }
    S.r2 = rmin + h - 1; S.c2 = cmin + w - 1; changed();
  }
  function clearSel() { pushUndo(); for (const gi of grpList()) for (let r = Math.min(S.r1, S.r2); r <= Math.max(S.r1, S.r2); r++) for (let c = Math.min(S.c1, S.c2); c <= Math.max(S.c1, S.c2); c++) { const o = cellObj(gi, r, c); if (o && !o.h) { o.raw = ''; delete o.ast; delete o.v; } } changed(); }
  function setFmt(f) { pushUndo(); for (const gi of grpList()) for (let r = Math.min(S.r1, S.r2); r <= Math.max(S.r1, S.r2); r++) for (let c = Math.min(S.c1, S.c2); c <= Math.max(S.c1, S.c2); c++) { const ref = numToCol(c) + (r + 1), sh = wb.sheets[gi]; const o = sh.cells[ref] || (sh.cells[ref] = { raw: '' }); if (!o.h) o.f = f; } changed(); }
  // ---------- liste déroulante ----------
  function openList() { const o = cellObj(S.si, S.ar, S.ac); if (!o || !o.list) return; const r = $('dd').getBoundingClientRect();
    menu.innerHTML = o.list.map((x, i) => `<button data-li="${i}">${esc(x)}</button>`).join(''); menu.style.display = 'block';
    menu.style.left = Math.min(r.right - menu.offsetWidth, innerWidth - menu.offsetWidth - 8) + 'px'; menu.style.top = Math.min(r.bottom + 2, innerHeight - menu.offsetHeight - 8) + 'px'; menu.dataset.list = '1'; }
  setTimeout(() => { $('dd').addEventListener('mousedown', ev => { ev.preventDefault(); ev.stopPropagation(); openList(); }); });
  box.addEventListener('keydown', ev => { if (ev.altKey && ev.key === 'ArrowDown') { ev.preventDefault(); openList(); } });
  // ---------- menu contextuel (clic droit) ----------
  const menu = $('ctx');
  const FMTS = [['gen', 'Standard'], ['num', 'Nombre'], ['eur0', 'Monétaire (0 déc.)'], ['eur2', 'Monétaire'], ['date', 'Date courte'], ['djour', 'Date avec jour'], ['dlong', 'Date longue'], ['pct', 'Pourcentage'], ['pct1', 'Pourcentage (0,0 %)'], ['text', 'Texte']];
  function openMenu(x, y) {
    const multi = Math.max(S.r1, S.r2) > Math.min(S.r1, S.r2);
    menu.innerHTML = `<button data-a="copy">Copier<span>Ctrl+C</span></button><button data-a="paste" ${S.clip ? '' : 'disabled'}>Coller<span>Ctrl+V</span></button>
      <button data-a="pastev" ${S.clip ? '' : 'disabled'}>Coller les valeurs</button><button data-a="pastesp" ${S.clip ? '' : 'disabled'}>Collage spécial…<span>Ctrl+Alt+V</span></button><hr>
      <button data-a="filldown" ${multi ? '' : 'disabled'}>Recopier vers le bas<span>Ctrl+D</span></button><button data-a="clear">Effacer le contenu<span>Suppr</span></button><hr>
      <div class="sub"><button class="subh">Format de cellule ▸</button><div class="subm">${FMTS.map(([k, l]) => `<button data-f="${k}">${l}</button>`).join('')}</div></div>`;
    menu.style.display = 'block'; const W = menu.offsetWidth, H = menu.offsetHeight;
    menu.style.left = Math.min(x, innerWidth - W - 8) + 'px'; menu.style.top = Math.min(y, innerHeight - H - 8) + 'px';
  }
  const closeMenu = () => { menu.style.display = 'none'; };
  grid.addEventListener('contextmenu', ev => { ev.preventDefault(); const t = ev.target.closest('td, th.ch'); if (!t) return; openMenu(ev.clientX, ev.clientY); });
  menu.addEventListener('mousedown', ev => ev.preventDefault());
  menu.addEventListener('click', ev => { const b = ev.target.closest('button'); if (!b || b.disabled || b.classList.contains('subh')) return; closeMenu();
    if (b.dataset.t) { tabAction(b.dataset.t, +b.dataset.si); if (b.dataset.t !== 'rename') box.focus(); return; }
    if (b.dataset.li !== undefined) { const o = cellObj(S.si, S.ar, S.ac); pushUndo(); setRaw(S.si, numToCol(S.ac) + (S.ar + 1), o.list[+b.dataset.li]); changed(); box.focus(); return; }
    const a = b.dataset.a, f = b.dataset.f;
    if (f) setFmt(f); else if (a === 'copy') { S.clip = { si: S.si, r1: Math.min(S.r1, S.r2), r2: Math.max(S.r1, S.r2), c1: Math.min(S.c1, S.c2), c2: Math.max(S.c1, S.c2) }; flash('Copié : clic droit sur la destination, puis Coller'); }
    else if (a === 'paste') paste(); else if (a === 'pastev') pasteValues(); else if (a === 'pastesp') openPS(); else if (a === 'clear') clearSel();
    else if (a === 'filldown') { const rmin = Math.min(S.r1, S.r2), rmax = Math.max(S.r1, S.r2); S.r1 = S.r2 = rmin; doFill(rmax, Math.max(S.c1, S.c2)); }
    box.focus(); });
  document.addEventListener('mousedown', ev => { if (!ev.target.closest('#ctx') && !ev.target.closest('#dd')) closeMenu(); });
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') closeMenu(); });
  function undo() { const s = S.undo.pop(); if (!s) return; restore(JSON.parse(s)); changed(); }
  let flashT; function flash(m, ms) { const f = $('flash'); f.textContent = m; f.style.display = 'block'; clearTimeout(flashT); flashT = setTimeout(() => f.style.display = 'none', ms || 2600); }

  // ---------- ruban ----------
  $('fmt').addEventListener('change', ev => { if (S.edit) commit(0, 0); pushUndo(); const f = ev.target.value;
    for (const gi of grpList()) for (let r = Math.min(S.r1, S.r2); r <= Math.max(S.r1, S.r2); r++) for (let c = Math.min(S.c1, S.c2); c <= Math.max(S.c1, S.c2); c++) { const ref = numToCol(c) + (r + 1), sh = wb.sheets[gi]; const o = sh.cells[ref] || (sh.cells[ref] = { raw: '' }); if (o.h) continue; o.f = f; }
    changed(); box.focus(); });
  if ($('showf')) $('showf').addEventListener('click', () => { if (S.edit) commit(0, 0); XLAPP.toggleFormulas(); box.focus(); });
  $('undo').addEventListener('click', () => { if (S.edit) cancel(); undo(); });
  // ---------- onglets : groupe, 3D, renommer, dupliquer, déplacer ----------
  const tabsEl = $('tabs'); let tdrag = null;
  tabsEl.addEventListener('mousedown', ev => { const b = ev.target.closest('.tab'); if (!b || ev.button !== 0 || b.querySelector('input')) return; ev.preventDefault(); closeMenu();
    const si = +b.dataset.si;
    if (S.edit) { if (pointable()) { if (ev.shiftKey) { S.p3 = [wb.sheets[S.si].name, wb.sheets[si].name]; render(); fx.focus(); return; } S.p3 = null; S.si = si; render(); (S.si === S.edit.si ? cellEd : fx).focus(); return; } commit(0, 0); }
    if (ev.ctrlKey || ev.metaKey) { S.grp = S.grp && S.grp.size > 1 ? S.grp : new Set([S.si]); if (S.grp.has(si) && si !== S.si) S.grp.delete(si); else S.grp.add(si); render(); box.focus(); return; }
    if (ev.shiftKey) { S.grp = new Set(); for (let k = Math.min(S.si, si); k <= Math.max(S.si, si); k++) S.grp.add(k); render(); box.focus(); return; }
    if (!(S.grp && S.grp.has(si))) S.grp = null;
    if (si !== S.si) { S.si = si; S.ar = S.r1 = S.r2 = 1; S.ac = S.c1 = S.c2 = 3; }
    tdrag = { from: si, x: ev.clientX, on: false }; render(); box.focus(); });
  document.addEventListener('mousemove', ev => { if (!tdrag) return; if (!tdrag.on && Math.abs(ev.clientX - tdrag.x) > 10) tdrag.on = true; if (!tdrag.on) return;
    const to = dropIndex(ev.clientX); tabsEl.querySelectorAll('.tab').forEach((t, i) => { t.style.boxShadow = i === to ? 'inset 3px 0 0 #217346' : (to === wb.sheets.length && i === wb.sheets.length - 1 ? 'inset -3px 0 0 #217346' : ''); }); });
  document.addEventListener('mouseup', ev => { if (!tdrag) return; const d = tdrag; tdrag = null; if (!d.on) return; const to = dropIndex(ev.clientX);
    if (ev.ctrlKey || ev.metaKey) copySheet(d.from, to); else moveSheet(d.from, to); });
  function dropIndex(x) { const ts = [...tabsEl.querySelectorAll('.tab')]; for (let i = 0; i < ts.length; i++) { const r = ts[i].getBoundingClientRect(); if (x < r.left + r.width / 2) return i; } return ts.length; }
  function sheetQ(n) { return /^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(n) ? n : "'" + n.replace(/'/g, "''") + "'"; }
  function moveSheet(from, to) { if (to === from || to === from + 1) { render(); return; } pushUndo(); const act = wb.sheets[S.si]; const [sh] = wb.sheets.splice(from, 1); wb.sheets.splice(to > from ? to - 1 : to, 0, sh); S.si = wb.sheets.indexOf(act); S.grp = null; changed(); flash(`Feuille « ${sh.name} » déplacée.`); }
  function uniqName(n) { let k = 2, base = n.replace(/ \(\d+\)$/, ''); while (wb.sheets.some(s => s.name.toLowerCase() === `${base} (${k})`.toLowerCase())) k++; return `${base} (${k})`; }
  function copySheet(from, to) { pushUndo(); const src = wb.sheets[from]; const cp = { name: uniqName(src.name), src: src.src, w: src.w, nrows: src.nrows, ncols: src.ncols, cells: JSON.parse(JSON.stringify(src.cells)), hid: new Set() };
    wb.sheets.splice(to, 0, cp); S.si = to; S.grp = null; S.ar = S.r1 = S.r2 = 0; S.ac = S.c1 = S.c2 = 0; changed(); flash(`Copie créée : « ${cp.name} ». Double-cliquez sur l'onglet pour la renommer.`, 4000); }
  function renameRefs(oldN, newN) {
    const o = oldN.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), nq = sheetQ(newN), nb = newN.replace(/'/g, "''");
    const res = [[new RegExp("'" + o.replace(/'/g, "''") + "'(?=!)", 'g'), nq], [new RegExp("'" + o + "(?=:[^'!]+'!)", 'g'), "'" + nb], [new RegExp("(:)" + o + "(?='!)", 'g'), '$1' + nb], [new RegExp("(^|[^\\wÀ-ÿ.'])" + o + "(?=[!:][^\\d])", 'g'), '$1' + (/^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(newN) ? newN : null)]];
    wb.sheets.forEach((sh, si) => { for (const k in sh.cells) { const c = sh.cells[k]; if (c.ast === undefined || typeof c.raw !== 'string') continue;
      const parts = c.raw.split(/("(?:[^"]|"")*")/); let ch = false;
      for (let i = 0; i < parts.length; i += 2) { let x = parts[i]; for (const [re, by] of res) { if (by === null) { x = x.replace(re, (m, p1) => p1 + nq); continue; } x = x.replace(re, by); } if (x !== parts[i]) { parts[i] = x; ch = true; } }
      if (ch) setRaw(si, k, parts.join(''), true); } });
  }
  function renameSheet(si) { render.tabs = ''; const b = tabsEl.querySelector(`.tab[data-si="${si}"]`); if (!b) return; const old = wb.sheets[si].name;
    b.innerHTML = `<input value="${esc(old).replace(/"/g, '&quot;')}" style="font:inherit;width:${Math.max(70, old.length * 9)}px;border:1px solid #217346;padding:1px 3px">`; const inp = b.querySelector('input'); inp.focus(); inp.select();
    let done = false; const fin = ok => { if (done) return; done = true; const n = inp.value.trim();
      if (ok && n && n !== old) { if (/[\[\]:*?\/\\]/.test(n) || n.length > 31) { flash('Nom de feuille impossible : 31 caractères au plus, sans [ ] : * ? / \\', 5000); render(); return; }
        if (wb.sheets.some((s, i) => i !== si && s.name.toLowerCase() === n.toLowerCase())) { flash('Ce nom est déjà pris : choisissez-en un autre.', 4000); render(); return; }
        pushUndo(); wb.sheets[si].name = n; renameRefs(old, n); changed(); } else render(); box.focus(); };
    inp.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') { e.preventDefault(); fin(true); } if (e.key === 'Escape') { e.preventDefault(); fin(false); } });
    inp.addEventListener('blur', () => fin(true)); inp.addEventListener('mousedown', e => e.stopPropagation()); }
  tabsEl.addEventListener('dblclick', ev => { const b = ev.target.closest('.tab'); if (!b || S.edit) return; renameSheet(+b.dataset.si); });
  tabsEl.addEventListener('contextmenu', ev => { const b = ev.target.closest('.tab'); if (!b) return; ev.preventDefault(); if (S.edit) commit(0, 0); const si = +b.dataset.si;
    const grouped = S.grp && S.grp.size > 1; if (!grouped && si !== S.si) { S.si = si; render(); }
    menu.innerHTML = `<button data-t="rename" data-si="${si}">Renommer</button><button data-t="dup" data-si="${si}">Dupliquer (copie juste à droite)</button><hr>
      <button data-t="left" data-si="${si}" ${si === 0 ? 'disabled' : ''}>Déplacer vers la gauche</button><button data-t="right" data-si="${si}" ${si === wb.sheets.length - 1 ? 'disabled' : ''}>Déplacer vers la droite</button><hr>
      <button data-t="all">Sélectionner toutes les feuilles</button><button data-t="ungroup" ${grouped ? '' : 'disabled'}>Dissocier les feuilles</button>`;
    menu.style.display = 'block'; menu.style.left = Math.min(ev.clientX, innerWidth - menu.offsetWidth - 8) + 'px'; menu.style.top = Math.max(8, ev.clientY - menu.offsetHeight) + 'px'; });
  function tabAction(t, si) {
    if (t === 'rename') renameSheet(si); else if (t === 'dup') copySheet(si, si + 1); else if (t === 'left') moveSheet(si, si - 1); else if (t === 'right') moveSheet(si, si + 2);
    else if (t === 'all') { S.grp = new Set(wb.sheets.map((_, i) => i)); render(); } else if (t === 'ungroup') { S.grp = null; render(); flash('Feuilles dissociées.'); } }
  nameBox.addEventListener('keydown', ev => { if (ev.key !== 'Enter') return; ev.preventDefault(); const m = nameBox.value.trim().toUpperCase().match(/^([A-Z]{1,3})(\d+)(?::([A-Z]{1,3})(\d+))?$/); if (!m) return;
    S.ar = S.r1 = +m[2] - 1; S.ac = S.c1 = colToNum(m[1]); S.r2 = m[3] ? +m[4] - 1 : S.r1; S.c2 = m[3] ? colToNum(m[3]) : S.c1; render(); box.focus(); });

  // ---------- sauvegarde ----------
  const KEY = (window.CFG && CFG.key ? CFG.key : 'xl17') + '-interactif-v2';
  function save() { const d = 'v2|' + JSON.stringify(serialize()); try { localStorage.setItem(KEY, d); } catch (e) {} window.onSave && window.onSave(d); }
  function load(d) { try { if (!d || !d.startsWith('v2|')) return; const data = JSON.parse(d.slice(3)); restore(data); EV.reset(); } catch (e) {} }
  // ---------- collage spécial ----------
  const PS = { dlg: $('psdlg') };
  function openPS() { if (!PS.dlg) return; if (S.edit) commit(0, 0); if (!S.clip) { flash('Copiez d\'abord des cellules (Ctrl+C).'); return; } $('pss').textContent = ''; PS.dlg.style.display = 'block'; PS.dlg.querySelector('input[name=psw]:checked').focus(); }
  function closePS() { if (PS.dlg) PS.dlg.style.display = 'none'; box.focus(); }
  function sheetRef(si) { const n = wb.sheets[si].name; return /^[A-Za-zÀ-ÿ_][\wÀ-ÿ.]*$/.test(n) ? n : "'" + n.replace(/'/g, "''") + "'"; }
  function pasteSpecial(o) {
    const cl = S.clip; if (!cl) return; const h = cl.r2 - cl.r1 + 1, w = cl.c2 - cl.c1 + 1;
    const rmin = Math.min(S.r1, S.r2), cmin = Math.min(S.c1, S.c2);
    const H = o.transpose ? w : h, W = o.transpose ? h : w;
    let th = H, tw = W; if (!o.transpose && !o.link) { th = Math.max(H, Math.max(S.r1, S.r2) - rmin + 1); tw = Math.max(W, Math.max(S.c1, S.c2) - cmin + 1); if (th % H) th = H; if (tw % W) tw = W; }
    if (cl.si === S.si && o.transpose && !(rmin + th - 1 < cl.r1 || rmin > cl.r2 || cmin + tw - 1 < cl.c1 || cmin > cl.c2)) { $('pss').textContent = 'Impossible de coller : la zone de collage chevauche la zone copiée. Choisissez une destination libre.'; return false; }
    pushUndo(); const sh = wb.sheets[S.si];
    for (let i = 0; i < th; i++) for (let j = 0; j < tw; j++) {
      const si_ = i % H, sj = j % W; const fr = cl.r1 + (o.transpose ? sj : si_), fc = cl.c1 + (o.transpose ? si_ : sj);
      const tr = rmin + i, tc = cmin + j, ref = numToCol(tc) + (tr + 1);
      const src = cellObj(cl.si, fr, fc); const blank = !src || src.raw === '' || src.raw === undefined;
      const old = sh.cells[ref] || { raw: '' }; const hdr = old.h, bd = old.b;
      if (o.link) { const r0 = numToCol(fc) + (fr + 1); const one = h === 1 && w === 1; const rr = one ? '$' + numToCol(fc) + '$' + (fr + 1) : r0; sh.cells[ref] = { f: old.f && old.f !== 'gen' ? old.f : (src && src.f) }; setRaw(S.si, ref, '=' + (cl.si !== S.si ? sheetRef(cl.si) + '!' : '') + rr, true); }
      else if (blank && o.skip) continue;
      else if (o.op && o.op !== 'none') {
        const sv = blank ? 0 : val(cl.si, fr, fc); const keepF = o.what === 'all' || o.what === 'formats' ? (src && src.f) : o.what === 'valnum' ? (src && src.f) : old.f;
        if (o.what === 'formats') { sh.cells[ref] = Object.assign({}, old, { f: src && src.f }); }
        else if (typeof sv !== 'number') { /* texte : pas d'opération */ }
        else { const sym = { add: '+', sub: '-', mul: '*', div: '/' }[o.op];
          if (old.ast !== undefined) { sh.cells[ref] = { f: keepF }; setRaw(S.si, ref, '=(' + String(old.raw).replace(/^=/, '') + ')' + sym + String(sv).replace('.', ','), true); }
          else { const tv = old.raw === '' || old.raw === undefined ? 0 : (typeof old.v === 'number' ? old.v : null);
            if (tv === null) { /* cible texte : inchangée */ } else { let x = o.op === 'add' ? tv + sv : o.op === 'sub' ? tv - sv : o.op === 'mul' ? tv * sv : (sv === 0 ? null : tv / sv); if (x !== null) x = Math.round(x * 1e10) / 1e10; sh.cells[ref] = { f: keepF, raw: x === null ? '#DIV/0!' : String(x), v: x === null ? { err: '#DIV/0!' } : x }; } } }
      }
      else if (o.what === 'formats') { sh.cells[ref] = Object.assign({}, old); if (src && src.f) sh.cells[ref].f = src.f; else delete sh.cells[ref].f; }
      else if (o.what === 'values' || o.what === 'valnum') { const f = o.what === 'valnum' ? (src && src.f) : old.f;
        if (blank) sh.cells[ref] = { raw: '', f }; else { const x = val(cl.si, fr, fc); sh.cells[ref] = { f, raw: x === null ? '' : (typeof x === 'object' ? x.err : String(x)), v: typeof x === 'object' && x ? x : x }; if (typeof x === 'object' && x) sh.cells[ref].raw = x.err; } }
      else { const f = o.what === 'formulas' ? old.f : (src && src.f);
        if (blank) sh.cells[ref] = { raw: '', f }; else if (src.ast !== undefined) { sh.cells[ref] = { f }; setRaw(S.si, ref, shiftFormula(src.raw, tr - fr, tc - fc), true); } else { sh.cells[ref] = { raw: src.raw, v: src.v, f }; } }
      if (hdr) sh.cells[ref].h = 1; if (bd) sh.cells[ref].b = 1;
    }
    S.r1 = rmin; S.c1 = cmin; S.r2 = rmin + th - 1; S.c2 = cmin + tw - 1; changed();
    window.onPasteSpecial && window.onPasteSpecial(Object.assign({ si: S.si, r: rmin, c: cmin }, o)); return true;
  }
  if (PS.dlg) { const get = n => PS.dlg.querySelector(`input[name=${n}]:checked`).value;
    const go = link => { const ok = pasteSpecial({ what: get('psw'), op: get('pso'), skip: $('psb').checked, transpose: $('pst').checked, link }); if (ok !== false) { closePS(); flash(link ? 'Collé avec liaison.' : 'Collage spécial effectué.'); } };
    $('psok').addEventListener('click', () => go(false)); $('pslink').addEventListener('click', () => go(true)); $('psno').addEventListener('click', closePS); $('psx').addEventListener('click', closePS);
    PS.dlg.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Escape') { ev.preventDefault(); closePS(); } if (ev.key === 'Enter') { ev.preventDefault(); go(false); } });
    if ($('pspbtn')) $('pspbtn').addEventListener('click', openPS); if ($('pastebtn')) $('pastebtn').addEventListener('click', () => { paste(); box.focus(); }); }
  // ---------- gras ----------
  function toggleBold() { if (S.edit) commit(0, 0); const rr = [Math.min(S.r1, S.r2), Math.max(S.r1, S.r2)], cc = [Math.min(S.c1, S.c2), Math.max(S.c1, S.c2)];
    const first = cellObj(S.si, S.ar, S.ac); const on = !(first && first.b); pushUndo();
    for (const gi of grpList()) for (let r = rr[0]; r <= rr[1]; r++) for (let c = cc[0]; c <= cc[1]; c++) { const ref = numToCol(c) + (r + 1), sh = wb.sheets[gi]; const o = sh.cells[ref] || (sh.cells[ref] = { raw: '' }); if (on) o.b = 1; else delete o.b; }
    changed(); box.focus(); }
  if ($('bold')) $('bold').addEventListener('click', toggleBold);
  // ---------- rechercher / remplacer ----------
  const FR = { dlg: $('frdlg') };
  function openFind() { if (!FR.dlg) return; if (S.edit) commit(0, 0); FR.dlg.style.display = 'block'; $('frs').textContent = ''; $('frf').focus(); $('frf').select(); }
  function closeFind() { if (FR.dlg) FR.dlg.style.display = 'none'; box.focus(); }
  function frScope() { const multi = S.r1 !== S.r2 || S.c1 !== S.c2; const sh = wb.sheets[S.si];
    return multi ? { r1: Math.min(S.r1, S.r2), r2: Math.max(S.r1, S.r2), c1: Math.min(S.c1, S.c2), c2: Math.max(S.c1, S.c2), sel: true } : { r1: 0, r2: sh.nrows - 1, c1: 0, c2: (sh.ncols || NCOLS) - 1, sel: false }; }
  function frMatcher() { const f = $('frf').value, cs = $('frc').checked, whole = $('frw').checked; if (f === '') return null;
    const esc2 = f.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); return { re: new RegExp(whole ? '^' + esc2 + '$' : esc2, cs ? 'g' : 'gi'), test: t => new RegExp(whole ? '^' + esc2 + '$' : esc2, cs ? '' : 'i').test(t) }; }
  function frText(o) { return o && o.raw !== undefined && o.raw !== null && o.raw !== '' ? String(o.raw) : null; }
  function replaceAll() { const m = frMatcher(); if (!m) { $('frs').textContent = 'Tapez d\'abord le texte à rechercher.'; return; }
    const sc = frScope(), to = $('frr').value; let n = 0, cells = 0; const changes = [];
    for (const gi of grpList()) { const sh = wb.sheets[gi]; for (let r = sc.r1; r <= sc.r2; r++) for (let c = sc.c1; c <= sc.c2; c++) { const ref = numToCol(c) + (r + 1), o = sh.cells[ref], t = frText(o); if (t === null || !m.test(t)) continue;
      const k = (t.match(m.re) || []).length; const nt = t.replace(m.re, () => to); n += k; cells++; changes.push([gi, ref, nt]); } }
    if (!n) { $('frs').textContent = 'Aucune correspondance trouvée' + (sc.sel ? ' dans la sélection.' : ' dans la feuille.'); return; }
    pushUndo(); for (const [gi, ref, nt] of changes) setRaw(gi, ref, nt); changed();
    $('frs').textContent = `${n} remplacement${n > 1 ? 's' : ''} effectué${n > 1 ? 's' : ''}${sc.sel ? ' dans la sélection' : ' dans toute la feuille'}.`;
    window.onReplaceAll && window.onReplaceAll({ find: $('frf').value, by: to, n, sel: sc.sel, case: $('frc').checked, whole: $('frw').checked }); }
  function findNext() { const m = frMatcher(); if (!m) return; const sh = wb.sheets[S.si], nr = sh.nrows, nc = sh.ncols || NCOLS; let start = S.ar * nc + S.ac;
    for (let k = 1; k <= nr * nc; k++) { const p = (start + k) % (nr * nc), r = Math.floor(p / nc), c = p % nc; const t = frText(sh.cells[numToCol(c) + (r + 1)]); if (t !== null && m.test(t)) { S.ar = S.r1 = S.r2 = r; S.ac = S.c1 = S.c2 = c; S.scroll = true; render(); $('frs').textContent = 'Trouvé en ' + numToCol(c) + (r + 1) + '.'; return; } }
    $('frs').textContent = 'Aucune correspondance trouvée.'; }
  if (FR.dlg) { $('findbtn').addEventListener('click', openFind); $('fra').addEventListener('click', replaceAll); $('frn').addEventListener('click', findNext); $('frx').addEventListener('click', closeFind); $('frclose').addEventListener('click', closeFind);
    FR.dlg.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Escape') { ev.preventDefault(); closeFind(); } if (ev.key === 'Enter' && ev.target.tagName === 'INPUT' && ev.target.type !== 'checkbox') { ev.preventDefault(); findNext(); } }); }
  // ---------- filtres automatiques, tri, volets, somme automatique ----------
  const MOISN = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  const isDateF = f => f === 'date' || f === 'dlong' || f === 'djour';
  const blankAt = (si, r, c) => { const o = cellObj(si, r, c); return !o || o.raw === '' || o.raw === undefined; };
  function currentRegion(si, r, c) {
    const sh = wb.sheets[si], nc = sh.ncols; let r1 = r, r2 = r, c1 = c, c2 = c, grew = true;
    const rowHas = (rr, a, b) => { if (rr < 0 || rr >= sh.nrows) return false; for (let k = Math.max(0, a); k <= Math.min(nc - 1, b); k++) if (!blankAt(si, rr, k)) return true; return false; };
    const colHas = (cc, a, b) => { if (cc < 0 || cc >= nc) return false; for (let k = Math.max(0, a); k <= Math.min(sh.nrows - 1, b); k++) if (!blankAt(si, k, cc)) return true; return false; };
    while (grew) { grew = false;
      if (rowHas(r1 - 1, c1 - 1, c2 + 1)) { r1--; grew = true; } if (rowHas(r2 + 1, c1 - 1, c2 + 1)) { r2++; grew = true; }
      if (colHas(c1 - 1, r1 - 1, r2 + 1)) { c1--; grew = true; } if (colHas(c2 + 1, r1 - 1, r2 + 1)) { c2++; grew = true; } }
    return { r1, r2, c1, c2 };
  }
  function afKey(si, r, c) { const o = cellObj(si, r, c); if (!o || o.raw === '' || o.raw === undefined) return '(Vides)'; const v = o.f === 'text' ? o.raw : val(si, r, c);
    if (typeof v === 'number' && isDateF(o.f)) { const p = XL.serialToParts(v); return 'D:' + p.y + '-' + String(p.m).padStart(2, '0'); }
    return display(v, o.f); }
  const numOperand = s => { const t = String(s).trim(); return /^-?\d+(?:[.,]\d+)?$/.test(t) ? +t.replace(',', '.') : null; };
  function cusTest(x, txt, op, operand) {
    if (operand === '' || operand == null) return true; const n = numOperand(operand), t = String(txt).toLowerCase(), o = String(operand).toLowerCase();
    const wild = q => new RegExp('^' + q.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\?/g, '.') + '$', 'i');
    switch (op) {
      case 'eq': return n !== null && typeof x === 'number' ? Math.abs(x - n) < 1e-9 : wild(o).test(t);
      case 'ne': return !(n !== null && typeof x === 'number' ? Math.abs(x - n) < 1e-9 : wild(o).test(t));
      case 'gt': case 'ge': case 'lt': case 'le': { if (n === null) { if (typeof x === 'number') return false; const c = t.localeCompare(o, 'fr', { sensitivity: 'base' }); return { gt: c > 0, ge: c >= 0, lt: c < 0, le: c <= 0 }[op]; }
        if (typeof x !== 'number') return false; return { gt: x > n, ge: x >= n, lt: x < n, le: x <= n }[op]; }
      case 'bw': return t.startsWith(o); case 'nbw': return !t.startsWith(o); case 'ew': return t.endsWith(o); case 'new': return !t.endsWith(o);
      case 'ct': return t.includes(o); case 'nct': return !t.includes(o);
    } return true;
  }
  function rowPasses(si, r, crit, skip) {
    for (const k in crit) { const c = +k; if (c === skip) continue; const cr = crit[k];
      if (cr.t === 'list') { if (!cr.keys.includes(afKey(si, r, c))) return false; }
      else { const o = cellObj(si, r, c); const blank = !o || o.raw === '' || o.raw === undefined; const x = blank ? null : (o.f === 'text' ? o.raw : val(si, r, c)); const txt = blank ? '' : display(x, o.f);
        const a = cusTest(x, txt, cr.a.op, cr.a.v); const b = cr.b ? cusTest(x, txt, cr.b.op, cr.b.v) : null; if (!(cr.b ? (cr.and ? a && b : a || b) : a)) return false; } }
    return true;
  }
  function refilter(si) { const sh = wb.sheets[si]; sh.hid = new Set(); const af = sh.af; if (!af || !Object.keys(af.crit).length) return;
    for (let r = af.r + 1; r <= af.r2; r++) if (!rowPasses(si, r, af.crit, -1)) sh.hid.add(r); }
  function toggleFilter() { if (S.edit) commit(0, 0); const sh = wb.sheets[S.si]; pushUndo();
    if (sh.af) { sh.af = null; refilter(S.si); flash('Filtre supprimé : toutes les lignes sont de nouveau visibles.'); }
    else { if (blankAt(S.si, S.ar, S.ac) && !(() => { const g = currentRegion(S.si, S.ar, S.ac); return g.r2 > g.r1 || g.c2 > g.c1; })()) { S.undo.pop(); flash('Cliquez d\'abord dans la liste, puis Données → Filtrer.', 4000); return; }
      const g = currentRegion(S.si, S.ar, S.ac); sh.af = { r: g.r1, r2: g.r2, c1: g.c1, c2: g.c2, crit: {} }; }
    changed(); box.focus(); }
  function clearFilters() { if (S.edit) commit(0, 0); const sh = wb.sheets[S.si]; if (!sh.af || !Object.keys(sh.af.crit).length) { flash('Aucun filtre à effacer sur cette feuille.'); return; } pushUndo(); sh.af.crit = {}; refilter(S.si); changed(); flash('Tous les filtres sont effacés : les ' + (sh.af.r2 - sh.af.r) + ' lignes sont visibles.'); box.focus(); }
  // ----- tri -----
  function colKind(si, rows, c) { let nb = 0, nd = 0, nt = 0; for (const r of rows) { const o = cellObj(si, r, c); if (!o || o.raw === '' || o.raw === undefined) continue; const v = o.f === 'text' ? o.raw : val(si, r, c); if (typeof v === 'number') { if (isDateF(o.f)) nd++; else nb++; } else nt++; }
    return nt > nb + nd ? 'text' : nd > nb ? 'date' : 'num'; }
  function orderLabels(kind) { return kind === 'text' ? ['De A à Z', 'De Z à A'] : kind === 'date' ? ['Du plus ancien au plus récent', 'Du plus récent au plus ancien'] : ['Du plus petit au plus grand', 'Du plus grand au plus petit']; }
  function cmpVals(a, b) { const ba = a === null || a === '', bb = b === null || b === '';
    if (ba || bb) return ba && bb ? 0 : ba ? 1 : -1; const na = typeof a === 'number', nb = typeof b === 'number';
    if (na && nb) return a - b; if (na) return -1; if (nb) return 1; return String(a).localeCompare(String(b), 'fr', { sensitivity: 'base', numeric: false }); }
  function sortRows(si, r1, r2, c1, c2, keys) { // keys: [{c, desc}] — seules les lignes visibles sont triées (comme Excel)
    const sh = wb.sheets[si]; const rows = []; for (let r = r1; r <= r2; r++) if (!sh.hid.has(r)) rows.push(r);
    const data = rows.map(r => { const cells = {}; for (let c = c1; c <= c2; c++) { const ref = numToCol(c) + (r + 1); cells[c] = sh.cells[ref]; }
      const kv = keys.map(k => { const o = cells[k.c]; return !o || o.raw === '' || o.raw === undefined ? null : (o.f === 'text' ? o.raw : val(si, r, k.c)); }); return { r, cells, kv }; });
    const sorted = data.slice().sort((x, y) => { for (let i = 0; i < keys.length; i++) { const a = x.kv[i], b = y.kv[i]; const ba = a === null || a === '', bb = b === null || b === ''; if (ba || bb) { if (ba && bb) continue; return ba ? 1 : -1; } let d = cmpVals(a, b); if (keys[i].desc) d = -d; if (d) return d; } return x.r - y.r; });
    sorted.forEach((d, i) => { const tr = rows[i]; for (let c = c1; c <= c2; c++) { const ref = numToCol(c) + (tr + 1); const src = d.cells[c];
      if (!src) { delete sh.cells[ref]; continue; } if (src.ast !== undefined && d.r !== tr) { sh.cells[ref] = { f: src.f }; if (src.b) sh.cells[ref].b = 1; setRaw(si, ref, shiftFormula(src.raw, tr - d.r, 0), true); } else sh.cells[ref] = src; } });
  }
  function sortRange(si, hdrGuess) { const sh = wb.sheets[si]; if (sh.af && S.ar >= sh.af.r && S.ar <= sh.af.r2 && S.ac >= sh.af.c1 && S.ac <= sh.af.c2) return { r1: sh.af.r, r2: sh.af.r2, c1: sh.af.c1, c2: sh.af.c2, af: true };
    const g = currentRegion(si, S.ar, S.ac); return g; }
  function guessHeader(si, g) { if (g.af) return true; let allText = true, below = false; for (let c = g.c1; c <= g.c2; c++) { const o = cellObj(si, g.r1, c); if (o && o.raw !== '' && o.raw !== undefined && typeof val(si, g.r1, c) === 'number') allText = false; const p = cellObj(si, g.r1 + 1, c); if (p && typeof val(si, g.r1 + 1, c) === 'number') below = true; } return allText && below; }
  function quickSort(desc) { if (S.edit) commit(0, 0); const si = S.si; if (blankAt(si, S.ar, S.ac) && !wb.sheets[si].af) { flash('Cliquez d\'abord dans la colonne à trier.'); return; } const g = sortRange(si); const hdr = guessHeader(si, g);
    pushUndo(); sortRows(si, hdr ? g.r1 + 1 : g.r1, g.r2, g.c1, g.c2, [{ c: S.ac, desc }]); if (wb.sheets[si].af && g.af) wb.sheets[si].af.sort = { c: S.ac, desc }; changed(); box.focus(); }
  // ----- liste déroulante de filtre -----
  const AFM = document.createElement('div'); AFM.id = 'afm'; document.body.appendChild(AFM);
  let afState = null;
  function closeAF() { AFM.style.display = 'none'; afState = null; }
  function openAF(c, btn) {
    const si = S.si, sh = wb.sheets[si], af = sh.af; if (!af) return; const hdr = cellObj(si, af.r, c); const hname = hdr && hdr.raw ? String(hdr.raw) : 'Colonne ' + numToCol(c);
    const rows = []; for (let r = af.r + 1; r <= af.r2; r++) rows.push(r); const kind = colKind(si, rows, c);
    const avail = new Map(); for (const r of rows) if (rowPasses(si, r, af.crit, c)) { const k = afKey(si, r, c); if (!avail.has(k)) { const o = cellObj(si, r, c); avail.set(k, { k, v: !o || o.raw === '' || o.raw === undefined ? null : (o.f === 'text' ? o.raw : val(si, r, c)) }); } }
    let items = [...avail.values()];
    const cur = af.crit[c]; const checked = new Set(cur && cur.t === 'list' ? cur.keys : (cur ? [...avail.keys()].filter(k => [...Array(af.r2 - af.r)].some((_, i) => afKey(si, af.r + 1 + i, c) === k && rowPasses(si, af.r + 1 + i, { [c]: cur }, -1))) : [...avail.keys()]));
    if (kind === 'date') { items.sort((a, b) => a.k === '(Vides)' ? 1 : b.k === '(Vides)' ? -1 : a.k < b.k ? -1 : 1); }
    else items.sort((a, b) => a.k === '(Vides)' ? 1 : b.k === '(Vides)' ? -1 : cmpVals(a.v, b.v));
    const L = orderLabels(kind); afState = { c, si, kind, items, checked, hname, q: '' };
    const cf = kind === 'text' ? [['eq', 'Est égal à…'], ['ne', 'Est différent de…'], ['bw', 'Commence par…'], ['ew', 'Se termine par…'], ['ct', 'Contient…'], ['nct', 'Ne contient pas…']]
      : kind === 'num' ? [['eq', 'Est égal à…'], ['ne', 'Est différent de…'], ['gt', 'Supérieur à…'], ['ge', 'Supérieur ou égal à…'], ['lt', 'Inférieur à…'], ['le', 'Inférieur ou égal à…'], ['bt', 'Entre…']] : [];
    const cfl = kind === 'text' ? 'Filtres textuels' : kind === 'num' ? 'Filtres numériques' : 'Filtres chronologiques';
    AFM.innerHTML = `<button data-afs="0">↑ Trier ${L[0].replace(/^De /, 'de ').replace(/^Du /, 'du ')}</button><button data-afs="1">↓ Trier ${L[1].replace(/^De /, 'de ').replace(/^Du /, 'du ')}</button><hr>
      <button data-afx="1" ${cur ? '' : 'disabled'}>✕ Effacer le filtre de « ${esc(hname)} »</button>
      <div class="sub"><button class="subh">${cfl} ▸</button><div class="subm">${cf.length ? cf.map(([k, l]) => `<button data-cf="${k}">${l}</button>`).join('') + '<hr><button data-cf="custom">Filtre personnalisé…</button>' : '<button disabled>Utilisez la liste ci-dessous</button>'}</div></div>
      <input class="afq" placeholder="Rechercher" autocomplete="off" spellcheck="false"><div class="afl"></div>
      <div class="afbt"><button class="b p" data-afok="1">OK</button><button class="b" data-afno="1">Annuler</button></div>`;
    drawAFList(); AFM.style.display = 'block'; const r = btn.getBoundingClientRect();
    AFM.style.left = Math.max(8, Math.min(r.left, innerWidth - AFM.offsetWidth - 8)) + 'px'; AFM.style.top = Math.min(r.bottom + 2, innerHeight - AFM.offsetHeight - 8) + 'px';
    const q = AFM.querySelector('.afq'); q.addEventListener('input', () => { afState.q = q.value; drawAFList(); }); q.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') { e.preventDefault(); okAF(); } if (e.key === 'Escape') { closeAF(); box.focus(); } });
  }
  function afLabel(it) { if (it.k === '(Vides)') return '(Vides)'; if (it.k.startsWith('D:')) { const m = +it.k.slice(7); return MOISN[m - 1]; } return it.k; }
  function afVisible() { const q = afState.q.trim().toLowerCase(); if (!q) return afState.items; return afState.items.filter(it => afLabel(it).toLowerCase().includes(q) || (it.k.startsWith('D:') && it.k.slice(2, 6).includes(q))); }
  function drawAFList() { const st = afState, vis = afVisible(), q = st.q.trim(); const box2 = AFM.querySelector('.afl'); let h = '';
    if (q && st.qKey !== q) st.qSel = new Set(vis.map(it => it.k)); st.qKey = q;
    const allOn = vis.length && vis.every(it => (q ? st.qSel : st.checked).has(it.k));
    if (q) { h += `<label class="all"><input type="checkbox" data-all="1" ${allOn ? 'checked' : ''}> (Sélectionner tous les résultats de la recherche)</label>`; if (!vis.length) h += '<div class="none">Aucune correspondance</div>'; }
    else h += `<label class="all"><input type="checkbox" data-all="1" ${allOn ? 'checked' : ''}> (Sélectionner tout)</label>`;
    if (st.kind === 'date') { const years = [...new Set(vis.filter(it => it.k.startsWith('D:')).map(it => it.k.slice(2, 6)))];
      for (const y of years) { const ms = vis.filter(it => it.k.startsWith('D:' + y)); const on = ms.filter(it => (q ? st.qSel : st.checked).has(it.k)).length;
        h += `<label><input type="checkbox" data-yr="${y}" ${on === ms.length ? 'checked' : ''} ${on && on < ms.length ? 'data-ind="1"' : ''}> ${y}</label>`;
        h += ms.map(it => `<label class="l1"><input type="checkbox" data-k="${esc(it.k)}" ${(q ? st.qSel : st.checked).has(it.k) ? 'checked' : ''}> ${afLabel(it)}</label>`).join(''); }
      const vb = vis.find(it => it.k === '(Vides)'); if (vb) h += `<label><input type="checkbox" data-k="(Vides)" ${(q ? st.qSel : st.checked).has('(Vides)') ? 'checked' : ''}> (Vides)</label>`; }
    else h += vis.map(it => `<label><input type="checkbox" data-k="${esc(it.k).replace(/"/g, '&quot;')}" ${(q ? st.qSel : st.checked).has(it.k) ? 'checked' : ''}> ${esc(afLabel(it))}</label>`).join('');
    box2.innerHTML = h; box2.querySelectorAll('[data-ind]').forEach(e => e.indeterminate = true); }
  AFM.addEventListener('mousedown', ev => { if (ev.target.tagName !== 'INPUT') ev.preventDefault(); });
  AFM.addEventListener('change', ev => { const t = ev.target, st = afState; if (!st) return; const q = st.q.trim(); const tgt = q ? st.qSel : st.checked; const vis = afVisible();
    if (t.dataset.all) { if (t.checked) vis.forEach(it => tgt.add(it.k)); else vis.forEach(it => tgt.delete(it.k)); }
    else if (t.dataset.yr) { vis.filter(it => it.k.startsWith('D:' + t.dataset.yr)).forEach(it => t.checked ? tgt.add(it.k) : tgt.delete(it.k)); }
    else if (t.dataset.k !== undefined) { if (t.checked) tgt.add(t.dataset.k); else tgt.delete(t.dataset.k); }
    drawAFList(); });
  AFM.addEventListener('click', ev => { const b = ev.target.closest('button'); if (!b || b.disabled || b.classList.contains('subh')) return; const st = afState; if (!st) return;
    if (b.dataset.afno) { closeAF(); box.focus(); return; }
    if (b.dataset.afok) { okAF(); return; }
    if (b.dataset.afs) { const c = st.c; closeAF(); S.ac = S.c1 = S.c2 = c; S.ar = S.r1 = S.r2 = wb.sheets[S.si].af.r + 1; pushUndo(); const af = wb.sheets[S.si].af; sortRows(S.si, af.r + 1, af.r2, af.c1, af.c2, [{ c, desc: b.dataset.afs === '1' }]); af.sort = { c, desc: b.dataset.afs === '1' }; changed(); box.focus(); return; }
    if (b.dataset.afx) { const c = st.c; closeAF(); pushUndo(); delete wb.sheets[S.si].af.crit[c]; refilter(S.si); changed(); box.focus(); return; }
    if (b.dataset.cf) { const c = st.c, nm = st.hname; closeAF(); openCF(c, nm, b.dataset.cf); } });
  function okAF() { const st = afState; if (!st) return; const af = wb.sheets[st.si].af; const q = st.q.trim();
    let keys; if (q) keys = [...st.qSel]; else keys = [...st.checked];
    const allKeys = st.items.map(it => it.k); closeAF();
    if (!keys.length) { flash('Cochez au moins un élément.'); return; }
    pushUndo(); if (!q && allKeys.every(k => keys.includes(k))) delete af.crit[st.c]; else af.crit[st.c] = { t: 'list', keys };
    refilter(st.si); S.ar = S.r1 = S.r2 = af.r; S.ac = S.c1 = S.c2 = st.c; changed(); box.focus(); }
  document.addEventListener('mousedown', ev => { if (AFM.style.display === 'block' && !ev.target.closest('#afm') && !ev.target.closest('.afb')) closeAF(); });
  // ----- filtre personnalisé -----
  const CFOPS = [['eq', 'est égal à'], ['ne', 'est différent de'], ['gt', 'est supérieur à'], ['ge', 'est supérieur ou égal à'], ['lt', 'est inférieur à'], ['le', 'est inférieur ou égal à'], ['bw', 'commence par'], ['nbw', 'ne commence pas par'], ['ew', 'se termine par'], ['new', 'ne se termine pas par'], ['ct', 'contient'], ['nct', 'ne contient pas']];
  const CFD = document.createElement('div'); CFD.id = 'cfdlg'; document.body.appendChild(CFD); let cfState = null;
  function openCF(c, hname, preset) { const cur = wb.sheets[S.si].af.crit[c]; let a = { op: preset === 'bt' ? 'ge' : preset === 'custom' ? 'eq' : preset, v: '' }, b = { op: preset === 'bt' ? 'le' : '', v: '' }, and = true;
    if (cur && cur.t === 'cus') { a = { ...cur.a }; if (cur.b) b = { ...cur.b }; and = cur.and; if (preset !== 'custom') { a.op = preset === 'bt' ? 'ge' : preset; if (preset === 'bt') b.op = 'le'; } }
    const sel = (n, v) => `<select data-op="${n}"><option value=""></option>${CFOPS.map(([k, l]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    CFD.innerHTML = `<div class="frh"><b>Filtre automatique personnalisé</b><button data-cx="1" title="Fermer">✕</button></div><div style="margin:4px 0 8px">Afficher les lignes dans lesquelles : <b>${esc(hname)}</b></div>
      <div class="cfr">${sel('a', a.op)}<input data-v="a" value="${esc(a.v)}" autocomplete="off"></div>
      <div class="cfa"><label><input type="radio" name="cfand" value="1" ${and ? 'checked' : ''}> Et</label><label><input type="radio" name="cfand" value="0" ${and ? '' : 'checked'}> Ou</label></div>
      <div class="cfr">${sel('b', b.op)}<input data-v="b" value="${esc(b.v)}" autocomplete="off"></div>
      <div class="kbd" style="margin:6px 0">Utilisez ? pour représenter un caractère, * pour une série de caractères.</div>
      <div class="frb"><button class="b p" data-cok="1">OK</button><button class="b" data-cx="1">Annuler</button></div>`;
    cfState = { c }; CFD.style.display = 'block'; const i = CFD.querySelector('input[data-v="a"]'); i.focus(); i.select(); }
  CFD.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Escape') { ev.preventDefault(); CFD.style.display = 'none'; box.focus(); } if (ev.key === 'Enter') { ev.preventDefault(); okCF(); } });
  CFD.addEventListener('click', ev => { const b = ev.target.closest('button'); if (!b) return; if (b.dataset.cx) { CFD.style.display = 'none'; box.focus(); } if (b.dataset.cok) okCF(); });
  function okCF() { const g = n => ({ op: CFD.querySelector(`select[data-op="${n}"]`).value, v: CFD.querySelector(`input[data-v="${n}"]`).value });
    const a = g('a'), b = g('b'), and = CFD.querySelector('input[name=cfand]:checked').value === '1'; CFD.style.display = 'none';
    if (!a.op || a.v === '') { if (!b.op || b.v === '') { box.focus(); return; } }
    const af = wb.sheets[S.si].af; pushUndo(); const A1 = a.op && a.v !== '' ? a : b, B1 = a.op && a.v !== '' && b.op && b.v !== '' ? b : null;
    af.crit[cfState.c] = { t: 'cus', a: A1, b: B1, and }; refilter(S.si); S.ar = S.r1 = S.r2 = af.r; S.ac = S.c1 = S.c2 = cfState.c; changed(); box.focus(); }
  // ----- dialogue Trier -----
  const SDL = document.createElement('div'); SDL.id = 'sdlg'; document.body.appendChild(SDL); let sdState = null;
  function openSort() { if (S.edit) commit(0, 0); const si = S.si; if (blankAt(si, S.ar, S.ac) && !wb.sheets[si].af) { flash('Cliquez d\'abord dans la liste à trier.'); return; } const g = sortRange(si);
    sdState = { si, g, hdr: guessHeader(si, g), lv: [{ c: S.ac >= g.c1 && S.ac <= g.c2 ? S.ac : g.c1, desc: false }], cur: 0 }; drawSort(); SDL.style.display = 'block'; }
  function drawSort() { const st = sdState, g = st.g; const rows = []; for (let r = st.hdr ? g.r1 + 1 : g.r1; r <= g.r2; r++) rows.push(r);
    const cols = []; for (let c = g.c1; c <= g.c2; c++) { const o = cellObj(st.si, g.r1, c); cols.push([c, st.hdr && o && o.raw !== '' && o.raw !== undefined ? String(display(val(st.si, g.r1, c), o.f)) : 'Colonne ' + numToCol(c)]); }
    SDL.innerHTML = `<div class="frh"><b>Trier</b><button data-sx="1" title="Fermer">✕</button></div>
      <div class="sdt"><button class="b" data-sadd="1">+ Ajouter un niveau</button><button class="b" data-sdel="1" ${st.lv.length > 1 ? '' : 'disabled'}>✕ Supprimer un niveau</button><label class="sdh"><input type="checkbox" data-sh="1" ${st.hdr ? 'checked' : ''}> Mes données ont des en-têtes</label></div>
      <table class="sdl"><thead><tr><th></th><th>Colonne</th><th>Trier sur</th><th>Ordre</th></tr></thead><tbody>${st.lv.map((l, i) => { const L = orderLabels(colKind(st.si, rows, l.c));
        return `<tr class="${i === st.cur ? 'on' : ''}" data-li="${i}"><td>${i ? 'Puis par' : 'Trier par'}</td><td><select data-sc="${i}">${cols.map(([c, n]) => `<option value="${c}" ${c === l.c ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></td><td>Valeurs des cellules</td><td><select data-so="${i}"><option value="0" ${l.desc ? '' : 'selected'}>${L[0]}</option><option value="1" ${l.desc ? 'selected' : ''}>${L[1]}</option></select></td></tr>`; }).join('')}</tbody></table>
      <div class="frb"><button class="b p" data-sok="1">OK</button><button class="b" data-sx="1">Annuler</button></div>`; }
  SDL.addEventListener('click', ev => { const st = sdState; if (!st) return; const tr = ev.target.closest('tr[data-li]'); if (tr) { st.cur = +tr.dataset.li; SDL.querySelectorAll('tr[data-li]').forEach(x => x.classList.toggle('on', +x.dataset.li === st.cur)); }
    const b = ev.target.closest('button'); if (!b || b.disabled) return;
    if (b.dataset.sx) { SDL.style.display = 'none'; sdState = null; box.focus(); return; }
    if (b.dataset.sadd) { const used = new Set(st.lv.map(l => l.c)); let c = st.g.c1; for (let k = st.g.c1; k <= st.g.c2; k++) if (!used.has(k)) { c = k; break; } st.lv.push({ c, desc: false }); st.cur = st.lv.length - 1; drawSort(); return; }
    if (b.dataset.sdel) { st.lv.splice(st.cur, 1); st.cur = Math.max(0, st.cur - 1); drawSort(); return; }
    if (b.dataset.sok) { SDL.style.display = 'none'; const g = st.g; pushUndo(); sortRows(st.si, st.hdr ? g.r1 + 1 : g.r1, g.r2, g.c1, g.c2, st.lv); const af = wb.sheets[st.si].af; if (af && g.af) af.sort = { c: st.lv[0].c, desc: st.lv[0].desc };
      window.onSortDialog && window.onSortDialog({ hdr: st.hdr, lv: st.lv.map(l => ({ ...l })) }); sdState = null; changed(); box.focus(); } });
  SDL.addEventListener('change', ev => { const st = sdState, t = ev.target; if (t.dataset.sh) { st.hdr = t.checked; drawSort(); } else if (t.dataset.sc !== undefined) { st.lv[+t.dataset.sc].c = +t.value; drawSort(); } else if (t.dataset.so !== undefined) st.lv[+t.dataset.so].desc = t.value === '1'; });
  SDL.addEventListener('keydown', ev => { ev.stopPropagation(); if (ev.key === 'Escape') { SDL.style.display = 'none'; sdState = null; box.focus(); } });
  // ----- figer les volets -----
  function openFreeze(btn) { const sh = wb.sheets[S.si]; const r = btn.getBoundingClientRect();
    menu.innerHTML = sh.fz ? `<button data-fz="off">Libérer les volets</button><button data-fz="row">Figer la ligne supérieure</button><button data-fz="col">Figer la première colonne</button>` : `<button data-fz="here">Figer les volets<span>à gauche et au-dessus de la cellule active</span></button><button data-fz="row">Figer la ligne supérieure</button><button data-fz="col">Figer la première colonne</button>`;
    menu.style.display = 'block'; menu.style.left = Math.min(r.left, innerWidth - menu.offsetWidth - 8) + 'px'; menu.style.top = (r.bottom + 2) + 'px'; }
  menu.addEventListener('click', ev => { const b = ev.target.closest('button[data-fz]'); if (!b) return; const sh = wb.sheets[S.si]; pushUndo(); const k = b.dataset.fz;
    if (k === 'off') sh.fz = null; else if (k === 'row') sh.fz = { r: 1, c: 0 }; else if (k === 'col') sh.fz = { r: 0, c: 1 }; else { if (!S.ar && !S.ac) { S.undo.pop(); return; } sh.fz = { r: S.ar, c: S.ac }; }
    closeMenu(); changed(); flash(sh.fz ? (sh.fz.r && sh.fz.c ? `Volets figés : lignes 1 à ${sh.fz.r} et colonnes A à ${numToCol(sh.fz.c - 1)}.` : sh.fz.r ? `Volets figés : ${sh.fz.r > 1 ? 'lignes 1 à ' + sh.fz.r : 'ligne 1'}.` : `Volets figés : ${sh.fz.c > 1 ? 'colonnes A à ' + numToCol(sh.fz.c - 1) : 'colonne A'}.`) : 'Volets libérés.'); box.focus(); }, true);
  // ----- somme automatique -----
  function autoSum() { if (S.edit) commit(0, 0); const si = S.si, sh = wb.sheets[si], c = S.ac, r = S.ar; const isNum = rr => { const o = cellObj(si, rr, c); return o && o.raw !== '' && o.raw !== undefined && typeof val(si, rr, c) === 'number' && !(o.ast !== undefined && /SOUS\.TOTAL|SOMME/i.test(o.raw)); };
    let r2 = r - 1; while (r2 >= 0 && blankAt(si, r2, c) && r - r2 < 2) r2--; if (r2 < 0 || !isNum(r2)) { startEdit('=SOMME()', 'enter'); return; }
    let r1 = r2; while (r1 - 1 >= 0 && (isNum(r1 - 1))) r1--;
    const af = sh.af, filtered = af && Object.keys(af.crit).length && r1 >= af.r && r2 <= af.r2 + 1;
    const ref = numToCol(c) + (r1 + 1) + ':' + numToCol(c) + (r2 + 1); const t = filtered ? `=SOUS.TOTAL(9;${ref})` : `=SOMME(${ref})`;
    const tgt = sh.cells[numToCol(c) + (r + 1)] || (sh.cells[numToCol(c) + (r + 1)] = { raw: '' }); const above = cellObj(si, r2, c); if ((!tgt.f || tgt.f === 'gen') && above && above.f) tgt.f = above.f;
    startEdit(t, 'enter'); const st = t.indexOf(ref); S.edit.point = { start: st, end: st + ref.length, r1, c1: c, r2, c2: c }; cellEd.setSelectionRange(st, st + ref.length); }
  // ----- ruban : onglets Accueil / Données / Affichage -----
  document.querySelectorAll('.rtabs span[data-rt]').forEach(t => t.addEventListener('click', () => { document.querySelectorAll('.rtabs span').forEach(x => x.classList.toggle('on', x === t)); const k = t.dataset.rt;
    document.querySelectorAll('.rbody > *').forEach(g => g.classList.toggle('off', (g.dataset.rt || 'acc') !== k)); }));
  if ($('afon')) { $('afon').addEventListener('click', toggleFilter); $('afclr').addEventListener('click', clearFilters); $('sorta').addEventListener('click', () => quickSort(false)); $('sortz').addEventListener('click', () => quickSort(true)); $('sortd').addEventListener('click', openSort);
    $('fzbtn').addEventListener('mousedown', ev => { ev.preventDefault(); ev.stopPropagation(); openFreeze($('fzbtn')); }); $('asum').addEventListener('click', autoSum); }
  window.XLAPP = {
    wb, idx, names: () => wb.sheets.map(s => s.name), grouped: () => !!(S.grp && S.grp.size > 1),
    val: (si, ref) => { si = idx(si); if (si < 0) return null; const m = ref.match(/^([A-Z]+)(\d+)$/); return val(si, +m[2] - 1, colToNum(m[1])); },
    cell: (si, ref) => { si = idx(si); return si < 0 ? undefined : wb.sheets[si].cells[ref]; }, display, todaySerial,
    sel: () => ({ si: S.si, r1: Math.min(S.r1, S.r2), r2: Math.max(S.r1, S.r2), c1: Math.min(S.c1, S.c2), c2: Math.max(S.c1, S.c2) }),
    reset() { restore(JSON.parse(ORIGINAL)); S.undo = []; S.si = 0; S.grp = null; S.p3 = null; S.ar = S.r1 = S.r2 = 1; S.ac = S.c1 = S.c2 = 3; changed(); },
    load(d) { load(d); render(); }, savedLocal() { try { return localStorage.getItem(KEY); } catch (e) { return null; } },
    goto(si, ref) { si = idx(si); if (si < 0) si = 0; if (S.edit) commit(0, 0); const m = ref.match(/^([A-Z]+)(\d+)$/); S.si = si; S.ar = S.r1 = S.r2 = +m[2] - 1; S.ac = S.c1 = S.c2 = colToNum(m[1]); S.scroll = true; render(); box.focus(); },
    toggleFormulas() { S.showF = !S.showF; if (S.showF) window.onShowFormulas && window.onShowFormulas(); const b = $('showf'); if (b) b.classList.toggle('on', S.showF); render(); },
    render, serialize,
    af: si => { const s = wb.sheets[idx(si)]; return s && s.af ? JSON.parse(JSON.stringify(s.af)) : null; }, hidden: si => [...wb.sheets[idx(si)].hid], fz: si => { const s = wb.sheets[idx(si)]; return s.fz ? { ...s.fz } : null; },
    setMarks(si, list) { si = idx(si); const map = {}; for (const [ref, k, why] of list) { const o = wb.sheets[si].cells[ref]; const m = ref.match(/^([A-Z]+)(\d+)$/); const v = o && o.raw !== '' && o.raw !== undefined ? (o.f === 'text' ? o.raw : val(si, +m[2] - 1, colToNum(m[1]))) : null; const txt = o && o.raw !== '' && o.raw !== undefined ? display(v, o.f) : ''; map[ref] = { k, why, sig: o ? (o.raw || '') + '|' + (o.f || '') + '|' + txt : '' }; } S.marks = { name: wb.sheets[si].name, map }; render(); },
    clearMarks() { S.marks = null; render(); },
    setTargets(si, refs) { si = idx(si); const set = new Set(); for (const x of refs) { const m = x.match(/^([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?$/); const c1 = colToNum(m[1]), r1 = +m[2], c2 = m[3] ? colToNum(m[3]) : c1, r2 = m[3] ? +m[4] : r1; for (let r = r1; r <= r2; r++) for (let c = c1; c <= c2; c++) set.add(numToCol(c) + r); } S.tg = { name: si >= 0 ? wb.sheets[si].name : '', cells: set }; render(); },
  };
  render(); box.focus();
})();
