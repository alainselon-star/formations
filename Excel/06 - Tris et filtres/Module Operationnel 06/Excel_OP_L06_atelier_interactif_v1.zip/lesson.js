// Atelier 06 interactif — Les 500 lignes (tris et filtres)
(function () {
  'use strict';
  const A = XLAPP, DP = 'Dépenses 2026', RP = 'Réponses';
  const c = (s, r) => A.cell(s, r) || {};
  const raw = (s, r) => String(c(s, r).raw || '').toUpperCase().replace(/\s/g, '');
  const OK = m => ({ ok: true, msg: m }), KO = m => ({ ok: false, msg: m });
  const empty = (s, r) => { const x = c(s, r).raw; return x === undefined || x === ''; };
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.006;
  const numAns = ref => { const v = A.val(RP, ref); if (typeof v === 'number') return v; if (typeof v === 'string') { const t = v.replace(/[\s €]/g, '').replace(',', '.'); return /^-?\d+(\.\d+)?$/.test(t) ? +t : null; } return null; };
  const txtAns = ref => String(A.val(RP, ref) == null ? '' : A.val(RP, ref)).trim().toLowerCase();
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} réponse${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  // données d'origine (indépendantes du tri) pour calculer les bonnes réponses
  const W = window.WB[0].cells, ROWS = [];
  for (let r = 2; r <= 501; r++) ROWS.push({ d: W['A' + r].v, ch: W['B' + r].v, cat: W['C' + r].v, fo: W['D' + r].v, m: W['E' + r].v });
  const mon = s => XLAPP.display(s, 'date').slice(3, 5) | 0;
  const agg = f => { const x = ROWS.filter(f); return { n: x.length, s: Math.round(x.reduce((p, q) => p + q.m, 0) * 100) / 100, top: x.slice().sort((a, b) => b.m - a.m)[0] }; };
  const Q1 = agg(r => r.cat === 'Sous-traitance' && mon(r.d) <= 3);
  const ST = agg(r => r.cat === 'Sous-traitance'), Q1ALL = agg(r => mon(r.d) <= 3);
  const LER = agg(r => /leroy/i.test(r.ch)), LERCUM = agg(r => /leroy/i.test(r.ch) && r.cat === 'Sous-traitance' && mon(r.d) <= 3);
  const G3 = agg(r => r.m > 3000), BT = agg(r => r.m >= 2000 && r.m <= 4000), BTS = agg(r => r.m > 2000 && r.m < 4000);
  const DUV = agg(r => /duval/i.test(r.fo)), DUV1 = agg(r => r.fo === 'Échafaudages Duval'), DUV2 = agg(r => r.fo === 'Duval Plomberie');
  const HP = agg(r => r.ch === 'Hôtel du Parc — Senlis'), LJ = agg(r => r.cat === 'Location' && mon(r.d) === 6), TOT = agg(() => true);
  const S = [];
  const nb = (ref, exp, extra) => { const v = numAns(ref); if (empty(RP, ref)) return 'Pas encore de réponse.'; if (v === null) return 'Tapez un nombre, sans texte.'; if (near(v, exp)) return null; return (extra && extra(v)) || 'Ce n\'est pas le bon résultat.'; };

  S.push({ t: 'La demande du comptable', go: [DP, 'A2'], tg: [RP, ['B4:B6']],
    need: 'Le comptable veut les dépenses de <b>sous-traitance</b> du <b>premier trimestre</b> (janvier à mars), de la plus grosse à la plus petite : combien il y en a, pour quel montant, et qui a facturé la plus grosse.',
    ou: 'Feuille <b>Dépenses 2026</b> : cliquez dans la liste, onglet <b>Données</b> → <b>Filtrer</b>. Utilisez les flèches des colonnes Catégorie, Date et Montant HT. Notez vos réponses feuille <b>Réponses</b>, en B4, B5 et B6. Astuce : onglet <b>Affichage</b> → Figer les volets → Figer la ligne supérieure garde les titres visibles.',
    verif: 'La barre d\'état, en bas, annonce le nombre d\'enregistrements trouvés sur 500. Sélectionnez les montants visibles : la barre d\'état donne leur somme.',
    h: ['Flèche de <b>Catégorie</b> : décochez (Sélectionner tout), cochez Sous-traitance, OK. Flèche de <b>Date</b> : ne laissez cochés que janvier, février et mars. Flèche de <b>Montant HT</b> : Trier du plus grand au plus petit.', 'Le nombre est dans la barre d\'état (« … enregistrements trouvés sur 500 »). Pour la somme, cliquez sur la lettre <b>E</b> : la barre d\'état n\'additionne que les lignes visibles. Le fournisseur de la plus grosse dépense est en tête de liste après le tri.'],
    sol: `Données → Filtrer. Catégorie : Sous-traitance seule. Date : janvier, février, mars. Montant HT : Trier du plus grand au plus petit. Réponses : B4 = <b>${Q1.n}</b>, B5 = <b>${XLAPP.display(Q1.s, 'eur2')}</b>, B6 = <b>${Q1.top.fo}</b>.`,
    cells: () => [[RP, 'B4', nb('B4', Q1.n, v => v === Q1.n + 1 ? 'Vous avez compté la ligne de titre : prenez le nombre d\'enregistrements trouvés.' : v === 500 ? 'C\'est le nombre total de lignes : filtrez d\'abord.' : v === ST.n ? 'C\'est toute la sous-traitance de l\'année : filtrez aussi la date (janvier à mars).' : v === Q1ALL.n ? 'C\'est tout le premier trimestre : filtrez aussi la catégorie.' : null)],
      [RP, 'B5', nb('B5', Q1.s, v => near(v, TOT.s) ? 'C\'est le total des 500 lignes : sélectionnez la colonne une fois filtrée.' : near(v, ST.s) ? 'C\'est toute la sous-traitance de l\'année : filtrez aussi la date.' : near(v, Q1.s - Q1.top.m) || near(v, Q1.top.m) ? 'Sélectionnez tous les montants visibles (cliquez sur la lettre E).' : null)],
      [RP, 'B6', empty(RP, 'B6') ? 'Pas encore de réponse.' : txtAns('B6').includes(Q1.top.fo.split(' ')[0].toLowerCase()) ? null : 'Ce n\'est pas le fournisseur de la plus grosse dépense : triez le montant du plus grand au plus petit et lisez la première ligne.']],
    check() { return summary(this.cells(), `${Q1.n} dépenses pour ${XLAPP.display(Q1.s, 'eur2')}, la plus grosse chez ${Q1.top.fo} (${XLAPP.display(Q1.top.m, 'eur2')}). Sans rien recopier ni supprimer : les autres lignes sont seulement masquées.`); } });

  S.push({ t: 'Le chantier Leroy', go: [DP, 'B1'], tg: [RP, ['B9']],
    need: 'Sophie veut le montant total des dépenses du <b>chantier Leroy</b>, toutes catégories et toutes dates confondues.',
    ou: 'Feuille <b>Dépenses 2026</b>, flèche de <b>Chantier</b> : tapez « Leroy » dans la zone <b>Rechercher</b>. Réponse feuille <b>Réponses</b>, en <b>B9</b>.',
    verif: `Vous devez trouver ${LER.n} lignes. Si vous en voyez beaucoup moins, les filtres de la mission 1 sont encore actifs.`,
    h: ['Les filtres se cumulent : effacez d\'abord ceux de la mission 1 (flèche → Effacer le filtre de…, ou Données → <b>Effacer</b> pour tout retirer d\'un coup).', 'Flèche de Chantier → tapez Leroy dans Rechercher → OK. Cliquez ensuite sur la lettre E pour lire la somme dans la barre d\'état.'],
    sol: `Données → Effacer. Flèche de Chantier → Rechercher : Leroy → OK. Lettre E → barre d'état. B9 = <b>${XLAPP.display(LER.s, 'eur2')}</b>.`,
    cells: () => [[RP, 'B9', nb('B9', LER.s, v => near(v, LERCUM.s) ? 'Les filtres de la mission 1 sont encore actifs : effacez-les avant de filtrer le chantier.' : near(v, TOT.s) ? 'C\'est le total des 500 lignes : filtrez le chantier.' : null)]],
    check() { return summary(this.cells(), `${LER.n} dépenses pour ${XLAPP.display(LER.s, 'eur2')}. Retenez le réflexe : on efface les filtres précédents avant d'en poser un nouveau.`); } });

  S.push({ t: 'Les filtres numériques', go: [DP, 'E1'], tg: [RP, ['B12:B14']],
    need: 'Le comptable veut d\'abord le nombre de dépenses <b>au-dessus de 3 000 €</b>, puis le nombre et le montant des dépenses <b>entre 2 000 € et 4 000 €</b> (bornes comprises).',
    ou: 'Flèche de <b>Montant HT</b> → <b>Filtres numériques</b>. Réponses en <b>B12</b>, <b>B13</b> et <b>B14</b>.',
    verif: 'Avec « Supérieur à », la barre d\'état doit trouver ' + G3.n + ' dépenses. Avec « Entre », vérifiez que les deux lignes de la boîte de dialogue sont reliées par <b>Et</b>.',
    h: ['Données → Effacer d\'abord. Puis flèche de Montant HT → Filtres numériques → Supérieur à… → tapez <b>3000</b>, sans espace ni symbole €.', '« Entre… » ouvre la boîte avec deux conditions : « est supérieur ou égal à » 2000 <b>Et</b> « est inférieur ou égal à » 4000.'],
    sol: `Filtres numériques → Supérieur à… 3000 → B12 = <b>${G3.n}</b>. Puis Filtres numériques → Entre… ≥ 2000 Et ≤ 4000 → B13 = <b>${BT.n}</b>, B14 = <b>${XLAPP.display(BT.s, 'eur2')}</b>.`,
    cells: () => [[RP, 'B12', nb('B12', G3.n, v => v === 0 ? 'Aucune ligne ? Vous avez sans doute tapé « 3 000 € » : tapez 3000, sans espace ni symbole.' : v === G3.n + 1 ? 'Vous avez compté la ligne de titre.' : null)],
      [RP, 'B13', nb('B13', BT.n, v => v === BTS.n ? 'Bornes comprises : choisissez « supérieur ou égal » et « inférieur ou égal ».' : v === 500 ? 'Les deux conditions sont reliées par Ou : choisissez Et.' : null)],
      [RP, 'B14', nb('B14', BT.s, v => near(v, BTS.s) ? 'Bornes comprises : choisissez « supérieur ou égal » et « inférieur ou égal ».' : near(v, TOT.s) ? 'C\'est le total des 500 lignes : le filtre n\'est pas posé, ou les conditions sont reliées par Ou.' : null)]],
    check() { return summary(this.cells(), `${G3.n} dépenses au-dessus de 3 000 € ; ${BT.n} entre 2 000 et 4 000 €, pour ${XLAPP.display(BT.s, 'eur2')}. Dans un filtre numérique, on tape le nombre nu : 3000.`); } });

  S.push({ t: 'Le filtre textuel', go: [DP, 'D1'], tg: [RP, ['B17']],
    need: 'Le fournisseur Duval a deux sociétés et Sophie ne sait plus leurs noms exacts. Elle veut le nombre de lignes de <b>toutes</b> les sociétés dont le nom contient « Duval ».',
    ou: 'Flèche de <b>Fournisseur</b> → <b>Filtres textuels</b>. Réponse en <b>B17</b>.',
    verif: 'Sélectionnez la colonne Fournisseur : vous devez voir deux noms différents.',
    h: ['Données → Effacer d\'abord. Le nom commence parfois par Duval, parfois non : « Commence par » ne suffit pas.', 'Filtres textuels → <b>Contient…</b> → Duval. La casse ne compte pas.'],
    sol: `Données → Effacer. Flèche de Fournisseur → Filtres textuels → Contient… → Duval. B17 = <b>${DUV.n}</b> (Échafaudages Duval et Duval Plomberie).`,
    cells: () => [[RP, 'B17', nb('B17', DUV.n, v => v === DUV1.n || v === DUV2.n ? 'Vous n\'avez qu\'une des deux sociétés : utilisez Filtres textuels → Contient…' : v === DUV.n + 1 ? 'Vous avez compté la ligne de titre.' : null)]],
    check() { return summary(this.cells(), `${DUV.n} lignes : ${DUV1.n} chez Échafaudages Duval et ${DUV2.n} chez Duval Plomberie. « Contient » trouve le mot où qu'il soit dans le nom.`); } });

  const orderPb = () => { const pb = orderPb0(); return pb && A.hidden(DP).length ? 'Des lignes sont encore masquées : seules les lignes visibles ont été triées. Données → Effacer, puis triez de nouveau.' : pb; };
  const orderPb0 = () => {
    if (String(A.val(DP, 'A1')) !== 'Date' || String(A.val(DP, 'B1')) !== 'Chantier') return 'La ligne de titres a quitté la ligne 1 : « Mes données ont des en-têtes » était décoché. Annulez (Ctrl+Z) et recommencez.';
    for (let r = 2; r < 501; r++) { const a = String(A.val(DP, 'B' + r)), b = String(A.val(DP, 'B' + (r + 1))); const d = a.localeCompare(b, 'fr', { sensitivity: 'base' });
      if (d > 0) return `Les chantiers ne sont pas dans l'ordre de A à Z (ligne ${r + 1}).`;
      if (d === 0 && A.val(DP, 'E' + r) < A.val(DP, 'E' + (r + 1))) return `Dans un même chantier, les montants ne vont pas du plus grand au plus petit (ligne ${r + 1}, chantier ${a}).`; }
    return null; };
  S.push({ t: 'Trier sur deux niveaux', go: [DP, 'B2'], tg: [RP, ['B20']],
    need: 'Sophie veut la liste rangée <b>par chantier</b> (de A à Z) et, dans chaque chantier, <b>de la plus grosse dépense à la plus petite</b>. Puis elle demande la plus grosse dépense du chantier Hôtel du Parc — Senlis.',
    ou: 'Feuille <b>Dépenses 2026</b> : onglet <b>Données</b> → <b>Trier…</b>. Réponse feuille <b>Réponses</b>, en <b>B20</b>.',
    verif: 'Les lignes de chaque chantier se suivent, la plus grosse en premier. La ligne 1 contient toujours les titres.',
    h: ['Données → Effacer d\'abord (un tri sur une liste filtrée ne range que les lignes visibles). Puis Données → Trier… : vérifiez que « Mes données ont des en-têtes » est coché.', 'Trier par <b>Chantier</b>, De A à Z → <b>Ajouter un niveau</b> → Puis par <b>Montant HT</b>, Du plus grand au plus petit → OK.'],
    sol: `Données → Effacer. Données → Trier… : Chantier, De A à Z ; Ajouter un niveau ; Montant HT, Du plus grand au plus petit → OK. B20 = <b>${XLAPP.display(HP.top.m, 'eur2')}</b> (${HP.top.fo}).`,
    cells: () => [[DP, 'B2', orderPb()], [RP, 'B20', nb('B20', HP.top.m)]],
    check() { return summary(this.cells(), `Liste triée par chantier puis par montant. Plus grosse dépense de l'Hôtel du Parc : ${XLAPP.display(HP.top.m, 'eur2')}, chez ${HP.top.fo}.`); } });

  const e502 = () => raw(DP, 'E502');
  S.push({ t: 'Un total qui suit le filtre', go: [DP, 'E502'], tg: [DP, ['E502:F502']],
    need: 'Sophie veut un total, sous la liste, qui ne compte <b>que les lignes visibles</b> : les <b>locations de juin</b>. Pour comparer, elle veut aussi le total de toute la colonne.',
    ou: `Filtrez Catégorie sur <b>Location</b> et Date sur <b>juin</b>. Cliquez en <b>E502</b>, puis onglet <b>Accueil</b> → <b>Σ Somme automatique</b> → Entrée. En <b>F502</b>, tapez <code>=SOMME(E2:E501)</code>.`,
    verif: `E502 doit afficher ${XLAPP.display(LJ.s, 'eur2')} (${LJ.n} locations en juin) et F502 ${XLAPP.display(TOT.s, 'eur2')}, le total des 500 lignes. Regardez la formule de E502 dans la barre de formule.`,
    h: ['Données → Effacer, puis flèche de Catégorie : Location seule ; flèche de Date : juin seul. La ligne 502 reste visible sous la liste.', 'Quand la liste est filtrée, Somme automatique écrit <code>=SOUS.TOTAL(9;E2:E501)</code> au lieu de SOMME : le 9 veut dire « somme », et SOUS.TOTAL ignore les lignes masquées.'],
    sol: `Filtre : Catégorie = Location, Date = juin. E502 → Σ Somme automatique → Entrée : <code>=SOUS.TOTAL(9;E2:E501)</code> = ${XLAPP.display(LJ.s, 'eur2')}. F502 : <code>=SOMME(E2:E501)</code> = ${XLAPP.display(TOT.s, 'eur2')}.`,
    cells: () => { const ev = A.val(DP, 'E502'), fv = A.val(DP, 'F502'); let we = null, wf = null;
      if (empty(DP, 'E502')) we = 'Rien en E502 : cliquez en E502 puis Σ Somme automatique.';
      else if (!/^=SOUS\.TOTAL\((9|109);E\$?2:\$?E\$?501\)$/.test(e502())) we = /^=SOMME\(/.test(e502()) ? 'SOMME additionne aussi les lignes masquées : filtrez d\'abord, puis utilisez Somme automatique (elle écrit SOUS.TOTAL).' : 'Attendu : =SOUS.TOTAL(9;E2:E501).';
      else if (!near(ev, LJ.s)) we = near(ev, TOT.s) ? 'Aucun filtre actif : filtrez Catégorie sur Location et Date sur juin.' : 'La formule est juste, mais le filtre ne correspond pas : Location seule et juin seul.';
      if (empty(DP, 'F502')) wf = 'Tapez =SOMME(E2:E501) en F502.'; else if (!/^=SOMME\(E\$?2:\$?E\$?501\)$/.test(raw(DP, 'F502')) || !near(fv, TOT.s)) wf = 'Attendu : =SOMME(E2:E501).';
      return [[DP, 'E502', we], [DP, 'F502', wf]]; },
    check() { return summary(this.cells(), `SOUS.TOTAL donne ${XLAPP.display(LJ.s, 'eur2')} (seulement les lignes visibles), SOMME ${XLAPP.display(TOT.s, 'eur2')} (toutes les lignes). Changez le filtre : seul E502 bouge. Vous pouvez ensuite effacer E502 et F502.`); } });

  window.LESSON = { steps: S };
})();
