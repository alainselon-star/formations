import openpyxl,collections
F='/mnt/user-data/uploads/Formation bureautique/Excel/13 - Tableaux croisés dynamiques/Excel_13_TCD_factures_2026.xlsx'
wb=openpyxl.load_workbook(F,data_only=True); ws=wb['Factures']; h=[c.value for c in ws[1]]
rows=[dict(zip(h,r)) for r in ws.iter_rows(min_row=2,values_only=True)]
