# Production 13.2–13.5 (état au 4 nov. 2026, 21h30)
Découpage validé par Alain (production directe, pas de validation intermédiaire) :
- 13.2 D'autres chiffres : A.4 (Somme/NB/Moyenne/Max), Afficher les valeurs en % ; atelier = ex. 3 + question % + expérience C
- 13.3 Filtrer et présenter : filtre, tri, Grouper trimestres, segment, style ; atelier = ex. 4 et 6
- 13.4 Quand les données changent : Actualiser, tableau structuré, double-clic (Afficher les détails) ; atelier = ex. 5 et 7
- 13.5 Le fichier qui ment : A.8 source propre ; atelier = ex. 8 (fichier piège créé) + test final leçon
Moodle : un seul cours payant « Excel – TCD – Parcours complet », 1 section/module (SCORM + page atelier + fichier + quiz GIFT).
Noms exacts Excel FR (vérifiés en capture) : « Synthétiser les valeurs par » (Somme, NB, Moyenne, Max., Min.), « Afficher les valeurs » (% du total général…),
« Afficher les détails », « Actualiser », Grouper → « Trimestres » → étiquettes « Trimestre1…4 » (pas Trim1), regroupement auto crée « Mois (Date) » et « Jours (Date) »,
onglet « Analyse du tableau croisé dynamique » → Filtrer → « Insérer un segment ». Montant HT avec texte → cocher le place en Lignes ; glissé dans Valeurs → « Nombre de Montant HT ».
Fait : rendu images TCD (render.py, gen132.py → img132/T1..T6), captures réelles M04 (Synthétiser), M05 (Afficher les valeurs), M06 Grouper, M07 ruban segment,
M08 Insérer des segments, M09 segment En attente (Julie 98 210 / Thomas 55 610 / total 153 820), M10 montant en texte G4, M11 dates texte + Nombre de.
Fichier piège : Excel_13_TCD_factures_piege.xlsx déposé dans le dossier leçon 13 (G4 '1 200 €', A119 '21.05.2026', ligne 302 TOTAL, sans tableau structuré).
Reste : scripts/narration 13.2–13.5, pptx (base /home/claude/m131/build/build.js), Storyline (import pptx, TTS Léa/Isabelle(BE)/Rémi, quiz via import TXT format MC + ligne points 10, résultats 75 %), SCORM, Moodle.

## Décision du 4 nov. 2026, 21 h 40
Alain veut les modules 13.2 à 13.5 en Storyline, comme le 13.1 (pas en leçons Moodle natives).
Méthode pour économiser la limite : 1) préparer tout le contenu hors écran (scripts, narrations, PPTX, quiz .txt, pages et GIFT des ateliers) ;
2) Alain importe lui-même le PPTX dans Storyline et glisse les zip dans Moodle ; 3) Claude fait voix, quiz, résultats, publication.
Ensuite : cours Moodle MD-102 (usage personnel d'Alain), dans une autre conversation.
Fichiers de travail du conteneur (images, scripts) : /home/claude/m13 — à régénérer si la session est perdue (render.py + gen132.py décrits ci-dessus).
