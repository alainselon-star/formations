# Rendu "façon Excel" de tableaux croisés, en PNG, via Playwright
import html, asyncio
from playwright.sync_api import sync_playwright
CSS = """
body{margin:0;background:#fff;font-family:Carlito,Calibri,sans-serif;font-size:15px;color:#000}
table{border-collapse:collapse;margin:6px}
td{padding:2px 8px;white-space:nowrap;height:20px}
.h td{background:#DDEBF7;font-weight:bold;border-bottom:1px solid #9BC2E6}
.f{background:#fff}
.t td{background:#DDEBF7;font-weight:bold;border-top:1px solid #9BC2E6}
.n{text-align:right}
.dd{display:inline-block;width:13px;height:13px;border:1px solid #ababab;font-size:9px;line-height:12px;text-align:center;color:#555;margin-left:10px;vertical-align:middle;background:#fff}
.hl{background:#FFF2CC !important;outline:2px solid #F2A900}
.filt td{background:#fff}
.filt .lab{font-weight:bold}
"""
def fmt(v,kind='eur'):
    if v is None or v=='': return ''
    if isinstance(v,str): return v
    if kind=='eur0': s=f"{v:,.0f}".replace(',', ' '); return s+' €'
    if kind=='eur': s=f"{v:,.2f}".replace(',', ' ').replace('.', ',').replace(' ', ' '); return s+' €'
    if kind=='pct': return f"{v:.2f}".replace('.', ',')+' %'
    if kind=='int': return str(v)
    return str(v)

def pivot_html(header, body, total=None, kinds=None, filters=None, highlight=(), sort_icon=False):
    """header: list of header cells; body: list of rows [label, v1, v2...]; kinds: per value col"""
    kinds = kinds or ['eur']*(len(header)-1)
    out=['<table>']
    if filters:
        for lab,val in filters:
            out.append(f'<tr class="filt"><td class="lab">{html.escape(lab)}</td><td>{html.escape(val)}<span class="dd">▼</span></td></tr>')
        out.append('<tr><td>&nbsp;</td></tr>')
    out.append('<tr class="h">')
    for i,hc in enumerate(header):
        dd = '<span class="dd">%s</span>'%('↓' if (sort_icon and i==0) else '▼') if hc.startswith('Étiquettes') else ''
        out.append(f'<td class="{"n" if i else ""}">{html.escape(hc)}{dd}</td>')
    out.append('</tr>')
    for r_i,r in enumerate(body):
        out.append('<tr>')
        for i,c in enumerate(r):
            cls = 'n' if i else ''
            if (r_i,i) in highlight: cls+=' hl'
            out.append(f'<td class="{cls}">{html.escape(fmt(c,kinds[i-1]) if i else str(c))}</td>')
        out.append('</tr>')
    if total:
        out.append('<tr class="t">'+''.join(f'<td class="{"n" if i else ""}">{html.escape(fmt(c,kinds[i-1]) if i else str(c))}</td>' for i,c in enumerate(total))+'</tr>')
    out.append('</table>')
    return '\n'.join(out)

def shoot(inner, path, scale=2):
    with sync_playwright() as p:
        b=p.chromium.launch(); pg=b.new_page(device_scale_factor=scale)
        pg.set_content(f'<html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{inner}</body></html>')
        el=pg.query_selector('table'); el.screenshot(path=path); b.close()
