exec(open('data.py').read())
from render import *
O='img132/'
types=sorted(set(r['Type de travaux'] for r in rows),key=lambda s:s.replace('É','E'))
tot=sum(r['Montant HT'] for r in rows)
V={t:[r['Montant HT'] for r in rows if r['Type de travaux']==t] for t in types}
L='Étiquettes de lignes'
shoot(pivot_html([L,'Somme de Montant HT'],[[t,sum(V[t])] for t in types],['Total général',tot],['eur0']),O+'T1_somme.png')
shoot(pivot_html([L,'Nombre de Client'],[[t,len(V[t])] for t in types],['Total général',300],['int']),O+'T2_nombre.png')
shoot(pivot_html([L,'Moyenne de Montant HT'],[[t,sum(V[t])/len(V[t])] for t in types],['Total général',tot/300],['eur']),O+'T3_moyenne.png')
shoot(pivot_html([L,'Moyenne de Montant HT','Max de Montant HT'],[[t,sum(V[t])/len(V[t]),max(V[t])] for t in types],['Total général',tot/300,max(r['Montant HT'] for r in rows)],['eur','eur'],highlight={(2,1),(2,2)}),O+'T4_moy_max.png')
srt=sorted(types,key=lambda t:-sum(V[t]))
shoot(pivot_html([L,'Somme de Montant HT','Somme de Montant HT2'],[[t,sum(V[t]),100*sum(V[t])/tot] for t in srt],['Total général',tot,100.0],['eur0','pct'],sort_icon=True),O+'T5_pct.png')
shoot(pivot_html([L,'Somme de Montant HT','Somme de Montant HT2'],[[t,sum(V[t]),100.0] for t in srt],['Total général',tot,100.0],['eur0','pct'],sort_icon=True),O+'T6_pct_ligne.png')
