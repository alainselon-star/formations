// Atelier 05 interactif — Compter et totaliser par critère
(function () {
  'use strict';
  const A = XLAPP, SY = 0, PR = 1;
  const v = (si, ref) => A.val(si, ref), c = (si, ref) => A.cell(si, ref) || {};
  const isF = (si, ref) => c(si, ref).ast !== undefined;
  const raw = (si, ref) => String(c(si, ref).raw || '').toUpperCase().replace(/\s/g, '');
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.0005;
  const errOf = x => x && typeof x === 'object' && x.err;
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  // Plages de la feuille Devis : doivent couvrir les lignes 2 à 301 (ou la colonne entière)
  const slid = x => { const re = /DEVIS!\$?[A-I]\$?(\d+):\$?[A-I]\$?(\d+)/g; let m; while ((m = re.exec(x))) { if (+m[1] > 2 || +m[2] < 301) return true; } return false; };
  const sizes = x => { const re = /DEVIS!\$?[A-I]\$?(\d+):\$?[A-I]\$?(\d+)/g; const s = new Set(); let m; while ((m = re.exec(x))) s.add(m[1] + '-' + m[2]); return s.size > 1 || (s.size > 0 && /!\$?[A-I]:\$?[A-I](?![\d$])/.test(x)); };
  // Contrôle commun d'une cellule réponse
  function chk(si, ref, exp, o = {}) {
    if (!isF(si, ref)) return 'Pas de formule : il faut un calcul qui commence par =.';
    const x = v(si, ref), r = raw(si, ref), e = errOf(x);
    if (e === '#VALEUR!') return sizes(r) ? '#VALEUR! : les plages n\'ont pas la même taille (mêmes lignes de début et de fin partout).' : (o.ens && /^=SOMME\.SI\.ENS\(DEVIS!\$?[^H]/.test(r) ? 'Dans SOMME.SI.ENS, la plage des montants vient en premier.' : '#VALEUR! : vérifiez les plages et les paires plage ; critère.');
    if (e === '#NOM?') return '#NOM? : nom de fonction mal écrit, ou texte du critère sans guillemets.';
    if (e) return 'Erreur ' + e + '.';
    if (o.ref && !o.ref.test(r)) return o.refMsg;
    if (near(x, exp)) return null;
    if (slid(r)) return 'La plage a glissé en recopiant : il manque les $ (touche F4).';
    return (o.why && o.why(x, r)) || 'Ce n\'est pas le résultat attendu.';
  }
  const S = [];

  S.push({ t: 'Combien de devis par commercial', go: [SY, 'B4'], tg: [SY, ['B4:B7']],
    need: 'Pour la réunion commerciale, Sophie veut savoir combien de devis chacun a établis entre janvier et septembre. Les 300 devis sont sur la feuille <b>Devis</b> (colonne G « Commercial »).',
    ou: 'Feuille <b>Synthèse</b>, colonne <b>B</b> « Nombre de devis » : B4 à B6 pour les trois commerciaux, puis le total en <b>B7</b>.',
    verif: 'Une seule formule en B4, recopiée en B5 et B6 ; elle prend le nom en colonne A au lieu de le taper. Le total doit tomber sur les 300 devis.',
    h: ['Une fonction compte les cellules d\'une plage qui remplissent un critère : NB.SI(plage ; critère). La plage est la colonne Commercial de la feuille Devis, le critère est le nom en A4.', 'Pendant la saisie, cliquez sur l\'onglet Devis et sélectionnez G2:G301, puis F4 pour la bloquer avant de recopier.'],
    sol: 'B4 : <code>=NB.SI(Devis!$G$2:$G$301;A4)</code>, recopie jusqu\'en B6 ; B7 : <code>=SOMME(B4:B6)</code>.',
    cells: () => [['B4', 141], ['B5', 114], ['B6', 45]].map(([ref, n]) => [SY, ref, chk(SY, ref, n, { ref: new RegExp('A' + ref.slice(1) + '(?!\\d)'), refMsg: 'Le critère doit être le nom en colonne A (cliquez sur la cellule), pas tapé dans la formule.' })])
      .concat([[SY, 'B7', chk(SY, 'B7', 300, { why: () => 'Le total doit faire 300 : vérifiez les trois nombres au-dessus.' })]]),
    check() { return summary(this.cells(), '141 + 114 + 45 = 300 : tous les devis sont comptés, aucun n\'est oublié.'); } });

  S.push({ t: 'Le montant total par commercial', go: [SY, 'C4'], tg: [SY, ['C4:C7']],
    need: 'Compter ne suffit pas : Sophie veut aussi le montant total HT des devis de chacun.',
    ou: 'Colonne <b>C</b> « Montant total HT » : C4 à C6, puis le total en <b>C7</b>.',
    verif: 'Même logique que l\'étape précédente, mais on additionne la colonne H « Montant HT » au lieu de compter. Le total C7 est la somme de tous les devis.',
    h: ['SOMME.SI(plage du critère ; critère ; plage à additionner) : on cherche le nom dans la colonne G et on additionne la colonne H.', 'Les deux plages doivent avoir les mêmes lignes (2 à 301) et être bloquées avec F4.'],
    sol: 'C4 : <code>=SOMME.SI(Devis!$G$2:$G$301;A4;Devis!$H$2:$H$301)</code>, recopie ; C7 : <code>=SOMME(C4:C6)</code>.',
    cells: () => [['C4', 727190, 141], ['C5', 595930, 114], ['C6', 214550, 45]].map(([ref, n, cnt]) => [SY, ref, chk(SY, ref, n, { ref: new RegExp('A' + ref.slice(1) + '(?!\\d)'), refMsg: 'Le critère doit être le nom en colonne A.',
      why: (x, r) => x === cnt ? 'C\'est le nombre de devis, pas leur montant : il faut SOMME.SI avec la plage des montants.' : x === 0 ? '0 : l\'ordre des arguments est inversé ? D\'abord la plage du critère, puis le critère, puis la plage à additionner.' : null })])
      .concat([[SY, 'C7', chk(SY, 'C7', 1537670)]]),
    check() { return summary(this.cells(), '1 537 670 € de devis au total, dont 727 190 € pour Julie.'); } });

  S.push({ t: 'Seulement les devis acceptés', go: [SY, 'D4'], tg: [SY, ['D4:F7']],
    need: 'Un devis ne rapporte que s\'il est accepté. Sophie veut, pour chacun : le nombre de devis acceptés, leur montant, et le taux de transformation (part des devis acceptés). Cette fois il y a <b>deux critères</b> : le commercial et le statut « Accepté ».',
    ou: 'Colonnes <b>D</b>, <b>E</b> et <b>F</b>, lignes 4 à 6, puis la ligne <b>Total</b> (D7, E7, F7).',
    verif: 'D : nombre de devis acceptés ; E : montant accepté ; F : D divisé par B. Le taux du total F7 se calcule sur les totaux, pas en faisant la moyenne des trois taux.',
    h: ['Avec plusieurs critères : NB.SI.ENS(plage1 ; critère1 ; plage2 ; critère2) et SOMME.SI.ENS(plage à additionner ; plage1 ; critère1 ; plage2 ; critère2). Attention, dans SOMME.SI.ENS la plage des montants vient en premier.', 'Le statut est en colonne I. Le texte "Accepté" s\'écrit entre guillemets, avec l\'accent.'],
    sol: 'D4 : <code>=NB.SI.ENS(Devis!$G$2:$G$301;A4;Devis!$I$2:$I$301;"Accepté")</code><br>E4 : <code>=SOMME.SI.ENS(Devis!$H$2:$H$301;Devis!$G$2:$G$301;A4;Devis!$I$2:$I$301;"Accepté")</code><br>F4 : <code>=D4/B4</code> ; recopie jusqu\'à la ligne 6 ; ligne 7 : <code>=SOMME(D4:D6)</code>, <code>=SOMME(E4:E6)</code>, <code>=D7/B7</code>.',
    cells: () => {
      const o = []; const rows = [[4, 83, 434730, 141, 727190], [5, 64, 334630, 114, 595930], [6, 29, 133670, 45, 214550]];
      for (const [r, d, e, b, cc] of rows) {
        o.push([SY, 'D' + r, chk(SY, 'D' + r, d, { why: x => x === b ? 'C\'est le nombre de tous les devis : il manque le critère sur le statut (colonne I, "Accepté").' : null })]);
        o.push([SY, 'E' + r, chk(SY, 'E' + r, e, { ens: true, why: x => x === cc ? 'C\'est le montant de tous les devis : il manque le critère "Accepté".' : x === d ? 'C\'est un nombre de devis, pas un montant.' : null })]);
        o.push([SY, 'F' + r, chk(SY, 'F' + r, d / b, { why: x => near(x, b / d) ? 'Division inversée : devis acceptés divisés par nombre de devis.' : null })]);
      }
      o.push([SY, 'D7', chk(SY, 'D7', 176)], [SY, 'E7', chk(SY, 'E7', 903030)],
        [SY, 'F7', chk(SY, 'F7', 176 / 300, { why: x => near(x, (83 / 141 + 64 / 114 + 29 / 45) / 3) ? 'C\'est la moyenne des trois taux : calculez D7/B7, sur les totaux.' : null })]);
      return o;
    },
    check() { const r = summary(this.cells(), 'Sophie transforme le mieux (64,4 %), Julie apporte le plus gros montant accepté (434 730 €). Remarquez : si un devis en attente passe à « Accepté » dans la feuille Devis, toute la synthèse se met à jour seule.'); return r; } });

  S.push({ t: 'Les gros devis, avec un seuil réglable', go: [SY, 'B13'], tg: [SY, ['B13:B15', 'B9', 'B10']],
    need: 'Sophie veut repérer les gros devis : ceux <b>au-dessus du seuil</b> rangé en B9 (5 000 €). Elle se demande ensuite : « Et si on mettait la barre à 8 000 € ? »',
    ou: 'Tableau du bas, colonne <b>B</b> « Gros devis (colonne <b>B</b> « Gros devis »gt; seuil) », de B13 à B15. Puis tapez 8000 en <b>B9</b>, notez le nouveau nombre de Julie en <b>B10</b>, et remettez 5000 en B9.',
    verif: 'La formule utilise la cellule B9 : quand on change B9, les trois nombres changent seuls. B10 contient le résultat de Julie avec 8 000 €. B9 est revenu à 5 000.',
    h: ['Deux critères : le commercial (A13) et un montant supérieur au seuil. Un critère de comparaison s\'écrit entre guillemets : ">5000".', 'Pour utiliser la cellule B9, on colle l\'opérateur et la cellule avec & : ">"&$B$9. Le $B$9 reste hors des guillemets.'],
    sol: 'B13 : <code>=NB.SI.ENS(Devis!$G$2:$G$301;A13;Devis!$H$2:$H$301;"&gt;"&amp;$B$9)</code>, recopie ; B9 = 8000 → B13 affiche 21 → tapez <code>21</code> en B10 → B9 = 5000.',
    cells: () => {
      const seuil = v(SY, 'B9'); const exp = { 5000: [61, 50, 20], 8000: [21, 23, 5] }[seuil];
      const o = [['B13', 0], ['B14', 1], ['B15', 2]].map(([ref, i]) => { const r = raw(SY, ref);
        let w = null; if (isF(SY, ref) && /"[<>=]+\$?B\$?9"/.test(r)) w = '0 partout ? Le $B$9 doit être hors des guillemets, collé avec & : ">"&$B$9.';
        else if (isF(SY, ref) && !/B\$?9(?!\d)/.test(r)) w = /5000/.test(r) ? 'Seuil tapé dans la formule : utilisez la cellule B9.' : 'La formule doit utiliser le seuil en B9.';
        else if (exp) w = chk(SY, ref, exp[i], { why: x => x === [141, 114, 45][i] ? 'Tous les devis sont comptés : il manque le critère sur le montant.' : null });
        else w = isF(SY, ref) ? null : 'Pas de formule.';
        if (!w && !/\$B\$9/.test(r)) w = 'Le seuil a glissé en recopiant : bloquez B9 avec F4 ($B$9).';
        return [SY, ref, w]; });
      o.push([SY, 'B9', seuil === 5000 ? null : 'Remettez le seuil à 5 000 €.']);
      o.push([SY, 'B10', v(SY, 'B10') === 21 ? null : (v(SY, 'B10') == null || v(SY, 'B10') === '' ? 'Notez ici le nombre de gros devis de Julie avec un seuil à 8 000 €.' : 'Ce n\'est pas le nombre de Julie avec un seuil à 8 000 €.')]);
      return o;
    },
    check() { return summary(this.cells(), '61 gros devis pour Julie au-dessus de 5 000 €, 21 au-dessus de 8 000 € : une seule cellule à changer, aucune formule à retoucher.'); } });

  S.push({ t: 'Le 3e trimestre', go: [SY, 'C13'], tg: [SY, ['C13:D15']],
    need: 'Sophie veut le bilan du 3e trimestre : pour chacun, le nombre de devis <b>acceptés</b> entre la date de début (E9) et la date de fin (E10), et leur montant.',
    ou: 'Colonne <b>C</b> « Acceptés sur le trimestre » et colonne <b>D</b> « Montant accepté trimestre », lignes 13 à 15.',
    verif: 'Quatre critères à la fois : commercial, statut « Accepté », date ≥ E9, date ≤ E10. Les dates viennent des cellules jaunes, pas tapées dans la formule.',
    h: ['Une même plage peut servir deux fois : la colonne B « Date » avec ">="&$E$9, puis encore avec "<="&$E$10.', 'Pour le montant, SOMME.SI.ENS avec les mêmes critères et la plage des montants en premier.'],
    sol: 'C13 : <code>=NB.SI.ENS(Devis!$G$2:$G$301;A13;Devis!$I$2:$I$301;"Accepté";Devis!$B$2:$B$301;"&gt;="&amp;$E$9;Devis!$B$2:$B$301;"&lt;="&amp;$E$10)</code><br>D13 : <code>=SOMME.SI.ENS(Devis!$H$2:$H$301;Devis!$G$2:$G$301;A13;Devis!$I$2:$I$301;"Accepté";Devis!$B$2:$B$301;"&gt;="&amp;$E$9;Devis!$B$2:$B$301;"&lt;="&amp;$E$10)</code> ; recopie jusqu\'à la ligne 15.',
    cells: () => {
      const o = []; const rows = [[13, 20, 81740, 83], [14, 13, 77530, 64], [15, 10, 37470, 29]];
      const dates = ref => { const r = raw(SY, ref); return !isF(SY, ref) ? null : !/E\$?9(?!\d)/.test(r) || !/E\$?10(?!\d)/.test(r) ? 'La formule doit utiliser les deux dates, E9 et E10.' : /"[<>=]+\$?E\$?1?\d"/.test(r) ? 'Les cellules E9 et E10 doivent être hors des guillemets : ">="&$E$9.' : null; };
      for (const [r, cc, d, acc] of rows) {
        o.push([SY, 'C' + r, dates('C' + r) || chk(SY, 'C' + r, cc, { why: x => x === acc ? 'Ce sont tous les devis acceptés de l\'année : il manque les critères de date.' : null })]);
        o.push([SY, 'D' + r, dates('D' + r) || chk(SY, 'D' + r, d, { ens: true })]);
      }
      return o;
    },
    check() { return summary(this.cells(), 'Julie : 20 devis acceptés au 3e trimestre pour 81 740 €. Changez les dates en E9 et E10 : le tableau devient celui de n\'importe quelle période.'); } });

  S.push({ t: 'Les questions de Sophie', go: [PR, 'B5'], tg: [PR, ['B5:B9', 'E5:E10', 'F13:F15']],
    need: 'Sur la feuille <b>Pratique</b>, Sophie a préparé ses questions : nombre de devis par type de travaux, montant par ville, puis trois questions précises. À vous de choisir la bonne fonction à chaque fois.',
    ou: 'Feuille <b>Pratique</b> : <b>B5:B9</b> (nombre par type), <b>E5:E10</b> (montant par ville), puis les réponses aux questions 3 à 5 en <b>F13</b>, <b>F14</b> et <b>F15</b>.',
    verif: 'Une formule dans chaque cellule. Un critère : NB.SI ou SOMME.SI. Plusieurs critères : NB.SI.ENS ou SOMME.SI.ENS. Pour le 2e trimestre, du 01/04/2026 au 30/06/2026.',
    h: ['Type de travaux : colonne F ; ville : colonne E ; statut : colonne I ; montant : colonne H ; date : colonne B.', 'Q5 : quatre critères — "Accepté", "&gt;10000", "&gt;="&amp;DATE(2026;4;1), "&lt;="&amp;DATE(2026;6;30). Une date peut aussi s\'écrire "&gt;=01/04/2026".'],
    sol: 'B5 : <code>=NB.SI(Devis!$F$2:$F$301;A5)</code> ; E5 : <code>=SOMME.SI(Devis!$E$2:$E$301;D5;Devis!$H$2:$H$301)</code><br>F13 : <code>=NB.SI.ENS(Devis!G2:G301;"Thomas";Devis!I2:I301;"Refusé")</code><br>F14 : <code>=SOMME.SI.ENS(Devis!H2:H301;Devis!F2:F301;"Plomberie";Devis!E2:E301;"Compiègne";Devis!I2:I301;"Accepté")</code><br>F15 : <code>=NB.SI.ENS(Devis!I2:I301;"Accepté";Devis!H2:H301;"&gt;10000";Devis!B2:B301;"&gt;="&amp;DATE(2026;4;1);Devis!B2:B301;"&lt;="&amp;DATE(2026;6;30))</code>',
    cells: () => {
      const o = []; const typ = [89, 71, 61, 50, 29], vil = [512860, 124760, 338620, 191660, 219590, 150180];
      typ.forEach((n, i) => o.push([PR, 'B' + (5 + i), chk(PR, 'B' + (5 + i), n)]));
      vil.forEach((n, i) => o.push([PR, 'E' + (5 + i), chk(PR, 'E' + (5 + i), n, { why: x => Number.isInteger(x) && x < 300 ? 'C\'est un nombre de devis : la question demande un montant.' : null })]));
      o.push([PR, 'F13', chk(PR, 'F13', 38, { why: x => x === 114 ? 'Ce sont tous les devis de Thomas : il manque le statut "Refusé".' : null })]);
      o.push([PR, 'F14', chk(PR, 'F14', 56290, { ens: true, why: () => 'Trois critères : type "Plomberie", ville "Compiègne", statut "Accepté".' })]);
      o.push([PR, 'F15', chk(PR, 'F15', 5, { why: () => 'Quatre critères : statut, montant > 10 000, date ≥ 01/04/2026 et date ≤ 30/06/2026.' })]);
      return o;
    },
    check() { return summary(this.cells(), 'Peinture arrive en tête (89 devis), Compiègne pèse 512 860 €, Thomas a 38 devis refusés, 56 290 € de plomberie acceptée à Compiègne, et 5 gros devis acceptés au 2e trimestre.'); } });

  window.LESSON = { steps: S };
})();
