// Atelier 16 interactif — Un classeur, plusieurs feuilles
(function () {
  'use strict';
  const A = XLAPP, R = 'Récap T1';
  const v = (s, ref) => A.val(s, ref), c = (s, ref) => A.cell(s, ref) || {};
  const isF = (s, ref) => c(s, ref).ast !== undefined;
  const raw = (s, ref) => String(c(s, ref).raw || '').toUpperCase().replace(/\s/g, '');
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.005;
  const errOf = x => x && typeof x === 'object' && x.err;
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${bad[0][1]} : ${bad[0][2]}`) : OK(okMsg); };
  const names = () => A.names(), pos = n => names().indexOf(n);
  const MOIS = ['Janvier', 'Février', 'Mars'];
  const V = { Janvier: [[4200, 3100, 2650], [3800, 2900, 4100], [2500, 1800, 3300], [3600, 2700, 1950]], 'Février': [[4650, 2800, 3050], [3350, 3400, 3900], [2900, 2100, 2750], [4100, 2500, 2300]], Mars: [[5100, 3300, 2900], [4250, 3150, 4400], [3150, 2450, 3100], [3900, 3050, 2650]] };
  const REC = [0, 1, 2, 3].map(i => [0, 1, 2].map(j => MOIS.reduce((s, m) => s + V[m][i][j], 0)));
  const S = [];

  S.push({ t: 'Un premier lien', go: [R, 'H4'], tg: [R, ['H4:H7']],
    need: 'Sophie veut voir, sur la feuille de synthèse, le total de chaque mois. Ces totaux existent déjà : en E8 de chaque feuille mensuelle. Il faut les <b>relier</b>, pas les recopier à la main : si un chiffre change dans Janvier, la synthèse doit suivre.',
    ou: 'Feuille <b>Récap T1</b>, tableau de droite « Total du mois » : <b>H4</b> (janvier), <b>H5</b> (février), <b>H6</b> (mars), puis le total du trimestre en <b>H7</b>.',
    verif: 'Chaque cellule est une formule qui pointe vers E8 de la bonne feuille. Dans la barre de formule, on lit le nom de la feuille suivi d\'un point d\'exclamation.',
    h: ['Tapez = dans H4, puis cliquez sur l\'onglet Janvier, puis sur la cellule E8, et appuyez sur Entrée sans revenir sur Récap T1.', 'Le résultat s\'écrit <code>=Janvier!E8</code> : le nom de la feuille, un point d\'exclamation, la cellule. H7 est une simple somme de H4:H6.'],
    sol: 'H4 : <code>=Janvier!E8</code> ; H5 : <code>=Février!E8</code> ; H6 : <code>=Mars!E8</code> ; H7 : <code>=SOMME(H4:H6)</code>.',
    cells: () => MOIS.map((m, i) => { const ref = 'H' + (4 + i), x = raw(R, ref); let w = null;
      if (!isF(R, ref)) w = 'Pas de formule : le nombre tapé ne suivra pas les changements. Il faut un lien =' + m + '!E8.';
      else if (!x.includes(m.toUpperCase() + '!')) w = /^=[$A-Z]+\$?\d+$/.test(x) ? 'La formule pointe sur Récap T1 elle-même : vous êtes revenu sur Récap T1 avant d\'appuyer sur Entrée ?' : 'La formule doit pointer vers la feuille ' + m + '.';
      else if (!near(v(R, ref), [36600, 37800, 41400][i])) w = 'Ce n\'est pas le total du mois : visez la cellule E8 de ' + m + '.';
      return [R, ref, w]; }).concat([[R, 'H7', !isF(R, 'H7') ? 'Il faut une formule de total.' : near(v(R, 'H7'), 115800) ? null : 'Ce n\'est pas la somme des trois mois.']]),
    check() { return summary(this.cells(), '36 600 €, 37 800 €, 41 400 € : 115 800 € sur le trimestre, reliés aux feuilles des mois.'); } });

  S.push({ t: 'Additionner les trois mois d\'un coup', go: [R, 'B4'], tg: [R, ['B4:D7']],
    need: 'Sophie veut maintenant le détail : les ventes du trimestre par commercial et par métier. Chaque case de Récap T1 est la somme de la <b>même case</b> sur les trois feuilles des mois.',
    ou: 'Feuille <b>Récap T1</b>, de <b>B4</b> à <b>D7</b> (la colonne E et la ligne 8 se calculent déjà seules).',
    verif: 'Une formule en B4, recopiée vers la droite puis vers le bas. B4 doit faire 13 950 € (peinture de Julie sur le trimestre) et E8 115 800 €.',
    h: ['Excel sait additionner une même cellule sur plusieurs feuilles qui se suivent : c\'est une référence « 3D ». Tapez <code>=SOMME(</code>, cliquez sur l\'onglet Janvier, maintenez Maj et cliquez sur l\'onglet Mars, puis cliquez sur B4.', 'La formule s\'écrit <code>=SOMME(Janvier:Mars!B4)</code>. Pas de $ : B4 doit devenir C4, B5… quand on recopie.'],
    sol: 'B4 : <code>=SOMME(Janvier:Mars!B4)</code>, recopie jusqu\'en D4, puis B4:D4 jusqu\'à la ligne 7.',
    cells: () => { const o = []; for (let i = 0; i < 4; i++) for (let j = 0; j < 3; j++) { const ref = 'BCD'[j] + (4 + i), x = raw(R, ref), y = v(R, ref); let w = null;
      if (!isF(R, ref)) w = 'Pas de formule : il faut additionner les trois feuilles.';
      else if (errOf(y)) w = errOf(y) === '#REF!' ? 'Référence circulaire : la plage de feuilles inclut Récap T1. Partez de l\'onglet Janvier.' : errOf(y) === '#VALEUR!' && !/SOMME/.test(x) ? '#VALEUR! : une référence 3D s\'utilise dans une fonction, par exemple SOMME(Janvier:Mars!B4).' : 'Erreur ' + errOf(y) + '.';
      else if (!near(y, REC[i][j])) w = /\$/.test(x) ? 'La référence a été bloquée avec $ : elle doit rester relative pour suivre la recopie.' : /JANVIER:FÉVRIER!|FÉVRIER:MARS!/.test(x) ? 'Il manque un mois : la plage doit aller de Janvier à Mars.' : !/[A-ZÀ-Ÿ']+:[A-ZÀ-Ÿ' ]+!/.test(x) && (x.match(/!/g) || []).length === 1 ? 'Un seul mois est additionné : il faut les trois.' : 'Ce n\'est pas la somme des trois mois pour cette case.';
      o.push([R, ref, w]); } return o; },
    check() { const r = summary(this.cells(), 'B4 = 13 950 €, E8 = 115 800 € : la synthèse additionne les trois mois case par case.'); if (r.ok && !/:/.test(raw(R, 'B4').replace(/^=SOMME\(/, '').split('!')[0])) r.msg += ' Votre formule additionne les mois un par un : ça marche, mais sur 12 mois la référence 3D Janvier:Décembre!B4 sera bien plus courte.'; return r; } });

  S.push({ t: 'Une correction qui suit', go: ['Février', 'B4'], tg: [R, ['H9']],
    need: 'Thomas signale une erreur : les ventes de peinture de Julie en février font 5 650 €, pas 4 650 €. Sophie veut voir l\'effet sur le total du trimestre… puis on remet la valeur d\'origine pour la suite de l\'atelier.',
    ou: 'Feuille <b>Février</b>, cellule <b>B4</b> : tapez 5650. Revenez sur <b>Récap T1</b>, notez le nouveau total du trimestre (E8) en <b>H9</b>. Puis remettez 4650 en Février B4.',
    verif: 'H9 contient le total du trimestre avec 5 650 €. Février B4 est revenu à 4 650 €. Rien n\'a été retouché sur Récap T1, à part H9.',
    h: ['Après la modification, regardez E8 sur Récap T1 : il a bougé tout seul, de 1 000 €.', 'Tapez le nombre lu dans E8 en H9 (sans formule), puis retournez sur Février remettre 4650.'],
    sol: 'Février B4 = 5650 → Récap T1 E8 affiche 116 800 € → tapez <code>116800</code> en H9 → Février B4 = 4650.',
    cells: () => [[R, 'H9', near(v(R, 'H9'), 116800) ? null : (v(R, 'H9') == null || v(R, 'H9') === '' ? 'Notez ici le total du trimestre obtenu avec 5 650 €.' : 'Ce n\'est pas le total obtenu avec 5 650 € en février.')],
      ['Février', 'B4', v('Février', 'B4') === 4650 ? null : 'Remettez 4 650 en Février B4.']],
    check() { return summary(this.cells(), '116 800 € : la correction dans Février s\'est propagée seule jusqu\'à la synthèse. C\'est tout l\'intérêt des liens.'); } });

  S.push({ t: 'Deux feuilles d\'un coup', go: ['Février', 'B4'], tg: ['Février', ['B4:E8']],
    need: 'Janvier affiche ses montants en euros, mais pas Février ni Mars. Plutôt que de faire deux fois le même travail, Sophie veut les mettre en forme <b>en une seule fois</b>.',
    ou: 'Feuilles <b>Février</b> et <b>Mars</b>, plage <b>B4:E8</b> : format Monétaire (avec ou sans décimales).',
    verif: 'Les deux feuilles affichent des euros de B4 à E8. Ensuite, les feuilles sont dissociées : « [Groupe] » ne doit plus apparaître dans la barre verte du haut.',
    h: ['Cliquez sur l\'onglet Février, maintenez Ctrl et cliquez sur l\'onglet Mars : les deux feuilles sont groupées, « [Groupe] » s\'affiche en haut. Sélectionnez B4:E8 et choisissez le format dans la liste « Nombre ».', 'Pour dissocier : clic droit sur un onglet → Dissocier les feuilles (ou un simple clic sur l\'onglet Janvier). Attention : tant que le groupe est actif, ce que vous tapez s\'écrit aussi dans toutes les feuilles du groupe.'],
    sol: 'Février, Ctrl + clic sur Mars → B4:E8 → format Monétaire → clic droit sur un onglet → Dissocier les feuilles.',
    cells: () => { const o = []; for (const m of ['Février', 'Mars']) for (let r = 4; r <= 8; r++) for (const L of 'BCDE') { const f = c(m, L + r).f; o.push([m, L + r, f === 'eur0' || f === 'eur2' ? null : `${m} ${L}${r} n'est pas au format Monétaire${m === 'Mars' ? ' : la mise en forme n\'a touché qu\'une feuille ? Groupez-les avec Ctrl + clic sur les onglets.' : '.'}`]); } return o; },
    check() { const r = summary(this.cells(), 'Février et Mars sont en euros, en un seul geste.'); if (r.ok && A.grouped()) return KO('Les formats sont bons, mais les feuilles sont encore groupées : clic droit sur un onglet → Dissocier les feuilles.'); return r; } });

  S.push({ t: 'Préparer avril', go: ['Mars', 'A1'], tg: ['Mars', ['A1']],
    need: 'Le mois d\'avril commence. Sophie veut une feuille Avril identique à Mars (même tableau, mêmes formules, même mise en forme), placée juste après Mars, sans tout refaire.',
    ou: 'Les onglets en bas : créez une copie de <b>Mars</b>, renommez-la <b>Avril</b>, et écrivez « Ventes d\'avril 2026 » en <b>A1</b> de la nouvelle feuille.',
    verif: 'Un onglet Avril, placé après Mars, avec le titre d\'avril en A1 et les formules de total en colonne E et en ligne 8.',
    h: ['Clic droit sur l\'onglet Mars → Dupliquer. (Dans Excel : Ctrl + glisser l\'onglet, ou clic droit → Déplacer ou copier → Créer une copie.)', 'La copie s\'appelle « Mars (2) » : double-cliquez sur son onglet pour la renommer, tapez Avril, Entrée.'],
    sol: 'Clic droit sur Mars → Dupliquer → double-clic sur « Mars (2) » → Avril → A1 : <code>Ventes d\'avril 2026</code>.',
    cells: () => { const n = names(), p = pos('Avril'); if (p < 0) return [['Mars', 'A1', n.some(x => /\(\d+\)$/.test(x)) ? 'La copie existe, mais elle n\'est pas renommée : double-cliquez sur son onglet.' : 'Pas encore de feuille Avril : clic droit sur l\'onglet Mars → Dupliquer.']];
      return [['Avril', 'A1', /avril/i.test(String(v('Avril', 'A1') || '')) ? null : 'Le titre doit être celui d\'avril.'], ['Avril', 'E8', isF('Avril', 'E8') ? null : 'Les formules de total ont disparu : repartez d\'une copie de Mars.']]; },
    check() { const r = summary(this.cells(), 'Avril est prête, avec les formules et la mise en forme de Mars.'); if (r.ok && pos('Avril') < pos('Mars')) return KO('La feuille Avril existe, mais elle est placée avant Mars : faites glisser son onglet après Mars (ou clic droit → Déplacer vers la droite).'); return r; } });

  S.push({ t: 'Le piège de l\'ordre des onglets', go: [R, 'H10'], tg: [R, ['H10']],
    need: 'La formule Janvier:Mars!B4 additionne <b>toutes les feuilles placées entre</b> les onglets Janvier et Mars. Que se passe-t-il si une feuille se glisse au milieu ? Vérifiez-le, puis rangez tout.',
    ou: 'Faites glisser l\'onglet <b>Avril</b> entre Février et Mars. Notez le total E8 de Récap T1 en <b>H10</b>. Puis remettez Avril après Mars et effacez ses ventes (Avril, <b>B4:D7</b>).',
    verif: 'H10 contient le total faussé. Avril est revenue après Mars, ses ventes sont vides, et Récap T1 affiche de nouveau 115 800 €.',
    h: ['Glissez l\'onglet Avril avec la souris (sans Ctrl) et lâchez-le entre Février et Mars. Récap T1 E8 grimpe : les ventes d\'Avril (copiées de Mars) sont comptées.', 'Remettez Avril tout à droite, puis sélectionnez B4:D7 sur Avril et appuyez sur Suppr.'],
    sol: 'Avril entre Février et Mars → E8 = 157 200 € → tapez <code>157200</code> en H10 → Avril après Mars → Avril B4:D7, Suppr.',
    cells: () => { const p = pos('Avril'); const o = [[R, 'H10', near(v(R, 'H10'), 157200) ? null : (v(R, 'H10') == null || v(R, 'H10') === '' ? 'Notez ici E8 quand Avril est entre Février et Mars.' : 'Ce n\'est pas le total obtenu avec Avril entre Février et Mars.')]];
      if (p < 0) return o.concat([[R, 'E8', 'La feuille Avril n\'existe pas : faites d\'abord l\'étape précédente.']]);
      o.push([R, 'E8', near(v(R, 'E8'), 115800) ? null : (p < pos('Mars') ? 'Avril est encore entre Janvier et Mars : remettez-la après Mars.' : 'Le total du trimestre devrait revenir à 115 800 €.')]);
      let full = 0; for (let r = 4; r <= 7; r++) for (const L of 'BCD') { const x = c('Avril', L + r); if (x.raw !== '' && x.raw !== undefined) full++; }
      o.push(['Avril', 'B4', full ? `Il reste ${full} vente${full > 1 ? 's' : ''} dans Avril (B4:D7) : effacez-les.` : null]); return o; },
    check() { return summary(this.cells(), '157 200 € avec Avril au milieu : 41 400 € de trop. Une référence 3D prend toutes les feuilles entre les deux onglets, quel que soit leur nom. Rangez toujours les feuilles dans l\'ordre.'); } });

  window.LESSON = { steps: S };
})();
