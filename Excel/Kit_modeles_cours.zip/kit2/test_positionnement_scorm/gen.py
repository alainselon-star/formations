import openpyxl,json
wb=openpyxl.load_workbook('/mnt/user-data/outputs/md102/Banque_questions_positionnement_MD102.xlsx',read_only=True)
rows=list(wb['Banque'].iter_rows(values_only=True))[1:]
T={'01':"Relier un appareil à l'entreprise",'02':"Placer un appareil sous la gestion de l'entreprise",'03':"Donner à chacun les bons droits, pas plus",'04':"Laisser entrer seulement les appareils sûrs",'05':"Préparer un PC neuf sans y toucher",'06':"Équiper sans acheter, migrer sans perdre",'07':"Les mêmes réglages partout, sauf exceptions",'08':"Agir à distance, sans se déplacer",'09':"Fermer la porte aux attaques",'10':"Mettre à jour sans tout casser",'11':"Déployer les applications",'12':"Protéger les applications",'13':"Automatiser",'14':"Superviser et optimiser"}
Q=[]
for r in rows:
    if not r[0] or int(r[0][1:])>=68: continue
    ans=[a for a in r[5:10] if a]
    assert ans[-1]=='Je ne sais pas',r[0]
    c='ABCDE'.index(r[10].strip())
    Q.append(dict(id=r[0],d=r[1][:2],l=r[2][1:3],q=r[4],a=ans,c=c,fb=r[11],err=[x if x and not x.startswith('—') else '' for x in r[12:16]]))
draws={}
for t in list(wb['Tiroirs'].iter_rows(values_only=True))[1:15]: draws[t[0][1:3]]=t[3]
D={}
for t in list(wb['Tiroirs'].iter_rows(values_only=True))[1:15]: D.setdefault(t[1][:2],{'name':t[1][3:],'lessons':[]})['lessons'].append(t[0][1:3])
json.dump
open('pkg/data.js','w').write('window.POS='+json.dumps({'Q':Q,'draws':draws,'titles':T,'domains':D},ensure_ascii=False)+';')
print(len(Q),draws,sum(draws.values()),{k:v for k,v in D.items()})
# --- Ajouts notions L12 (15/11/2026) ---
import sys,random;sys.path.insert(0,'/home/claude/md12n');from q import Q as NQ1;from q2 import Q2 as NQ2;NQ=NQ1+NQ2
for k,(n,mid) in enumerate([(0,'M68'),(4,'M69'),(6,'M70'),(13,'M71'),(21,'M72')]):
    t,good,gf,bad=NQ[n];random.seed(100+k)
    ch=[(good,'')]+bad;random.shuffle(ch)
    Q.append(dict(id=mid,d='D4',l='12',q=t,a=[a for a,_ in ch]+['Je ne sais pas'],c=[a for a,_ in ch].index(good),fb=gf,err=[f for _,f in ch]))
open('pkg/data.js','w').write('window.POS='+json.dumps({'Q':Q,'draws':draws,'titles':T,'domains':D},ensure_ascii=False)+';')
print('total',len(Q),'L12',sum(q['l']=='12' for q in Q))
