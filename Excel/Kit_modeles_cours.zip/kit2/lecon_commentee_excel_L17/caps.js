const {render}=require('/home/claude/xlgrid.js');const {d,f}=require('./g.json');
const dd=n=>{const x=new Date(Date.UTC(1899,11,(n<60?31:30)+n));return String(x.getUTCDate()).padStart(2,'0')+'/'+String(x.getUTCMonth()+1).padStart(2,'0')+'/'+x.getUTCFullYear();};
const cols=[['A',100],['B',110],['C',130],['D',110]].map(([l,w])=>({l,w}));
const hd={n:1,cells:['N° devis','Date du devis','Date de signature','Délai (jours)'].map(v=>({v,b:1}))};
const mk=std=>[hd,...d.map((r,i)=>({n:i+2,cells:[r[0],{v:r[1],r:1},{v:r[2],r:1},{v:std?String(r[3]):dd(r[3]),r:1,mark:i==0,c:std?undefined:'#c00'}]})),{n:'…',cells:Array(4).fill({v:'…',c:'#888'})}];
const fc=[['A',100],['B',110],['C',90],['D',110],['E',110],['F',100]].map(([l,w])=>({l,w}));
const fh={n:1,h:40,cells:['N° facture','Date de facture','Délai (jours)','Échéance','Jours restants','Situation'].map(v=>({v,b:1,wrap:1}))};
const fr=[fh,...f.map((r,i)=>({n:i+2,cells:[r[0],{v:r[1],r:1},{v:String(r[2]),r:1},{v:r[3],r:1,mark:i==0},{v:String(r[4]),r:1},{v:r[4]<0?'En retard':'À venir',c:r[4]<0?'#c00':undefined}]})),{n:'…',cells:Array(6).fill({v:'…',c:'#888'})}];
render([
 ['img/X17_C01_piege_1900.png',{cols,sel:'D',fbar:{ref:'D2',f:'=C2-B2'},rows:mk(false)}],
 ['img/X17_C02_standard.png',{cols,sel:'D',fbar:{ref:'D2',f:'=C2-B2'},rows:mk(true),status:'<span>Moyenne : 13,75</span><span>Nombre : 40</span><span>Somme : 550</span>'}],
 ['img/X17_C03_echeances.png',{cols:fc,sel:'D',fbar:{ref:'D2',f:'=B2+C2'},rows:fr}],
]).then(()=>console.log('ok'));
