#!/usr/bin/env python3
"""Fabrique un paquet SCORM 1.2 à partir de scorm_src.pptx + Questions_Lxx.txt.
usage: make_scorm.py <dossier> <num> <titre_lecon> <section_id>"""
import sys, os, re, json, subprocess, shutil, zipfile
from pptx import Presentation
d, num, titre, sec = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
os.chdir(d)
src = open([f for f in os.listdir('.') if f in ('body.js', 'build.js')][0], encoding='utf-8').read()
titles = [re.sub(r"\\'", "'", m.group(2) or m.group(3)) for m in re.finditer(
    r"(contenu\(|addText\()(?:'((?:[^'\\]|\\.)*)'|\"([^\"]*)\")(?:,\s*'|,\s*\{ placeholder)", src)]
# keep only slide titles: contenu(...) and placeholder titles, in order
titles = [m.group(1) or m.group(2) for m in re.finditer(
    r"(?:contenu\(|s\.addText\()(?:'((?:[^'\\]|\\.)*)'|\"((?:[^\"\\]|\\.)*)\")(?=,\s*'\d|,\s*\{ placeholder)", src)]
titles = [t.replace("\\'", "'") for t in titles]
shutil.rmtree('sc', ignore_errors=True); os.makedirs('sc/slides')
subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', 'scorm_src.pptx'], capture_output=True)
subprocess.run(['pdftoppm', '-r', '160', '-png', 'scorm_src.pdf', 'sc/slides/s'], check=True)
p = Presentation('scorm_src.pptx')
SP = {'NARRATEUR': 'narr', 'SOPHIE': 'sophie', 'KARIM': 'karim'}
REPL = [("dsregcmd", "D S reg C M D"), ('DeviceId', 'Device I D'), ('MFA', 'M F A'), (' PC', ' pécé'), ('BYOD', 'B Y O D'),
        ('MDM', 'M D M'), ('GPO', 'G P O'), ('DEM', 'D E M'), ('ABM', 'A B M'), ('ADE', 'A D E'), ('COPE', 'C O P E'),
        ('COBO', 'C O B O'), ('MAM', 'M A M'), ('CSV', 'C S V'), ('ESP', 'E S P'), ('OOBE', 'O O B E'), ('TPM', 'T P M'), ('JSON', 'djé-sonne'), ('24H2', 'vingt-quatre H 2'), ('26H2', 'vingt-six H 2'), ('AOSP', 'A O S P'), ('OMA-URI', 'O M A, U R I'), ('OEMConfig', 'O E M Config'), ('CSP', 'C S P'), ('EPM', 'E P M'), ('RBAC', 'R B A C'), ('NDES', 'N D E S'), ('SCEP', 'S C E P'), ('PKI', 'P K I'), ('EDR', 'E D R'), ('ASR', 'A S R'), ('WDAC', 'W DAC'), ('TPM', 'T P M'), ('0x81036501', 'zéro x huit, un, zéro, trois, six, cinq, zéro, un')]
slides = []
n = len(p.slides)
for i, s in enumerate(p.slides, 1):
    lines = []
    for line in s.notes_slide.notes_text_frame.text.split('\n'):
        k, _, t = line.partition(' : ')
        t = t.strip(); say = t
        for a, b in REPL: say = say.replace(a, b)
        lines.append({'who': SP[k], 'text': t, 'say': say})
    slides.append({'img': 'slides/s-%02d.png' % i, 'title': titles[i - 1] if i - 1 < len(titles) else '', 'lines': lines})
qs = []
for blk in open(f'out/Questions_L{num}.txt', encoding='utf-8').read().strip().split('\n\n'):
    L = blk.strip().split('\n'); q = {'q': L[2], 'opts': []}
    for o in L[3:]:
        ok = o.startswith('*'); a, _, fb = o.lstrip('*').partition(' | ')
        q['opts'].append({'t': a.strip(), 'ok': ok, 'fb': fb.strip()})
    qs.append(q)
data = {'title': f"Excel Opérationnel · Leçon {num} – {titre}", 'slides': slides, 'quizAfter': n - 1, 'questions': qs, 'pass': 75,
        'review': f"Revoyez les diapositives 4 à {n-2}, puis réessayez le quiz.", 'reviewFrom': 3,
        'atelier': f'https://academie-numerique.moodlecloud.com/course/section.php?id={sec}'}
open('sc/data.js', 'w', encoding='utf-8').write('window.LESSON=' + json.dumps(data, ensure_ascii=False) + ';')
shutil.copy('/home/claude/player/index.html', 'sc/index.html')
man = open('/home/claude/player/imsmanifest.xml', encoding='utf-8').read().replace('MD102_L01', f'XLOP_L{num}').replace(
    "MD-102 · Leçon 01 – Relier un appareil à l'entreprise", data['title']).replace("Relier un appareil à l'entreprise", titre)
open('sc/imsmanifest.xml', 'w', encoding='utf-8').write(man)
z = f'Excel_OP_L{num}_v1.zip'
if os.path.exists(z): os.remove(z)
with zipfile.ZipFile(z, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, _, files in os.walk('sc'):
        for f in files:
            full = os.path.join(root, f); zf.write(full, os.path.relpath(full, 'sc'))
print('OK', z, n, 'diapos', len(qs), 'questions', titles)
