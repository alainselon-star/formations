// Excel Opérationnel Leçon 17 — PowerPoint pour import Storyline
const pptxgen = require('pptxgenjs');
const P = new pptxgen();
P.layout = 'LAYOUT_16x9'; // 10 x 5.625 in
P.title = "Excel - Leçon 17 - Calculer avec des dates";

const C = { dk: '1B2733', bleu: '1E4D33', acc: '217346', clair: 'E6F2EA', gris: 'F3F5F7',
  jaune: 'FFF6DC', jauneTxt: '8A6100', or: 'F2A900', rouge: 'FBECEA', rougeTxt: 'C0392B',
  mute: '6B7785', bleuClair: 'A9D5B8', blanc: 'FFFFFF', console: '0C0C0C', consTxt: 'CCCCCC' };
const F = 'Calibri';
const IMG = __dirname + '/img/', ICO = __dirname + '/icons/';
const DIM = require('./dims.json');

P.defineSlideMaster({ title: 'SOMBRE', background: { color: C.bleu },
  objects: [{ placeholder: { options: { name: 'title', type: 'title', x: 0.6, y: 1.6, w: 8.8, h: 1.2,
    fontFace: F, fontSize: 38, bold: true, color: C.blanc, valign: 'middle', align: 'left' }, text: '' } }] });
P.defineSlideMaster({ title: 'CONTENU', background: { color: C.blanc },
  objects: [{ placeholder: { options: { name: 'title', type: 'title', x: 0.5, y: 0.3, w: 7.3, h: 0.7,
    fontFace: F, fontSize: 25, bold: true, color: C.bleu, valign: 'middle', align: 'left' }, text: '' } }] });

function pic(s, file, x, y, maxW, maxH, name) {
  const [w0, h0] = DIM[file]; let w = maxW, h = w * h0 / w0;
  if (h > maxH) { h = maxH; w = h * w0 / h0; }
  s.addShape(P.shapes.RECTANGLE, { x: x - 0.02, y: y - 0.02, w: w + 0.04, h: h + 0.04, fill: { color: 'D5DCE3' }, line: { color: 'D5DCE3' } });
  s.addImage({ path: IMG + file, x, y, w, h, altText: name });
  return { w, h };
}
function contenu(titre, etape, notes) {
  const s = P.addSlide({ masterName: 'CONTENU' });
  s.addText(titre, { placeholder: 'title' });
  s.addShape(P.shapes.ROUNDED_RECTANGLE, { x: 7.95, y: 0.42, w: 1.6, h: 0.42, fill: { color: C.clair }, line: { color: C.clair }, rectRadius: 0.21 });
  s.addText(etape, { x: 7.95, y: 0.42, w: 1.6, h: 0.42, align: 'center', valign: 'middle', fontFace: F, fontSize: 11, bold: true, color: C.acc });
  s.addNotes(notes);
  return s;
}
function box(s, x, y, w, h, fill) { s.addShape(P.shapes.RECTANGLE, { x, y, w, h, fill: { color: fill }, line: { color: fill } }); }
function bandeau(s, y, runs, fill, h) {
  box(s, 0.5, y, 9.0, h || 0.7, fill || C.jaune);
  s.addText(runs, { x: 0.7, y, w: 8.6, h: h || 0.7, valign: 'middle', fontFace: F, fontSize: 15, color: C.dk });
}
const B = (t, col) => ({ text: t, options: { bold: true, color: col || C.acc } });
const T = (t) => ({ text: t });
function etapes(s, x, y, w, h, items, size) {
  s.addText(items.map((t, i) => ({ text: t, options: { bullet: { type: 'number' }, breakLine: i < items.length - 1, paraSpaceAfter: 8 } })),
    { x, y, w, h, valign: 'top', fontFace: F, fontSize: size || 15, color: C.dk });
}
function puces(s, x, y, w, h, items, size) {
  s.addText(items.map((t, i) => ({ text: t, options: { bullet: true, breakLine: i < items.length - 1, paraSpaceAfter: 6 } })),
    { x, y, w, h, valign: 'top', fontFace: F, fontSize: size || 15, color: C.dk });
}
function carte(s, x, y, w, h, fill, titre, sous, corps, titreCol) {
  box(s, x, y, w, h, fill);
  s.addText([
    { text: titre, options: { bold: true, fontSize: 17, color: titreCol || C.dk, breakLine: true } },
    { text: sous, options: { fontSize: 12, color: C.mute, breakLine: true } },
    { text: ' ', options: { fontSize: 6, breakLine: true } },
    { text: corps, options: { fontSize: 13 } }],
    { x: x + 0.18, y: y + 0.12, w: w - 0.36, h: h - 0.24, valign: 'top', fontFace: F, color: C.dk });
}

