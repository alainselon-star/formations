// Rendu générique d'une grille « type tableur » (illustrations des leçons Excel)
// spec = { cols:[{l,w}], rows:[{n, cells:[cell…], h}], fbar:{ref,f}, status, sel:'H' }
// cell = 'texte' | { v, r:1 (droite), b:1, bg, c, mark:1, hd:1, i:1, wrap:1, center:1 }
const { chromium } = require('playwright');
function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }
function html(sp) {
  const W = 34 + sp.cols.reduce((a, c) => a + c.w, 0);
  let h = `<html><head><style>
  body{margin:0;font-family:Carlito,Calibri,Arial;font-size:14px;background:#fff}
  table{border-collapse:collapse;table-layout:fixed;width:${W}px}
  td{box-sizing:border-box;height:22px;padding:0 5px;white-space:nowrap;overflow:hidden;border:1px solid #e1e1e1;color:#000}
  td.rh{background:#f3f3f3;color:#555;text-align:center;padding:0;border-color:#d4d4d4;font-size:12px}
  tr.ch td{background:#f3f3f3;color:#555;text-align:center;border-color:#d4d4d4;font-size:12px;height:20px}
  tr.ch td.sel{background:#d3e7d3;color:#1e6b3a;font-weight:bold;border-bottom:2px solid #217346}
  .fb{display:flex;border-bottom:1px solid #d4d4d4;font-size:14px;background:#fff}
  .fb .ref{width:84px;border-right:1px solid #d4d4d4;padding:5px 8px;color:#333}
  .fb .fx{width:34px;border-right:1px solid #d4d4d4;padding:5px 0;text-align:center;color:#777;font-style:italic}
  .fb .f{padding:5px 10px;font-family:Consolas,'DejaVu Sans Mono',monospace;font-size:13.5px}
  .sb{display:flex;justify-content:flex-end;gap:28px;background:#f3f3f3;border-top:1px solid #d4d4d4;padding:5px 18px;font-size:13px;color:#333}
  .mark{outline:3px solid #f2a900;outline-offset:-3px}
  </style></head><body><div id="g" style="display:inline-block;border:1px solid #c8c8c8;width:${W}px">`;
  if (sp.fbar) h += `<div class="fb"><span class="ref">${esc(sp.fbar.ref)}</span><span class="fx">fx</span><span class="f">${sp.fbar.html || esc(sp.fbar.f)}</span></div>`;
  h += `<table><tr class="ch"><td class="rh" style="width:34px"></td>` + sp.cols.map(c => `<td class="${sp.sel === c.l ? 'sel' : ''}" style="width:${c.w}px">${c.l}</td>`).join('') + '</tr>';
  for (const r of sp.rows) {
    h += `<tr${r.h ? ` style="height:${r.h}px"` : ''}><td class="rh">${r.n}</td>`;
    r.cells.forEach((c, j) => {
      if (c === null || c === undefined) c = '';
      const o = typeof c === 'object' ? c : { v: c };
      let st = '';
      if (o.r) st += 'text-align:right;'; if (o.center) st += 'text-align:center;';
      if (o.b) st += 'font-weight:bold;'; if (o.i) st += 'font-style:italic;';
      if (o.bg) st += `background:${o.bg};`; if (o.c) st += `color:${o.c};`;
      if (o.hd) st += 'font-weight:bold;background:#dbe9f7;text-align:center;border:1px solid #8aa8c8;white-space:normal;';
      if (o.wrap) st += 'white-space:normal;';
      if (o.mono) st += "font-family:Consolas,'DejaVu Sans Mono',monospace;font-size:12.5px;";
      const span = o.span ? ` colspan="${o.span}"` : '';
      h += `<td${span} class="${o.mark ? 'mark' : ''}" style="${st}">${o.html || esc(o.v ?? '')}</td>`;
    });
    h += '</tr>';
  }
  h += '</table>';
  if (sp.tabs) h += `<div style="display:flex;gap:2px;background:#f3f3f3;border-top:1px solid #d4d4d4;padding:0 0 0 40px;font-size:13px">` + sp.tabs.map(t => { const o = typeof t === 'object' ? t : { n: t };
    return `<span style="padding:4px 14px;${o.a ? 'background:#fff;color:#217346;font-weight:bold;border-bottom:3px solid #217346;' : o.g ? 'background:#fff;color:#217346;' : 'color:#444;'}${o.mark ? 'outline:3px solid #f2a900;outline-offset:-3px;' : ''}">${esc(o.n)}</span>`; }).join('') + `<span style="padding:4px 10px;color:#777">⊕</span></div>`;
  if (sp.status !== undefined) h += `<div class="sb">${sp.status || '&nbsp;'}</div>`;
  return h + '</div></body></html>';
}
async function render(list) { // list: [[path, spec], …]
  const b = await chromium.launch(); const p = await b.newPage({ deviceScaleFactor: 2 });
  for (const [f, sp] of list) { await p.setContent(html(sp)); await (await p.$('#g')).screenshot({ path: f }); }
  await b.close();
}
module.exports = { render, html };
