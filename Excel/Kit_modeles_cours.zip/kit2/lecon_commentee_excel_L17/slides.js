
// 1 — Titre
{ const s = P.addSlide({ masterName: 'SOMBRE' });
  s.addText('Calculer avec des dates', { placeholder: 'title' });
  s.addText("Délais, échéances et dates qui s'affichent en nombres", { x: 0.6, y: 2.85, w: 8.8, h: 0.6, fontFace: F, fontSize: 19, italic: true, color: C.blanc });
  s.addText('Excel Opérationnel · Leçon 17 · 15 min', { x: 0.6, y: 4.6, w: 6, h: 0.4, fontFace: F, fontSize: 12, color: C.bleuClair });
  s.addNotes("NARRATEUR : Combien de jours entre un devis et sa signature ? Quand une facture doit-elle être payée ? Combien de jours reste-t-il ? Dans cette leçon, vous allez calculer avec des dates, et comprendre pourquoi Excel affiche parfois une date de 1900, ou un nombre à cinq chiffres, à la place du résultat attendu."); }

// 2 — Dialogue
{ const s = contenu('Mercredi : combien de temps pour signer ?', '1 · Le besoin',
  "SOPHIE : Combien de temps nos clients mettent-ils à signer un devis ? Et pour les factures, je veux l'échéance de chacune, et voir tout de suite celles qui sont en retard.\nKARIM : J'ai écrit date de signature moins date du devis. Excel m'affiche deux février mille neuf cent. Je n'ose pas montrer ça.");
  avatars(s);
  box(s, 4.5, 1.3, 5.0, 2.0, C.clair);
  s.addText([{ text: 'Sophie', options: { bold: true, color: C.acc, breakLine: true } },
    { text: "« Le délai de signature, l'échéance de chaque facture, et les retards. »" }],
    { x: 4.7, y: 1.38, w: 4.6, h: 1.85, valign: 'top', fontFace: F, fontSize: 15, color: C.dk });
  box(s, 5.2, 3.5, 4.3, 1.4, C.jaune);
  s.addText([{ text: 'Karim', options: { bold: true, color: C.jauneTxt, breakLine: true } }, { text: "« Excel m'affiche 02/02/1900. »" }],
    { x: 5.4, y: 3.55, w: 4.0, h: 1.3, valign: 'top', fontFace: F, fontSize: 15, color: C.dk }); }

// 3 — Le problème
{ const s = contenu('Une formule juste, un affichage absurde', '1 · Le besoin',
  "NARRATEUR : Voici le tableau de Karim. Sa formule, égale C2 moins B2, est juste. Mais la colonne Délai était au format Date : le résultat, trente-trois jours, s'affiche comme la trente-troisième journée depuis le début du calendrier d'Excel, le deux février mille neuf cent. Le calcul est bon, c'est l'habillage qui trompe.");
  pic(s, 'X17_C01_piege_1900.png', 0.5, 1.15, 5.2, 2.66, 'Délai affiché en date');
  carte(s, 5.95, 1.15, 3.55, 2.66, C.rouge, '02/02/1900', '= 33 jours', 'Le résultat est juste, mais il est habillé en date.', C.rougeTxt);
  bandeau(s, 4.05, [B('Le calcul est bon, '), T('l\'affichage trompe. La solution est dans le format, pas dans la formule.')], C.jaune, 0.8); }

// 4 — Solution 1
{ const s = contenu('Solution 1 : compter sur le calendrier', '2 · Sans l\'outil',
  "NARRATEUR : Sans l'outil, on compte. Ouvrir un calendrier, compter les jours entre le deux janvier et le quatre février, attention au mois de février et aux années bissextiles. Quarante devis, quarante comptages. Pour les échéances, ajouter trente ou quarante-cinq jours à la main, et changer de mois au bon moment. Et chaque matin, recompter les jours restants avant chaque échéance. Une heure de travail, et des erreurs d'un jour un peu partout.");
  carte(s, 0.5, 1.2, 2.9, 2.6, C.gris, 'Délais', '40 comptages', 'Fin de mois, février, années bissextiles : des erreurs d\'un jour.');
  carte(s, 3.55, 1.2, 2.9, 2.6, C.gris, 'Échéances', '30 calculs', 'Ajouter 45 jours à la main, changer de mois au bon moment.');
  carte(s, 6.6, 1.2, 2.9, 2.6, C.gris, 'Jours restants', 'chaque matin', 'Tout recompter tous les jours.');
  bandeau(s, 4.05, [B('Bilan : ', C.rougeTxt), T('une heure de comptage, et un tableau faux dès le lendemain.')], C.rouge, 0.8); }

// 5 — Comprendre
{ const s = contenu('Une date est un nombre de jours', '3 · Comprendre',
  "NARRATEUR : Le secret : pour Excel, une date est un nombre. Le premier janvier mille neuf cent vaut un. Le premier janvier deux mille vingt-six vaut quarante-six mille vingt-trois. Chaque jour ajoute un. Le format Date habille ce nombre en jour, mois, année. Conséquence : on peut soustraire deux dates pour obtenir un nombre de jours, et ajouter des jours à une date pour obtenir une nouvelle date. Il faut seulement que le résultat porte le bon habillage : Standard pour un nombre de jours, Date pour une date.");
  s.addTable([
    [HD('Valeur'), HD('Au format Date'), HD('Au format Standard')],
    ['1', '01/01/1900', '1'],
    ['33', '02/02/1900', '33 (un délai)'],
    ['46023', '01/01/2026', '46023'],
    ['46339', '13/11/2026', '46339']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [2.4, 3.3, 3.3], fontSize: 15, rowH: 0.55 }, TB));
  bandeau(s, 4.0, [B('Date − date = '), T('un nombre de jours (format Standard). '), B('Date + jours = '), T('une date (format Date).')], C.jaune, 0.85); }

// 6 — Écart
{ const s = contenu('L\'écart entre deux dates', '4 · Solution 2',
  "NARRATEUR : En D2, égale C2 moins B2 : la date la plus récente moins la plus ancienne. Puis Accueil, groupe Nombre, Standard. Le deux février mille neuf cent devient trente-trois : trente-trois jours entre le devis et la signature. Recopiez, sélectionnez la colonne : la barre d'état affiche une moyenne de treize virgule soixante-quinze jours. Si le résultat est négatif, vous avez inversé les deux dates.");
  pic(s, 'X17_C02_standard.png', 0.5, 1.15, 5.2, 2.95, 'Délai au format Standard');
  etapes(s, 5.95, 1.15, 3.55, 2.95, ['=C2-B2 (la plus récente moins la plus ancienne)', 'Accueil → Nombre → Standard', 'Recopier vers le bas', 'Lire la moyenne dans la barre d\'état'], 13);
  bandeau(s, 4.35, [B('Résultat négatif ? '), T('les dates sont inversées : =B2-C2 au lieu de =C2-B2.')], C.gris, 0.7); }

// 7 — Échéance
{ const s = contenu('L\'échéance : une date plus des jours', '4 · Solution 2',
  "NARRATEUR : Pour les factures, l'échéance est la date de facture plus le délai de paiement. En D2, égale B2 plus C2. Excel ajoute quarante-cinq jours au premier novembre et trouve le seize décembre, en changeant de mois tout seul. Si le résultat s'affiche comme un nombre à cinq chiffres, appliquez le format Date courte : la valeur est juste, il manque l'habillage.");
  pic(s, 'X17_C03_echeances.png', 0.5, 1.15, 6.0, 2.45, 'Échéances');
  carte(s, 6.75, 1.15, 2.75, 2.45, C.clair, '=B2+C2', 'date + jours', '01/11/2026 + 45 jours = 16/12/2026.', C.acc);
  bandeau(s, 3.85, [B('Un nombre comme 46372 ? '), T('C\'est une date sans habillage : Accueil → Nombre → Date courte.')], C.jaune, 0.75); }

// 8 — Aujourd'hui
{ const s = contenu('AUJOURDHUI : la date qui avance toute seule', '4 · Solution 2',
  "NARRATEUR : Pour savoir combien de jours il reste avant chaque échéance, il faut la date du jour. La fonction AUJOURDHUI, sans rien entre les parenthèses, renvoie la date du jour et se met à jour à chaque ouverture du fichier. En E2 : égale D2 moins AUJOURDHUI, au format Standard. Un résultat négatif veut dire que l'échéance est dépassée. Attention : Contrôle point-virgule tape la date du jour une fois pour toutes, figée. Pratique pour noter la date d'un paiement, pas pour un compte à rebours.");
  s.addTable([
    [HD('Saisie'), HD('Résultat'), HD('Change demain ?')],
    ['=AUJOURDHUI()', 'la date du jour', 'oui, à chaque ouverture'],
    ['Ctrl+; (point-virgule)', 'la date du jour, tapée', 'non, elle est figée'],
    ['=D2-AUJOURDHUI()', 'jours avant l\'échéance', 'oui, il diminue chaque jour']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.0, 3.0, 3.0], fontSize: 14, rowH: 0.62 }, TB));
  bandeau(s, 3.85, [B('Négatif = en retard. '), T('Avec SI : =SI(E2<0;"En retard";"À venir").')], C.jaune, 0.75); }

// 9 — Autres fonctions
{ const s = contenu('Quelques fonctions de date utiles', '4 · Solution 2',
  "NARRATEUR : Quelques fonctions complètent la boîte à outils. ANNEE, MOIS et JOUR extraient une partie d'une date : MOIS de C2 donne deux pour février, pratique pour regrouper par mois. JOURSEM donne le jour de la semaine. MOIS point DECALER ajoute des mois entiers : l'échéance à un mois exact. Et NB point JOURS point OUVRES compte les jours ouvrés entre deux dates, sans les week-ends.");
  s.addTable([
    [HD('Fonction'), HD('Exemple'), HD('Résultat')],
    ['ANNEE / MOIS / JOUR', '=MOIS(C2)', '2 (février)'],
    ['JOURSEM', '=JOURSEM(C2;2)', '3 (mercredi, lundi = 1)'],
    ['MOIS.DECALER', '=MOIS.DECALER(B2;1)', 'la même date, un mois plus tard'],
    ['NB.JOURS.OUVRES', '=NB.JOURS.OUVRES(B2;C2)', 'jours ouvrés, sans week-ends']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [2.6, 3.4, 3.0], fontSize: 14, rowH: 0.62 }, TB));
  bandeau(s, 4.4, [B('Une date se tape '), T('avec des barres obliques et l\'année : 04/02/2026 (leçon 01).')], C.gris, 0.7); }

// 10 — Dates en texte
{ const s = contenu('Quand le calcul refuse : des dates en texte', '3 · Comprendre',
  "NARRATEUR : Si la soustraction renvoie dièse VALEUR, l'une des dates n'en est pas une : c'est du texte, souvent collé depuis un autre logiciel, avec des points ou une année à deux chiffres. Le signe : la date est calée à gauche. Solution : la leçon zéro un, Rechercher et remplacer les points par des barres obliques. Et à l'inverse, une date qui s'affiche quarante-six mille trente n'est pas cassée : elle a seulement perdu son format.");
  s.addTable([
    [HD('Ce qu\'on voit'), HD('Ce que c\'est'), HD('Que faire')],
    ['02/02/1900 dans un délai', 'un nombre de jours habillé en date', 'format Standard'],
    ['46030 à la place d\'une date', 'une date sans habillage', 'format Date courte'],
    ['#VALEUR! après une soustraction', 'une date en texte', 'la convertir (leçon 01)'],
    ['Une date calée à gauche', 'du texte', 'Rechercher « . » → « / »']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.2, 3.2, 2.6], fontSize: 14, rowH: 0.62 }, TB)); }

// 11 — Pièges
{ const s = contenu('Les pièges à éviter', '3 · Comprendre',
  "NARRATEUR : Les pièges les plus fréquents. Mettre le résultat au format Texte pour se débarrasser de la date : la formule ne calcule plus. Utiliser ANNEE moins ANNEE pour un délai : on obtient des années, pas des jours. Inverser l'ordre de la soustraction : résultat négatif. Utiliser Contrôle point-virgule au lieu d'AUJOURDHUI pour un compte à rebours. Et taper une date sans l'année : Excel prend l'année en cours.");
  s.addTable([
    [HD('Piège'), HD('Conséquence'), HD('Parade')],
    ['Format Texte sur le résultat', 'plus de calcul', 'format Standard'],
    ['=ANNEE(C2)-ANNEE(B2)', 'un écart en années', '=C2-B2'],
    ['=B2-C2', 'un délai négatif', 'la plus récente en premier'],
    ['Ctrl+; pour un compte à rebours', 'la date ne bouge plus', '=AUJOURDHUI()'],
    ['04/02 sans l\'année', 'année en cours', 'toujours taper l\'année']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.2, 2.8, 3.0], fontSize: 13.5, rowH: 0.58 }, TB)); }

// 12 — Tableau de synthèse
{ const s = contenu('Délai, échéance, retard : le trio', '4 · Solution 2',
  "NARRATEUR : Récapitulons avec les deux demandes de Sophie. Le délai de signature : date moins date, au format Standard. L'échéance : date plus délai de paiement, au format Date. Les jours restants : échéance moins AUJOURDHUI, au format Standard. La situation : un SI sur les jours restants. Quatre formules, recopiées vers le bas, et un tableau qui se met à jour chaque matin.");
  carte(s, 0.5, 1.2, 2.15, 2.8, C.clair, 'Délai', '=C2-B2', 'Format Standard.', C.acc);
  carte(s, 2.8, 1.2, 2.15, 2.8, C.clair, 'Échéance', '=B2+C2', 'Format Date.', C.acc);
  carte(s, 5.1, 1.2, 2.15, 2.8, C.clair, 'Jours restants', '=D2-AUJOURDHUI()', 'Format Standard.', C.acc);
  carte(s, 7.35, 1.2, 2.15, 2.8, C.jaune, 'Situation', '=SI(E2<0;…)', '« En retard » ou « À venir ».', C.jauneTxt);
  bandeau(s, 4.25, [B('Le format décide de l\'affichage : '), T('Standard pour des jours, Date pour une date.')], C.gris, 0.7); }

// 13 — À retenir
{ const s = contenu('À retenir', '5 · À retenir',
  "NARRATEUR : Retenez. Une date est un nombre de jours. Date moins date donne des jours, au format Standard. Date plus jours donne une date, au format Date. Une date de mille neuf cent dans un délai, ou un nombre à cinq chiffres à la place d'une date : c'est le format, pas le calcul. AUJOURDHUI se met à jour, Contrôle point-virgule fige la date. Et MOIS, JOURSEM, MOIS point DECALER ou NB point JOURS point OUVRES pour aller plus loin.");
  s.addTable([
    [HD('Besoin'), HD('Formule')],
    ['Écart en jours', '=C2-B2, format Standard'],
    ['Échéance', '=B2+30, format Date'],
    ['Date du jour qui avance', '=AUJOURDHUI()'],
    ['Jours restants', '=D2-AUJOURDHUI()'],
    ['Un mois plus tard', '=MOIS.DECALER(B2;1)'],
    ['Jours ouvrés', '=NB.JOURS.OUVRES(B2;C2)']],
    Object.assign({ x: 0.5, y: 1.15, w: 9.0, colW: [3.4, 5.6], fontSize: 14, rowH: 0.55 }, TB)); }

// 14 — Fin
{ const s = P.addSlide({ masterName: 'SOMBRE' });
  s.addText('Les dates n\'ont plus de secret', { placeholder: 'title' });
  s.addText("Vous savez calculer un délai, une échéance et des jours restants, et corriger une date qui s'affiche mal. Passez à l'atelier : les devis signés et les factures vous attendent.",
    { x: 0.6, y: 2.85, w: 8.8, h: 1.0, valign: 'top', fontFace: F, fontSize: 18, color: C.blanc });
  if (!SCORM) {
    s.addShape(P.shapes.ROUNDED_RECTANGLE, { x: 0.6, y: 4.2, w: 3.6, h: 0.7, fill: { color: C.or }, line: { color: C.or }, rectRadius: 0.1 });
    s.addText("Passer à l'atelier →", { x: 0.6, y: 4.2, w: 3.6, h: 0.7, align: 'center', valign: 'middle', fontFace: F, fontSize: 15, bold: true, color: C.dk }); }
  s.addNotes("SOPHIE : Treize jours en moyenne pour signer. Et je vois chaque matin les factures en retard.\nKARIM : Et plus de mille neuf cent dans mes délais.\nNARRATEUR : Bravo. Passez maintenant à l'atelier."); }

P.writeFile({ fileName: __dirname + (SCORM ? '/scorm_src.pptx' : '/Excel_L17_Calculer_dates.pptx') }).then(f => console.log('OK', f));
