// Atelier 03 interactif — La formule qui se dérègle
(function () {
  'use strict';
  const A = XLAPP, P = 0, G = 1;
  const v = (si, ref) => A.val(si, ref), c = (si, ref) => A.cell(si, ref) || {};
  const isF = (si, ref) => c(si, ref).ast !== undefined;
  const raw = (si, ref) => String(c(si, ref).raw || '').toUpperCase().replace(/\s/g, '');
  const fmt = (si, ref) => c(si, ref).f || 'gen';
  const range = (a, b) => { const o = []; for (let i = a; i <= b; i++) o.push(i); return o; };
  const OK = (m) => ({ ok: true, msg: m }), KO = (m) => ({ ok: false, msg: m });
  const near = (a, b) => typeof a === 'number' && Math.abs(a - b) < 0.005;
  const isErr = x => x && typeof x === 'object' && x.err;
  const R = range(4, 28), H = r => v(P, 'H' + r);
  const nof = (ref, si = P) => !isF(si, ref) ? 'Pas de formule : il faut un calcul qui commence par =.' : null;
  const enDur = ref => /%|0,0?\d/.test(raw(P, ref)) && !/Q/.test(raw(P, ref));
  let seenF = false; try { seenF = localStorage.getItem('xl03-seenf') === '1'; } catch (e) {}
  window.onShowFormulas = () => { seenF = true; try { localStorage.setItem('xl03-seenf', '1'); } catch (e) {} };
  window.onLessonReset = () => { seenF = false; try { localStorage.removeItem('xl03-seenf'); } catch (e) {} };
  const summary = (cells, okMsg) => { const bad = cells.filter(x => x[2]); const first = bad.find(x => !/^Le résultat est juste/.test(x[2])) || bad[0]; return bad.length ? KO(`${bad.length} cellule${bad.length > 1 ? 's' : ''} à revoir, par exemple ${first[1]} : ${first[2]}`) : OK(okMsg); };

  const S = [];
  // 1 — TVA
  S.push({ t: 'La TVA, avec un taux qui ne bouge pas', go: [P, 'J4'], tg: [P, ['J4:J28']],
    need: 'Sophie veut la TVA de chacune des 25 factures de mars. Le taux de TVA est rangé une seule fois, dans la cellule jaune Q3.',
    ou: 'Feuille <b>Factures mars</b>, colonne <b>J</b> « TVA », de J4 à J28.',
    verif: 'Une seule formule, écrite en J4 puis recopiée jusqu\'en J28. Elle doit utiliser la cellule Q3, pas un taux tapé dans la formule.',
    h: ['Montant HT × taux. Le montant doit changer à chaque ligne, le taux doit rester sur Q3.', 'Une référence se bloque avec des $ : touche F4 juste après avoir cliqué sur Q3.'],
    sol: 'J4 : <code>=H4*$Q$3</code>, puis double-clic sur la poignée.',
    cells: () => R.map(r => { const ref = 'J' + r; let w = nof(ref); if (!w && enDur(ref)) w = 'Taux tapé dans la formule : utilisez la cellule Q3.'; if (!w && !near(v(P, ref), H(r) * v(P, 'Q3'))) w = /Q\d/.test(raw(P, ref)) && !/Q\$3/.test(raw(P, ref)) ? 'Le taux a glissé : la formule ne pointe plus sur Q3.' : 'Ce n\'est pas la TVA de cette facture.'; return [P, ref, w]; }),
    check() { return summary(this.cells(), '380,00 € de TVA pour la première facture, et chaque ligne pointe toujours sur Q3.'); } });
  // 2 — TTC
  S.push({ t: 'Le montant TTC', go: [P, 'K4'], tg: [P, ['K4:K28']],
    need: 'Sophie veut le montant TTC de chaque facture.',
    ou: 'Colonne <b>K</b> « Montant TTC », de K4 à K28.',
    verif: 'Une seule formule recopiée. Se demander : faut-il bloquer quelque chose cette fois ?',
    h: ['TTC = HT + TVA, les deux sur la même ligne.', 'Les deux cellules doivent suivre la ligne quand on recopie : aucun $.'],
    sol: 'K4 : <code>=H4+J4</code>, puis recopie.',
    cells: () => R.map(r => { const ref = 'K' + r; let w = nof(ref); if (!w && !near(v(P, ref), H(r) + (v(P, 'J' + r) || 0))) w = 'Ce n\'est pas le HT plus la TVA de cette ligne.'; return [P, ref, w]; }),
    check() { return summary(this.cells(), 'Ici, rien à bloquer : les deux cellules suivent la ligne. Total TTC : 193 237 €.'); } });
  // 3 — Part
  S.push({ t: 'La part de chaque facture', go: [P, 'L4'], tg: [P, ['L4:L28']],
    need: 'Sophie veut savoir quelle part du chiffre d\'affaires du mois représente chaque facture, en pourcentage. Le total du mois est en H29.',
    ou: 'Colonne <b>L</b> « Part du total », de L4 à L28.',
    verif: 'Un pourcentage par facture ; la somme de la colonne fait 100 %. Aucune erreur #DIV/0!.',
    h: ['Montant de la facture ÷ total du mois. Lequel des deux doit rester fixe ?', 'Bloquez H29 avec F4, puis passez la colonne au format Pourcentage (clic droit → Format de cellule).'],
    sol: 'L4 : <code>=H4/$H$29</code>, recopie, puis format <b>Pourcentage (0,0 %)</b>.',
    cells: () => R.map(r => { const ref = 'L' + r, x = v(P, ref); let w = nof(ref);
      if (!w && isErr(x)) w = x.err === '#DIV/0!' ? '#DIV/0! : le total a glissé vers une cellule vide. Bloquez H29.' : 'Erreur ' + x.err + '.';
      if (!w && !near(x, H(r) / 175670)) w = 'Ce n\'est pas la part de cette facture dans le total.';
      if (!w && !/^pct/.test(fmt(P, ref))) w = 'Le résultat est juste, mais pas affiché en pourcentage.'; return [P, ref, w]; }),
    check() { return summary(this.cells(), '2,2 % pour la première facture, 100 % au total : H29 est resté bloqué.'); } });
  // 4 — Commission puis 6 %
  S.push({ t: 'La commission, puis un nouveau taux', go: [P, 'M4'], tg: [P, ['M4:M28', 'Q4']],
    need: 'Calculez la commission de chaque facture avec le taux de la cellule Q4. Puis Sophie annonce que le taux passe à <b>6 %</b> : toutes les commissions doivent suivre, sans retoucher une seule formule.',
    ou: 'Colonne <b>M</b> « Commission », de M4 à M28 ; puis la cellule jaune <b>Q4</b>.',
    verif: 'Avec 5 %, la somme des commissions est de 8 783,50 €. Avec 6 %, elle doit passer à 10 540,20 €.',
    h: ['Même principe que la TVA, avec le taux de Q4.', 'Pour changer le taux, on ne touche qu\'à Q4 : tapez 6 % dedans.'],
    sol: 'M4 : <code>=H4*$Q$4</code>, recopie ; puis tapez <code>6%</code> en Q4.',
    cells: () => R.map(r => { const ref = 'M' + r; let w = nof(ref); if (!w && enDur(ref)) w = 'Taux tapé dans la formule : il ne suivra pas le changement de Q4.'; if (!w && !near(v(P, ref), H(r) * v(P, 'Q4'))) w = /Q\d/.test(raw(P, ref)) && !/Q\$4/.test(raw(P, ref)) ? 'Le taux a glissé : la formule ne pointe plus sur Q4.' : 'Ce n\'est pas la commission de cette facture.'; return [P, ref, w]; })
      .concat([[P, 'Q4', near(v(P, 'Q4'), 0.06) ? null : 'Le taux doit maintenant être de 6 %.']]),
    check() { const r = summary(this.cells(), 'Les commissions ont suivi le nouveau taux : 10 540,20 € au total, sans toucher aux formules.'); if (!r.ok && this.cells().filter(x => x[2]).length === 1 && !near(v(P, 'Q4'), 0.06)) return KO('Les commissions sont justes. Il reste à passer le taux à 6 % dans Q4.'); return r; } });
  // 5 — Cumul
  S.push({ t: 'Le chiffre d\'affaires cumulé', go: [P, 'N4'], tg: [P, ['N4:N28']],
    need: 'Sophie veut voir le chiffre d\'affaires grandir facture après facture : sur chaque ligne, le total depuis la première facture du mois.',
    ou: 'Colonne <b>N</b> « CA cumulé », de N4 à N28.',
    verif: 'N4 = la première facture ; N28 = le total du mois, 175 670 €.',
    h: ['Une somme dont le début reste toujours sur la première facture, et dont la fin descend avec la ligne.', 'Dans la plage H4:H4, bloquez seulement le début avec F4.'],
    sol: 'N4 : <code>=SOMME($H$4:H4)</code>, puis recopie.',
    cells: () => { let cum = 0; return R.map(r => { cum += H(r); const ref = 'N' + r; let w = nof(ref); if (!w && !near(v(P, ref), cum)) w = /SOMME\(H4/.test(raw(P, ref)) ? 'Le début de la plage a glissé : il doit rester sur H4.' : 'Ce n\'est pas le cumul jusqu\'à cette ligne.'; return [P, ref, w]; }); },
    check() { return summary(this.cells(), 'La plage s\'allonge à chaque ligne : 175 670 € en N28.'); } });
  // 6 — Grille
  S.push({ t: 'La grille du banquier', go: [G, 'B5'], tg: [G, ['B5:D14']],
    need: 'Le banquier veut une grille des prix TTC : chaque montant HT de la colonne A, avec chacun des trois taux de la ligne 4.',
    ou: 'Feuille <b>Grille</b>, de B5 à D14.',
    verif: 'Une seule formule, écrite en B5 puis recopiée vers la droite et vers le bas. Par exemple 1 055 € en B5.',
    h: ['Montant × (1 + taux). Le montant est toujours en colonne A, le taux toujours en ligne 4.', 'Bloquez seulement la colonne du montant ($A5) et seulement la ligne du taux (B$4).'],
    sol: 'B5 : <code>=$A5*(1+B$4)</code>, recopie vers la droite jusqu\'en D5, puis vers le bas jusqu\'à la ligne 14.',
    cells: () => { const out = []; for (let r = 5; r <= 14; r++) for (const L of 'BCD') { const ref = L + r; let w = nof(ref, G);
        if (!w && !near(v(G, ref), v(G, 'A' + r) * (1 + v(G, L + '4')))) { const x = raw(G, ref); w = !/\$/.test(x) ? 'Rien n\'est bloqué : le montant ou le taux a glissé.' : (/\$[A-Z]\$\d/.test(x) ? 'Trop de $ : une référence entièrement bloquée ne suit plus ni la ligne ni la colonne.' : 'Ce n\'est pas le montant de la ligne avec le taux de la colonne.'); }
        out.push([G, ref, w]); } return out; },
    check() { return summary(this.cells(), 'Une seule formule pour 30 cellules : 12 000 € en D14 (10 000 € avec 20 %).'); } });
  // 7 — Afficher les formules
  S.push({ t: 'Contrôler d\'un coup d\'œil', go: [P, 'J4'], tg: [P, ['J4:N28']],
    need: 'Avant d\'envoyer le fichier, Sophie veut s\'assurer que chaque colonne contient bien la même formule, avec le taux bloqué.',
    ou: 'Feuille Factures mars. Bouton <b>ƒx Afficher les formules</b> du ruban (ou Ctrl+`). Cliquez de nouveau pour revenir aux résultats.',
    verif: 'Dans chaque colonne, la même formule, seul le numéro de ligne change, et le taux reste sur $Q$3 ou $Q$4.',
    h: ['Excel peut montrer les formules à la place des résultats.', 'Le bouton se trouve dans le groupe Formules du ruban.'],
    sol: 'Bouton <b>ƒx Afficher les formules</b>, lecture des colonnes J à N, puis nouveau clic pour revenir.',
    cells: () => [[P, 'J4', seenF ? null : 'Affichez les formules pour contrôler.']],
    check() { return seenF ? OK('Vous avez contrôlé les formules : c\'est le réflexe à avoir avant d\'envoyer un fichier.') : KO('Les formules n\'ont pas encore été affichées.'); } });
  window.LESSON = { steps: S };
})();
